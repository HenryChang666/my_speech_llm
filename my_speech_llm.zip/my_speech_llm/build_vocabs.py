#!/usr/bin/env python3
"""
Build vocabulary files for multi-scale CTC training.
Scans AISHELL training text and generates:
  1. phoneme_vocab.json      (initial + final phonemes with tone)
  2. char_vocab.json         (character-level vocabulary)
  3. pinyin_vocab.json       (pinyin syllable, no tone)
  4. pinyin_tone_vocab.json  (pinyin syllable, with tone)
"""

import os
import sys
import csv
import json
from pathlib import Path
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data.multiscale_tokenizer import PhonemeTokenizer, CharTokenizer, PinyinTokenizer

# AISHELL-1 data path (modelscope cache)
_MS_BASE = Path("/root/.cache/modelscope/hub/datasets/speech_asr/"
                "speech_asr_aishell1_trainsets/master/data_files")
_TRAIN_CSV = _MS_BASE / "dcd916f7a01b91236cd9f05c4f59c75a"

OUTPUT_DIR = "/root/workspace/my_speech_llm/vocabs"


def load_aishell_texts(csv_path: Path) -> list:
    """Load transcription texts from AISHELL CSV."""
    texts = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            text = row["Text:LABEL"].strip().replace(" ", "")
            if text:
                texts.append(text)
    return texts


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"Loading AISHELL training texts from {_TRAIN_CSV} ...")
    texts = load_aishell_texts(_TRAIN_CSV)
    print(f"  Total texts: {len(texts):,}")

    test_text = "人工智能"

    # 1. Phoneme vocab (initial + final, with tone)
    print("\n[1] Building phoneme vocabulary (with_tone=True) ...")
    ph_tok = PhonemeTokenizer(with_tone=True)
    ph_tok.build_from_texts(texts)
    ph_path = os.path.join(OUTPUT_DIR, "phoneme_vocab.json")
    ph_tok.save_vocab(ph_path)
    print(f"  Phoneme vocab size: {ph_tok.vocab_size}")
    print(f"  Saved: {ph_path}")
    encoded = ph_tok.encode(test_text)
    decoded = ph_tok.decode(encoded)
    print(f"  Test: '{test_text}' -> {encoded} -> '{decoded}'")

    # 2. Character vocab
    print("\n[2] Building character vocabulary ...")
    ch_tok = CharTokenizer()
    ch_tok.build_from_texts(texts, min_freq=2)
    ch_path = os.path.join(OUTPUT_DIR, "char_vocab.json")
    ch_tok.save_vocab(ch_path)
    print(f"  Char vocab size: {ch_tok.vocab_size}")
    print(f"  Saved: {ch_path}")
    encoded = ch_tok.encode(test_text)
    decoded = ch_tok.decode(encoded)
    print(f"  Test: '{test_text}' -> {encoded} -> '{decoded}'")

    # 3. Pinyin vocab (without tone)
    print("\n[3] Building pinyin vocabulary (with_tone=False) ...")
    py_tok = PinyinTokenizer(with_tone=False)
    py_tok.build_from_texts(texts)
    py_path = os.path.join(OUTPUT_DIR, "pinyin_vocab.json")
    py_tok.save_vocab(py_path)
    print(f"  Pinyin vocab size: {py_tok.vocab_size}")
    print(f"  Saved: {py_path}")
    encoded = py_tok.encode(test_text)
    decoded = py_tok.decode(encoded)
    print(f"  Test: '{test_text}' -> {encoded} -> '{decoded}'")

    # 4. Pinyin vocab (with tone) — for ctc_2
    print("\n[4] Building pinyin vocabulary (with_tone=True) ...")
    py_tone_tok = PinyinTokenizer(with_tone=True)
    py_tone_tok.build_from_texts(texts)
    py_tone_path = os.path.join(OUTPUT_DIR, "pinyin_tone_vocab.json")
    py_tone_tok.save_vocab(py_tone_path)
    print(f"  Pinyin (tone) vocab size: {py_tone_tok.vocab_size}")
    print(f"  Saved: {py_tone_path}")
    encoded = py_tone_tok.encode(test_text)
    decoded = py_tone_tok.decode(encoded)
    print(f"  Test: '{test_text}' -> {encoded} -> '{decoded}'")

    # Summary
    print("\n" + "=" * 60)
    print("Vocabulary Summary")
    print("=" * 60)
    print(f"  Phoneme (initial+final, tone):  {ph_tok.vocab_size:>6} tokens  -> {ph_path}")
    print(f"  Character:                      {ch_tok.vocab_size:>6} tokens  -> {ch_path}")
    print(f"  Pinyin (no tone):               {py_tok.vocab_size:>6} tokens  -> {py_path}")
    print(f"  Pinyin (with tone):             {py_tone_tok.vocab_size:>6} tokens  -> {py_tone_path}")
    print(f"  SPM-8000:                       {8000:>6} tokens  -> (already built)")
    print(f"\nAll vocabs saved to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
