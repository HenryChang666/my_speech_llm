"""
Phase 1 Trainer: SpeechEncoder + AlignmentAdapter, supervised only by CTC loss.

CTC loss setup:
    - blank = audio_patch_token = 128256  (matches Soundwave exactly)
    - Input to ctc_loss: log_probs [T', B, V]  (time-first)
    - input_lengths: valid encoder output frames per sample [B]
    - targets: ctc_ids [B, L_max]  (pure transcription tokens, no BOS/EOS)
    - target_lengths: ctc_lengths [B]

Multi-GPU: uses torch.nn.parallel.DistributedDataParallel when launched with torchrun.
"""

import os
import math
import time
import logging
from contextlib import nullcontext
from typing import Dict, Any, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.utils.data import DataLoader
from torch.amp import GradScaler, autocast

from models.encoder import SpeechEncoder
from models.alignment_adapter import AlignmentAdapter
from training.wer import compute_cer

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CTC loss helper
# ---------------------------------------------------------------------------

def ctc_loss(
    ctc_logits: torch.Tensor,       # [B, T', V]
    input_lengths: torch.Tensor,    # [B]  valid T' per sample
    ctc_ids: torch.Tensor,          # [B, L_max]  padded token ids
    ctc_lengths: torch.Tensor,      # [B]  valid L per sample
    blank_id: int,
) -> torch.Tensor:
    """Compute CTC loss, matching Soundwave's exact formulation."""
    B = ctc_logits.size(0)

    # log_softmax then transpose to [T', B, V] for F.ctc_loss
    log_probs = F.log_softmax(ctc_logits, dim=-1).transpose(0, 1)  # [T', B, V]

    # F.ctc_loss expects targets as a flat 1-D tensor (concatenated, no padding)
    # OR as a [B, L_max] 2-D tensor (with reduction done per-sample).
    # We use the 2-D form — PyTorch supports it when target_lengths is provided.
    with torch.backends.cudnn.flags(enabled=False):
        loss = F.ctc_loss(
            log_probs,
            ctc_ids,
            input_lengths,
            ctc_lengths,
            blank=blank_id,
            reduction="mean",
            zero_infinity=True,
        )
    return loss


# ---------------------------------------------------------------------------
# Trainer
# ---------------------------------------------------------------------------

class Phase1Trainer:
    """Trains SpeechEncoder + AlignmentAdapter with CTC loss only.

    Expected cfg keys:
        encoder:
            input_dim, conv_channels, embed_dim, conv_kernel_sizes,
            num_layers, num_heads, ffn_dim, dropout
        adapter:
            llm_hidden_size, llm_num_heads, vocab_size, ffn_multiplier, dropout
        training:
            lr, weight_decay, warmup_steps, max_steps,
            grad_clip, log_every, save_every, eval_every,
            accum_steps, fp16
        ctc_blank_id : int
        output_dir   : str
    """

    def __init__(self, cfg: Dict[str, Any], local_rank: int = 0, tokenizer=None):
        self.cfg = cfg
        self.local_rank = local_rank
        self.is_main = (local_rank == 0)
        self.device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
        self.output_dir = cfg["output_dir"]
        self.blank_id = cfg.get("ctc_blank_id", 128256)   # audio_patch_token
        self.tokenizer = tokenizer
        if self.is_main:
            os.makedirs(self.output_dir, exist_ok=True)
        self._setup_logging()
        self._build_model()
        self._build_optimizer()
        self.scaler = GradScaler("cuda", enabled=cfg["training"].get("fp16", True))
        self.global_step = 0
        self.best_val_loss = float("inf")

    # ------------------------------------------------------------------
    def _setup_logging(self):
        if not self.is_main:
            return
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(os.path.join(self.output_dir, "train.log")),
            ],
        )

    # ------------------------------------------------------------------
    def _build_model(self):
        ec = self.cfg["encoder"]
        ac = self.cfg["adapter"]

        self.encoder = SpeechEncoder(
            input_dim=ec.get("input_dim", 80),
            conv_channels=ec.get("conv_channels", 1024),
            embed_dim=ec.get("embed_dim", 512),
            conv_kernel_sizes=tuple(ec.get("conv_kernel_sizes", [5, 5])),
            num_layers=ec.get("num_layers", 12),
            num_heads=ec.get("num_heads", 8),
            ffn_dim=ec.get("ffn_dim", 2048),
            dropout=ec.get("dropout", 0.15),
        ).to(self.device)

        self.adapter = AlignmentAdapter(
            encoder_dim=ec.get("embed_dim", 512),
            llm_hidden_size=ac["llm_hidden_size"],
            llm_num_heads=ac["llm_num_heads"],
            vocab_size=ac["vocab_size"],
            ffn_multiplier=ac.get("ffn_multiplier", 2),
            dropout=ac.get("dropout", 0.1),
            audio_patch_token=self.cfg.get("ctc_blank_id", 128256),
        ).to(self.device)

        # Weight tying: load LLM embed_tokens if path provided, else skip
        # (can be tied later when LLM is available for Phase 2)
        llm_embed_path = self.cfg.get("llm_embed_weights_path")
        if llm_embed_path and os.path.exists(llm_embed_path):
            logger.info(f"Tying CTC weights from {llm_embed_path}")
            embed_w = torch.load(llm_embed_path, map_location=self.device)
            # embed_w must be on the same device as the adapter before tying
            self.adapter.tie_ctc_weights(embed_w)
        else:
            logger.info("No LLM embed weights path provided — CTC head uses random init")

        # Wrap with DDP if distributed
        if dist.is_available() and dist.is_initialized():
            self.encoder = nn.parallel.DistributedDataParallel(
                self.encoder, device_ids=[self.local_rank]
            )
            self.adapter = nn.parallel.DistributedDataParallel(
                self.adapter, device_ids=[self.local_rank]
            )
            logger.info(f"DDP enabled on rank {self.local_rank}")
        # NOTE: DataParallel is intentionally NOT used here.
        # DataParallel splits the batch across GPUs but the fbank tensors are
        # already padded to the full-batch maximum length, so padding_mask dims
        # mismatch on sub-replicas.  Use torchrun + DDP for multi-GPU instead.

        n_enc = sum(p.numel() for p in self.encoder.parameters() if p.requires_grad)
        n_ada = sum(p.numel() for p in self.adapter.parameters() if p.requires_grad)
        if self.is_main:
            logger.info(f"Encoder params: {n_enc/1e6:.1f}M")
            logger.info(f"Adapter params: {n_ada/1e6:.1f}M")

    # ------------------------------------------------------------------
    def _build_optimizer(self):
        tc = self.cfg["training"]
        params = list(self.encoder.parameters()) + list(self.adapter.parameters())
        self.optimizer = torch.optim.AdamW(
            params,
            lr=tc["lr"],
            betas=(0.9, 0.98),
            weight_decay=tc.get("weight_decay", 0.01),
        )
        # Inverse sqrt schedule with linear warmup (matches fairseq convention).
        # last_epoch=-1 is the default; we call scheduler.step() AFTER optimizer.step()
        # at each update step.  To silence the PyTorch "step before optimizer" warning
        # that fires when GradScaler.step() wraps optimizer.step(), we set last_epoch=0
        # and call step() only after the first real update.
        warmup = tc.get("warmup_steps", 4000)

        def lr_lambda(step: int) -> float:
            # step here is 0-indexed (scheduler counts from 0 after construction)
            step = step + 1   # make it 1-indexed to avoid division by zero
            if step < warmup:
                return float(step) / float(warmup)
            return math.sqrt(warmup / step)

        self.scheduler = torch.optim.lr_scheduler.LambdaLR(
            self.optimizer, lr_lambda, last_epoch=-1
        )

    # ------------------------------------------------------------------
    def _forward_step(self, batch: Dict) -> torch.Tensor:
        fbank = batch["fbank"].to(self.device)              # [B, T, 80]
        fbank_lengths = batch["fbank_lengths"].to(self.device)  # [B]
        ctc_ids = batch["ctc_ids"].to(self.device)          # [B, L_max]
        ctc_lengths = batch["ctc_lengths"].to(self.device)  # [B]

        amp_ctx = autocast("cuda", dtype=torch.float16) if self.cfg["training"].get("fp16", True) else nullcontext()

        with amp_ctx:
            # Encode
            enc_out, out_lengths, pad_mask = self.encoder(fbank, fbank_lengths)
            # [B, T', 512], [B], [B, T']

            # Align + CTC logits
            aligned, ctc_logits = self.adapter(enc_out, pad_mask)
            # [B, T', 4096], [B, T', vocab]

            # CTC loss
            loss = ctc_loss(
                ctc_logits,
                out_lengths,
                ctc_ids,
                ctc_lengths,
                blank_id=self.cfg["ctc_blank_id"],
            )

        return loss

    # ------------------------------------------------------------------
    def train(self, train_loader: DataLoader, val_loader: Optional[DataLoader] = None, test_loader: Optional[DataLoader] = None):
        """Main training loop.
        
        Args:
            train_loader: training data loader
            val_loader:   validation data loader (optional)
            test_loader:  test data loader for final evaluation (optional)
        """
        tc = self.cfg["training"]
        max_steps = tc["max_steps"]
        accum = tc.get("accum_steps", 1)
        log_every = tc.get("log_every", 100)
        save_every = tc.get("save_every", 1000)
        eval_every = tc.get("eval_every", 1000)

        # Estimate steps per epoch
        train_batches_per_epoch = len(train_loader)
        steps_per_epoch = math.ceil(train_batches_per_epoch / accum)
        total_epochs = max_steps / steps_per_epoch

        self.encoder.train()
        self.adapter.train()
        self.optimizer.zero_grad()

        step_loss_sum = 0.0
        t0 = time.time()

        if self.is_main:
            logger.info(f"Starting Phase 1 training — max_steps={max_steps} (~{total_epochs:.1f} epochs)")

        loader_iter = iter(train_loader)
        micro_step = 0

        while self.global_step < max_steps:
            # Fetch next batch (cycle through loader)
            try:
                batch = next(loader_iter)
            except StopIteration:
                loader_iter = iter(train_loader)
                batch = next(loader_iter)

            if batch is None:
                continue

            # Forward
            loss = self._forward_step(batch)
            loss_val = loss.item()

            # Backward (scaled)
            self.scaler.scale(loss / accum).backward()
            step_loss_sum += loss_val
            micro_step += 1

            if micro_step % accum != 0:
                continue

            # Gradient clipping
            self.scaler.unscale_(self.optimizer)
            nn.utils.clip_grad_norm_(
                list(self.encoder.parameters()) + list(self.adapter.parameters()),
                tc.get("grad_clip", 1.0),
            )

            # optimizer.step() is called inside scaler.step(); scheduler must
            # be stepped after to avoid the "step before optimizer" warning.
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad()
            self.global_step += 1
            self.scheduler.step()  # always after optimizer.step()

            # Logging with epoch progress
            if self.is_main and self.global_step % log_every == 0:
                avg_loss = step_loss_sum / log_every
                step_loss_sum = 0.0
                lr = self.optimizer.param_groups[0]["lr"]
                elapsed = time.time() - t0
                
                # Compute current epoch
                current_epoch = self.global_step / steps_per_epoch
                
                logger.info(
                    f"step={self.global_step:6d}/{max_steps} "
                    f"({current_epoch:.1f}/{total_epochs:.1f} epochs) "
                    f"loss={avg_loss:.4f}  "
                    f"lr={lr:.2e}  elapsed={elapsed:.0f}s"
                )
                t0 = time.time()

            # Evaluation on test set (during training)
            if test_loader is not None and self.global_step % eval_every == 0:
                test_metrics = self.evaluate(test_loader, split_name="test")
                if self.is_main:
                    logger.info(
                        f"  [eval] step={self.global_step}  "
                        f"test_loss={test_metrics['loss']:.4f}  "
                        f"test_cer={test_metrics['cer']:.2f}%  "
                        f"samples={test_metrics['samples']}"
                    )
                    # Save best based on test CER (lower is better)
                    if test_metrics['cer'] < self.best_val_loss:
                        self.best_val_loss = test_metrics['cer']
                        self.save_checkpoint("best")
                self.encoder.train()
                self.adapter.train()

            # Periodic checkpoint
            if self.is_main and self.global_step % save_every == 0:
                self.save_checkpoint(f"step_{self.global_step}")

        # Final evaluation on test set
        if test_loader is not None and self.is_main:
            logger.info("Running final evaluation on test set...")
            test_metrics = self.evaluate(test_loader, split_name="test")
            logger.info(
                f"  [TEST] loss={test_metrics['loss']:.4f}  "
                f"cer={test_metrics['cer']:.2f}%  "
                f"samples={test_metrics['samples']}"
            )
            self.save_checkpoint("final_with_test")

        if self.is_main:
            logger.info("Training finished. Saving final checkpoint.")
            self.save_checkpoint("final")

    # ------------------------------------------------------------------
    @torch.no_grad()
    def evaluate(self, val_loader: DataLoader, split_name: str = "validation") -> Dict[str, float]:
        """Evaluate on validation/test set. Returns loss and CER."""
        self.encoder.eval()
        self.adapter.eval()
        total_loss, n_batches = 0.0, 0
        all_preds, all_refs = [], []

        # Aim for ~20 printed samples regardless of dataset size.
        # Estimate total batches from loader length; print the first sample
        # of every print_interval-th batch.
        total_batches_est = len(val_loader)
        TARGET_PRINTS = 20
        print_interval = max(1, total_batches_est // TARGET_PRINTS)
        log_samples = []

        for batch_idx, batch in enumerate(val_loader):
            if batch is None:
                continue
            fbank = batch["fbank"].to(self.device)
            fbank_lengths = batch["fbank_lengths"].to(self.device)
            ctc_ids = batch["ctc_ids"].to(self.device)
            ctc_lengths = batch["ctc_lengths"].to(self.device)
            texts = batch["texts"]

            enc_out, out_lengths, pad_mask = self.encoder(fbank, fbank_lengths)
            aligned, ctc_logits = self.adapter(enc_out, pad_mask)

            loss = ctc_loss(
                ctc_logits,
                out_lengths,
                ctc_ids,
                ctc_lengths,
                blank_id=self.blank_id,
            )
            total_loss += loss.item()
            n_batches += 1

            # CTC greedy decode: argmax → remove blank (128256) → remove consecutive dups
            preds = ctc_logits.argmax(dim=-1)  # [B, T']
            for i in range(preds.size(0)):
                pred_ids = preds[i][:out_lengths[i]].tolist()
                # Remove blank tokens (audio_patch_token = 128256)
                pred_ids = [t for t in pred_ids if t != self.blank_id]
                # Remove consecutive duplicates (CTC collapse)
                decoded_ids, prev = [], -1
                for t in pred_ids:
                    if t != prev:
                        decoded_ids.append(t)
                        prev = t
                # Clamp to valid vocab range
                valid_ids = [t for t in decoded_ids if t < self.tokenizer.vocab_size] \
                    if self.tokenizer is not None else decoded_ids
                if self.tokenizer is not None:
                    try:
                        pred_text = self.tokenizer.decode(valid_ids, skip_special_tokens=True)
                    except Exception:
                        pred_text = ""
                else:
                    pred_text = str(valid_ids)

                all_preds.append(pred_text)
                all_refs.append(texts[i])

                # Print first sample of every print_interval-th batch
                if i == 0 and (batch_idx % print_interval == 0):
                    log_samples.append((texts[i], pred_text))

        avg_loss = total_loss / max(n_batches, 1)
        cer = compute_cer(all_preds, all_refs)

        # Log REF + HYP pairs
        if self.is_main and log_samples:
            logger.info(
                f"  [{split_name}] CTC predictions @ step {self.global_step} "
                f"({len(log_samples)} samples, 1 per {print_interval} batches):"
            )
            for ref, hyp in log_samples:
                logger.info(f"    REF: {ref}")
                logger.info(f"    HYP: {hyp if hyp else '(empty)'}")
                logger.info(f"    ---")

        return {"loss": avg_loss, "cer": cer, "samples": len(all_preds)}

    # ------------------------------------------------------------------
    def save_checkpoint(self, tag: str):
        """Save encoder + adapter state dicts."""
        # Unwrap DDP/DataParallel
        enc_state = (self.encoder.module if hasattr(self.encoder, "module") else self.encoder).state_dict()
        ada_state = (self.adapter.module if hasattr(self.adapter, "module") else self.adapter).state_dict()

        path = os.path.join(self.output_dir, f"ckpt_{tag}.pt")
        torch.save({
            "global_step": self.global_step,
            "encoder": enc_state,
            "adapter": ada_state,
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "scaler": self.scaler.state_dict(),
            "best_val_loss": self.best_val_loss,
            "cfg": self.cfg,
        }, path)
        logger.info(f"Saved checkpoint → {path}")

    # ------------------------------------------------------------------
    def load_checkpoint(self, path: str):
        """Resume from a checkpoint."""
        ckpt = torch.load(path, map_location=self.device)
        enc = self.encoder.module if hasattr(self.encoder, "module") else self.encoder
        ada = self.adapter.module if hasattr(self.adapter, "module") else self.adapter
        enc.load_state_dict(ckpt["encoder"])
        ada.load_state_dict(ckpt["adapter"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.scheduler.load_state_dict(ckpt["scheduler"])
        self.scaler.load_state_dict(ckpt["scaler"])
        self.global_step = ckpt["global_step"]
        self.best_val_loss = ckpt.get("best_val_loss", float("inf"))
        logger.info(f"Resumed from {path} at step {self.global_step}")
