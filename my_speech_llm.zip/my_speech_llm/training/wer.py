"""
CER (Character Error Rate) for Chinese ASR evaluation.

For Chinese, WER is inappropriate because there are no word boundaries (spaces).
Each character is the minimal unit, so CER is the correct metric.

CER = (substitutions + deletions + insertions) / num_reference_characters
    = edit_distance(ref_chars, hyp_chars) / len(ref_chars)

We implement this directly with Python's difflib to avoid jiwer's word-splitting
assumption that breaks on Chinese.
"""
from typing import List


def _edit_distance(a: List, b: List) -> int:
    """Standard dynamic programming edit distance."""
    m, n = len(a), len(b)
    # Use two rows to save memory
    prev = list(range(n + 1))
    curr = [0] * (n + 1)
    for i in range(1, m + 1):
        curr[0] = i
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                curr[j] = prev[j - 1]
            else:
                curr[j] = 1 + min(prev[j - 1], prev[j], curr[j - 1])
        prev, curr = curr, prev
    return prev[n]


def compute_cer(predictions: List[str], references: List[str]) -> float:
    """Compute CER (Character Error Rate) for Chinese ASR.

    Each Chinese character is treated as one token.
    Spaces are stripped before comparison so format differences don't matter.

    Args:
        predictions: list of predicted texts
        references:  list of ground truth texts

    Returns:
        CER as percentage (0-100). Returns 100.0 if all references are empty.
    """
    if not predictions or not references:
        return 0.0

    total_dist = 0
    total_ref_chars = 0

    for hyp, ref in zip(predictions, references):
        # Strip spaces — CTC decoder may produce space-separated output
        ref_chars = list(ref.replace(" ", ""))
        hyp_chars = list(hyp.replace(" ", ""))

        if len(ref_chars) == 0:
            # Empty reference: count as 0 errors to avoid division by zero
            continue

        total_dist += _edit_distance(hyp_chars, ref_chars)
        total_ref_chars += len(ref_chars)

    if total_ref_chars == 0:
        return 100.0

    return (total_dist / total_ref_chars) * 100.0


# Keep compute_wer as an alias for backward compatibility
compute_wer = compute_cer


if __name__ == "__main__":
    # Sanity checks
    assert compute_cer(["你好世界"], ["你好世界"]) == 0.0
    assert compute_cer(["你好地界"], ["你好世界"]) == 25.0  # 1 sub / 4 chars
    assert compute_cer(["你好"], ["你好世界"]) == 50.0      # 2 del / 4 chars
    assert compute_cer(["你好世界额外"], ["你好世界"]) == 50.0  # 2 ins / 4 chars
    assert compute_cer([""], ["你好世界"]) == 100.0
    # With spaces (CTC output may have spaces between tokens)
    assert compute_cer(["你 好 世 界"], ["你好世界"]) == 0.0
    print("All CER checks passed!")
