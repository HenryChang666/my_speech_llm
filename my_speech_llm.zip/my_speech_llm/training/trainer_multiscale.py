"""
Multi-scale Phase 1 Trainer.

Trains MultiscaleEncoder + AlignmentAdapter with:
  - Final CTC loss (LLaMA embeddings, weight=1.0)
  - Intermediate CTC losses at configurable encoder layers (configurable weights)

Total loss = adapter_ctc_loss * 1.0 + sum(intermediate_ctc_loss_i * weight_i)

Online tokenization: each intermediate CTC has its own tokenizer.
During eval: greedy-decode and log REF/HYP for every CTC level.
"""

import os
import math
import time
import logging
from contextlib import nullcontext
from typing import Dict, Any, Optional, List

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.utils.data import DataLoader
from torch.amp import GradScaler, autocast

from models.multiscale_encoder import MultiscaleEncoder, validate_interleaved_config
from models.alignment_adapter import AlignmentAdapter
from data.multiscale_tokenizer import BaseTokenizer, build_tokenizer
from training.wer import compute_cer

logger = logging.getLogger(__name__)


# -----------------------------------------------------------------------
# CTC loss helper (reused from baseline trainer)
# -----------------------------------------------------------------------

def ctc_loss_fn(
    ctc_logits: torch.Tensor,       # [B, T, V]
    input_lengths: torch.Tensor,    # [B]
    targets: torch.Tensor,          # [B, L_max]
    target_lengths: torch.Tensor,   # [B]
    blank_id: int,
) -> torch.Tensor:
    log_probs = F.log_softmax(ctc_logits, dim=-1).transpose(0, 1)  # [T, B, V]
    with torch.backends.cudnn.flags(enabled=False):
        loss = F.ctc_loss(
            log_probs, targets, input_lengths, target_lengths,
            blank=blank_id, reduction="mean", zero_infinity=True,
        )
    return loss


# -----------------------------------------------------------------------
# Multi-scale collator: online tokenization for each intermediate CTC
# -----------------------------------------------------------------------

class MultiscaleCollator:
    """Collator that pads fbank/ctc_ids and tokenizes text for each CTC level."""

    def __init__(self, pad_id: int, ctc_tokenizers: Dict[str, BaseTokenizer]):
        self.pad_id = pad_id
        self.ctc_tokenizers = ctc_tokenizers

    def __call__(self, batch):
        from torch.nn.utils.rnn import pad_sequence
        batch = [b for b in batch if b is not None]
        if len(batch) == 0:
            return None

        fbanks = [b["fbank"] for b in batch]
        fbank_lengths = torch.tensor([b["fbank_length"] for b in batch], dtype=torch.long)
        ctc_ids = [b["ctc_ids"] for b in batch]
        ctc_lengths = torch.tensor([b["ctc_length"] for b in batch], dtype=torch.long)
        texts = [b["text"] for b in batch]

        fbank_padded = pad_sequence(fbanks, batch_first=True, padding_value=0.0)
        ctc_padded = pad_sequence(ctc_ids, batch_first=True, padding_value=self.pad_id)

        result = {
            "fbank": fbank_padded,
            "fbank_lengths": fbank_lengths,
            "ctc_ids": ctc_padded,
            "ctc_lengths": ctc_lengths,
            "texts": texts,
        }

        # Online tokenize for each intermediate CTC
        for name, tokenizer in self.ctc_tokenizers.items():
            ids_list = []
            for text in texts:
                ids = tokenizer.encode(text)
                ids_list.append(torch.tensor(ids, dtype=torch.long))
            lengths = torch.tensor([len(ids) for ids in ids_list], dtype=torch.long)
            padded = pad_sequence(ids_list, batch_first=True, padding_value=0)
            result[f"{name}_ids"] = padded
            result[f"{name}_lengths"] = lengths

        return result


# -----------------------------------------------------------------------
# Trainer
# -----------------------------------------------------------------------

class MultiscalePhase1Trainer:
    """Multi-scale CTC trainer.

    Config must include 'interleaved' section with conv_N / ctc_N entries.
    """

    def __init__(self, cfg: Dict[str, Any], local_rank: int = 0,
                 tokenizer=None, ctc_tokenizers: Optional[Dict[str, BaseTokenizer]] = None):
        self.cfg = cfg
        self.local_rank = local_rank
        self.is_main = (local_rank == 0)
        self.device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
        self.output_dir = cfg["output_dir"]
        self.blank_id = cfg.get("ctc_blank_id", 128256)
        self.tokenizer = tokenizer           # LLaMA tokenizer for final CTC
        self.ctc_tokenizers = ctc_tokenizers or {}  # intermediate CTC tokenizers
        if self.is_main:
            os.makedirs(self.output_dir, exist_ok=True)
        self._setup_logging()
        self._build_model()
        self._build_optimizer()
        self.scaler = GradScaler("cuda", enabled=cfg["training"].get("fp16", True))
        self.global_step = 0
        self.best_cer = float("inf")

    def _setup_logging(self):
        if not self.is_main:
            return
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(os.path.join(self.output_dir, "train.log")),
            ],
        )

    def _build_model(self):
        ec = self.cfg["encoder"]
        ac = self.cfg["adapter"]
        num_layers = ec.get("num_layers", 24)

        # Validate and parse interleaved config
        interleaved_cfg = self.cfg.get("interleaved", {})
        self.interleaved_modules = validate_interleaved_config(interleaved_cfg, num_layers)

        if self.is_main:
            logger.info(f"Interleaved modules ({len(self.interleaved_modules)}):")
            for after_layer, mod_type, name, cfg_item in self.interleaved_modules:
                if mod_type == "conv":
                    logger.info(f"  Layer {after_layer}: {name} (stride={cfg_item.get('stride', 2)})")
                else:
                    logger.info(f"  Layer {after_layer}: {name} (weight={cfg_item.get('weight', 0.3)}, "
                                f"tokenizer={cfg_item['tokenizer']['type']})")

        # Build encoder
        self.encoder = MultiscaleEncoder(
            input_dim=ec.get("input_dim", 80),
            conv_channels=ec.get("conv_channels", 1024),
            embed_dim=ec.get("embed_dim", 1280),
            conv_kernel_sizes=tuple(ec.get("conv_kernel_sizes", [5, 5])),
            num_layers=num_layers,
            num_heads=ec.get("num_heads", 20),
            ffn_dim=ec.get("ffn_dim", 5120),
            dropout=ec.get("dropout", 0.1),
            interleaved_modules=self.interleaved_modules,
            ctc_tokenizers=self.ctc_tokenizers,
        ).to(self.device)

        # Build alignment adapter (final CTC, LLaMA embeddings, weight=1.0)
        self.adapter = AlignmentAdapter(
            encoder_dim=ec.get("embed_dim", 1280),
            llm_hidden_size=ac["llm_hidden_size"],
            llm_num_heads=ac["llm_num_heads"],
            vocab_size=ac["vocab_size"],
            ffn_multiplier=ac.get("ffn_multiplier", 2),
            dropout=ac.get("dropout", 0.1),
            audio_patch_token=self.blank_id,
        ).to(self.device)

        # Tie LLM embed weights
        llm_embed_path = self.cfg.get("llm_embed_weights_path")
        if llm_embed_path and os.path.exists(llm_embed_path):
            logger.info(f"Tying CTC weights from {llm_embed_path}")
            embed_w = torch.load(llm_embed_path, map_location=self.device)
            self.adapter.tie_ctc_weights(embed_w)
        else:
            logger.info("No LLM embed weights — adapter CTC head uses random init")

        # DDP
        if dist.is_available() and dist.is_initialized():
            self.encoder = nn.parallel.DistributedDataParallel(
                self.encoder, device_ids=[self.local_rank],
                find_unused_parameters=True,
            )
            self.adapter = nn.parallel.DistributedDataParallel(
                self.adapter, device_ids=[self.local_rank],
            )
            logger.info(f"DDP enabled on rank {self.local_rank}")

        n_enc = sum(p.numel() for p in self.encoder.parameters() if p.requires_grad)
        n_ada = sum(p.numel() for p in self.adapter.parameters() if p.requires_grad)
        if self.is_main:
            logger.info(f"Encoder params: {n_enc/1e6:.1f}M (with interleaved modules)")
            logger.info(f"Adapter params: {n_ada/1e6:.1f}M")

    def _build_optimizer(self):
        tc = self.cfg["training"]
        params = list(self.encoder.parameters()) + list(self.adapter.parameters())
        self.optimizer = torch.optim.AdamW(
            params, lr=tc["lr"],
            betas=(0.9, 0.98),
            weight_decay=tc.get("weight_decay", 0.01),
        )
        warmup = tc.get("warmup_steps", 4000)

        def lr_lambda(step: int) -> float:
            step = step + 1
            if step < warmup:
                return float(step) / float(warmup)
            return math.sqrt(warmup / step)

        self.scheduler = torch.optim.lr_scheduler.LambdaLR(
            self.optimizer, lr_lambda, last_epoch=-1,
        )

    def _get_encoder_module(self):
        return self.encoder.module if hasattr(self.encoder, "module") else self.encoder

    def _forward_step(self, batch: Dict) -> Dict[str, torch.Tensor]:
        """Forward pass returning per-loss dict."""
        fbank = batch["fbank"].to(self.device)
        fbank_lengths = batch["fbank_lengths"].to(self.device)
        ctc_ids = batch["ctc_ids"].to(self.device)
        ctc_lengths = batch["ctc_lengths"].to(self.device)

        amp_ctx = autocast("cuda", dtype=torch.float16) \
            if self.cfg["training"].get("fp16", True) else nullcontext()

        with amp_ctx:
            # Encoder forward (returns intermediate CTC outputs)
            enc_out, out_lengths, pad_mask, inter_ctc_outputs = self.encoder(
                fbank, fbank_lengths,
            )

            # Final CTC via alignment adapter
            aligned, final_ctc_logits = self.adapter(enc_out, pad_mask)
            final_loss = ctc_loss_fn(
                final_ctc_logits, out_lengths, ctc_ids, ctc_lengths,
                blank_id=self.blank_id,
            )

            # Intermediate CTC losses
            losses = {"adapter_ctc": final_loss}
            enc_module = self._get_encoder_module()

            for ctc_name, ctc_data in inter_ctc_outputs.items():
                inter_logits = ctc_data["logits"]    # [B, T, V]
                inter_lengths = ctc_data["lengths"]  # [B]

                # Get targets from batch (online-tokenized by collator)
                inter_ids = batch[f"{ctc_name}_ids"].to(self.device)
                inter_id_lengths = batch[f"{ctc_name}_lengths"].to(self.device)

                # blank_id = vocab_size (last index of this CTC head)
                tokenizer = self.ctc_tokenizers[ctc_name]
                inter_blank = tokenizer.blank_id

                inter_loss = ctc_loss_fn(
                    inter_logits, inter_lengths,
                    inter_ids, inter_id_lengths,
                    blank_id=inter_blank,
                )
                losses[ctc_name] = inter_loss

        return losses

    def _compute_total_loss(self, losses: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Compute weighted total loss.

        adapter_ctc weight = 1.0 (fixed)
        intermediate CTC weights from config
        """
        total = losses["adapter_ctc"] * 1.0

        enc_module = self._get_encoder_module()
        for ctc_name, loss in losses.items():
            if ctc_name == "adapter_ctc":
                continue
            weight = enc_module.ctc_weights.get(ctc_name, 0.3)
            total = total + loss * weight

        return total

    # ------------------------------------------------------------------
    def train(self, train_loader: DataLoader, val_loader=None, test_loader=None):
        tc = self.cfg["training"]
        max_steps = tc["max_steps"]
        accum = tc.get("accum_steps", 1)
        log_every = tc.get("log_every", 100)
        save_every = tc.get("save_every", 1000)
        eval_every = tc.get("eval_every", 1000)

        train_batches_per_epoch = len(train_loader)
        steps_per_epoch = math.ceil(train_batches_per_epoch / accum)
        total_epochs = max_steps / steps_per_epoch

        self.encoder.train()
        self.adapter.train()
        self.optimizer.zero_grad()

        loss_accum = {}  # accumulate per-loss for logging
        t0 = time.time()

        if self.is_main:
            logger.info(f"Starting multi-scale Phase 1 — max_steps={max_steps} "
                        f"(~{total_epochs:.1f} epochs)")

        loader_iter = iter(train_loader)
        micro_step = 0

        while self.global_step < max_steps:
            try:
                batch = next(loader_iter)
            except StopIteration:
                loader_iter = iter(train_loader)
                batch = next(loader_iter)

            if batch is None:
                continue

            # Forward
            losses = self._forward_step(batch)
            total_loss = self._compute_total_loss(losses)

            # Accumulate per-loss stats
            for k, v in losses.items():
                loss_accum[k] = loss_accum.get(k, 0.0) + v.item()
            loss_accum["total"] = loss_accum.get("total", 0.0) + total_loss.item()

            # Backward
            self.scaler.scale(total_loss / accum).backward()
            micro_step += 1

            if micro_step % accum != 0:
                continue

            # Gradient clipping
            self.scaler.unscale_(self.optimizer)
            nn.utils.clip_grad_norm_(
                list(self.encoder.parameters()) + list(self.adapter.parameters()),
                tc.get("grad_clip", 1.0),
            )

            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad()
            self.global_step += 1
            self.scheduler.step()

            # Logging
            if self.is_main and self.global_step % log_every == 0:
                n = log_every
                lr = self.optimizer.param_groups[0]["lr"]
                elapsed = time.time() - t0
                epoch_now = self.global_step / steps_per_epoch

                loss_str = "  ".join(
                    f"{k}={v / n:.4f}" for k, v in sorted(loss_accum.items())
                )
                logger.info(
                    f"step={self.global_step:6d}/{max_steps} "
                    f"({epoch_now:.1f}/{total_epochs:.1f} ep) "
                    f"{loss_str}  lr={lr:.2e}  {elapsed:.0f}s"
                )
                loss_accum = {}
                t0 = time.time()

            # Evaluation
            if test_loader is not None and self.global_step % eval_every == 0:
                metrics = self.evaluate(test_loader, split_name="test")
                if self.is_main:
                    # Log adapter CER + intermediate CERs
                    cer_str = "  ".join(
                        f"{k}_cer={v:.2f}%" for k, v in sorted(metrics["cers"].items())
                    )
                    logger.info(
                        f"  [eval] step={self.global_step}  "
                        f"loss={metrics['loss']:.4f}  {cer_str}"
                    )
                    # Save best based on adapter CER
                    adapter_cer = metrics["cers"].get("adapter_ctc", 100.0)
                    if adapter_cer < self.best_cer:
                        self.best_cer = adapter_cer
                        self.save_checkpoint("best")

                self.encoder.train()
                self.adapter.train()

            # Periodic save
            if self.is_main and self.global_step % save_every == 0:
                self.save_checkpoint(f"step_{self.global_step}")

        if self.is_main:
            logger.info("Training finished. Saving final checkpoint.")
            self.save_checkpoint("final")

    # ------------------------------------------------------------------
    @torch.no_grad()
    def evaluate(self, loader: DataLoader, split_name: str = "test") -> Dict:
        self.encoder.eval()
        self.adapter.eval()

        total_loss, n_batches = 0.0, 0
        # Per-CTC: collect predictions and references
        all_preds = {"adapter_ctc": []}
        all_refs = {"adapter_ctc": []}
        for name in self.ctc_tokenizers:
            all_preds[name] = []
            all_refs[name] = []

        total_batches = len(loader)
        TARGET_PRINTS = 20
        print_interval = max(1, total_batches // TARGET_PRINTS)
        log_samples = {"adapter_ctc": []}
        for name in self.ctc_tokenizers:
            log_samples[name] = []

        for batch_idx, batch in enumerate(loader):
            if batch is None:
                continue

            fbank = batch["fbank"].to(self.device)
            fbank_lengths = batch["fbank_lengths"].to(self.device)
            ctc_ids = batch["ctc_ids"].to(self.device)
            ctc_lengths = batch["ctc_lengths"].to(self.device)
            texts = batch["texts"]

            # Encoder
            enc_out, out_lengths, pad_mask, inter_ctc_outputs = self.encoder(
                fbank, fbank_lengths,
            )

            # Final CTC
            aligned, final_logits = self.adapter(enc_out, pad_mask)
            loss = ctc_loss_fn(
                final_logits, out_lengths, ctc_ids, ctc_lengths,
                blank_id=self.blank_id,
            )
            total_loss += loss.item()
            n_batches += 1

            # Decode adapter CTC (LLaMA tokenizer)
            self._decode_ctc_batch(
                final_logits, out_lengths, texts,
                self.blank_id, self.tokenizer, "adapter_ctc",
                all_preds, all_refs, log_samples, batch_idx, print_interval,
            )

            # Decode intermediate CTCs
            for ctc_name, ctc_data in inter_ctc_outputs.items():
                inter_logits = ctc_data["logits"]
                inter_lengths = ctc_data["lengths"]
                tokenizer = self.ctc_tokenizers[ctc_name]

                self._decode_ctc_batch(
                    inter_logits, inter_lengths, texts,
                    tokenizer.blank_id, tokenizer, ctc_name,
                    all_preds, all_refs, log_samples, batch_idx, print_interval,
                )

        avg_loss = total_loss / max(n_batches, 1)

        # Compute CER for each CTC level
        cers = {}
        for name in all_preds:
            if all_preds[name]:
                cers[name] = compute_cer(all_preds[name], all_refs[name])
            else:
                cers[name] = 100.0

        # Log REF/HYP samples for each CTC level
        if self.is_main:
            for name in sorted(log_samples.keys()):
                samples = log_samples[name]
                if not samples:
                    continue
                logger.info(
                    f"  [{split_name}] {name} predictions @ step {self.global_step} "
                    f"({len(samples)} samples):"
                )
                for ref, hyp in samples[:10]:  # cap at 10
                    logger.info(f"    REF: {ref}")
                    logger.info(f"    HYP: {hyp if hyp else '(empty)'}")
                    logger.info(f"    ---")

        return {"loss": avg_loss, "cers": cers, "samples": len(all_preds["adapter_ctc"])}

    def _decode_ctc_batch(
        self,
        logits: torch.Tensor,          # [B, T, V]
        lengths: torch.Tensor,         # [B]
        texts: List[str],
        blank_id: int,
        tokenizer,                     # BaseTokenizer or HF tokenizer
        name: str,
        all_preds: Dict, all_refs: Dict,
        log_samples: Dict,
        batch_idx: int, print_interval: int,
    ):
        """CTC greedy decode for a single CTC head.
        
        For intermediate CTC layers, both REF and HYP are encoded/decoded using
        the same tokenizer to ensure fair comparison.
        For adapter_ctc (final LLaMA CTC), original Chinese text is used as REF.
        """
        preds = logits.argmax(dim=-1)  # [B, T]
        
        # Distinguish our BaseTokenizer (intermediate CTC) from HuggingFace tokenizer
        # (adapter CTC). BaseTokenizer is identifiable by having a 'blank_id' property.
        is_intermediate_ctc = hasattr(tokenizer, 'blank_id')

        for i in range(preds.size(0)):
            pred_ids = preds[i][:lengths[i]].tolist()
            # Remove blank
            pred_ids = [t for t in pred_ids if t != blank_id]
            # Remove consecutive duplicates
            decoded_ids, prev = [], -1
            for t in pred_ids:
                if t != prev:
                    decoded_ids.append(t)
                    prev = t

            # Decode HYP to text
            if hasattr(tokenizer, 'decode'):
                if is_intermediate_ctc:
                    # Our BaseTokenizer (intermediate CTC)
                    try:
                        pred_text = tokenizer.decode(decoded_ids)
                    except Exception:
                        pred_text = ""
                else:
                    # HuggingFace tokenizer (adapter CTC)
                    valid_ids = [t for t in decoded_ids if t < tokenizer.vocab_size]
                    try:
                        pred_text = tokenizer.decode(valid_ids, skip_special_tokens=True)
                    except Exception:
                        pred_text = ""
            else:
                pred_text = str(decoded_ids)

            # Prepare REF text
            if is_intermediate_ctc:
                # For intermediate CTC: encode then decode to get canonical representation
                try:
                    ref_ids = tokenizer.encode(texts[i])
                    ref_text = tokenizer.decode(ref_ids)
                except Exception:
                    ref_text = texts[i]  # fallback to original
            else:
                # For adapter CTC: use original Chinese text
                ref_text = texts[i]

            all_preds[name].append(pred_text)
            all_refs[name].append(ref_text)

            if i == 0 and (batch_idx % print_interval == 0):
                log_samples[name].append((ref_text, pred_text))

    # ------------------------------------------------------------------
    def save_checkpoint(self, tag: str):
        enc_state = (self.encoder.module if hasattr(self.encoder, "module")
                     else self.encoder).state_dict()
        ada_state = (self.adapter.module if hasattr(self.adapter, "module")
                     else self.adapter).state_dict()
        path = os.path.join(self.output_dir, f"ckpt_{tag}.pt")
        torch.save({
            "global_step": self.global_step,
            "encoder": enc_state,
            "adapter": ada_state,
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "scaler": self.scaler.state_dict(),
            "best_cer": self.best_cer,
            "cfg": self.cfg,
        }, path)
        logger.info(f"Saved checkpoint -> {path}")

    def load_checkpoint(self, path: str):
        ckpt = torch.load(path, map_location=self.device)
        enc = self.encoder.module if hasattr(self.encoder, "module") else self.encoder
        ada = self.adapter.module if hasattr(self.adapter, "module") else self.adapter
        enc.load_state_dict(ckpt["encoder"])
        ada.load_state_dict(ckpt["adapter"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.scheduler.load_state_dict(ckpt["scheduler"])
        self.scaler.load_state_dict(ckpt["scaler"])
        self.global_step = ckpt["global_step"]
        self.best_cer = ckpt.get("best_cer", float("inf"))
        logger.info(f"Resumed from {path} at step {self.global_step}")
