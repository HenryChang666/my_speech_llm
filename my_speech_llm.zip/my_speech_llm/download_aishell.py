#!/usr/bin/env python3
"""下载 AISHELL-1 数据集 (train/dev/test) 到 modelscope 缓存"""

from modelscope.msdatasets import MsDataset

for split in ['train', 'validation', 'test']:
    print(f"Downloading split: {split} ...")
    ds = MsDataset.load(
        'speech_asr/speech_asr_aishell1_trainsets',
        split=split,
        trust_remote_code=True,
    )
    print(f"  {split}: {len(ds)} samples")

print("Done! Data cached at ~/.cache/modelscope/hub/datasets/speech_asr/speech_asr_aishell1_trainsets/")
