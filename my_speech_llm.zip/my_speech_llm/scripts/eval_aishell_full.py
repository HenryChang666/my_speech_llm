#!/usr/bin/env python3
"""
Evaluate SpeechLLM on full AISHELL-1 test set with multi-GPU inference.

Usage:
    # Single GPU
    python eval_aishell_full.py --checkpoint /path/to/checkpoint

    # Multi-GPU
    CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun --nproc_per_node=4 eval_aishell_full.py --checkpoint /path/to/checkpoint
"""
import sys
sys.path.insert(0, '/root/workspace/my_speech_llm')
import os
import argparse

os.environ.setdefault('PHASE1_CHECKPOINT', '/root/workspace/my_speech_llm/checkpoints/phase1_multiscale/ckpt_best.pt')
os.environ.setdefault('FREEZE_ENCODER', 'true')
os.environ.setdefault('FREEZE_ADAPTER', 'true')

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
import json
from tqdm import tqdm

# Initialize distributed
local_rank = int(os.environ.get('LOCAL_RANK', 0))
world_size = int(os.environ.get('WORLD_SIZE', 1))
if world_size > 1:
    dist.init_process_group(backend='nccl')
    torch.cuda.set_device(local_rank)

import swift_speech_llm
import swift_integration.model as speech_model_module
from modelscope.msdatasets import MsDataset
from transformers import AutoTokenizer
from data.dataset import compute_fbank

# Defaults
LLM_PATH = '/root/workspace/models/llama31-8b-instruct'


def parse_args():
    parser = argparse.ArgumentParser(description='Evaluate SpeechLLM on AISHELL-1 test set')
    parser.add_argument('--checkpoint', type=str, required=True,
                        help='Path to LoRA checkpoint directory')
    parser.add_argument('--output', type=str, default=None,
                        help='Output JSON file path (default: results/<checkpoint_name>.json)')
    parser.add_argument('--llm', type=str, default=LLM_PATH,
                        help=f'Base LLM path (default: {LLM_PATH})')
    return parser.parse_args()


def main():
    args = parse_args()
    is_main = local_rank == 0

    # Resolve output path
    if args.output:
        output_file = args.output
    else:
        ckpt_name = os.path.basename(args.checkpoint.rstrip('/'))
        output_file = f'/root/workspace/my_speech_llm/results/{ckpt_name}.json'

    if is_main:
        print(f"Checkpoint: {args.checkpoint}", flush=True)
        print(f"Output: {output_file}", flush=True)
        print("Loading model...", flush=True)

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.llm)

    # Load model directly (bypass InferArguments to avoid DDP issues)
    from swift_integration.model import SpeechLLMConfig, SpeechLLMForCausalLM
    from peft import PeftModel

    # Create config with phase1 checkpoint
    config = SpeechLLMConfig.from_pretrained(args.llm)
    config.phase1_checkpoint = os.environ['PHASE1_CHECKPOINT']
    config.freeze_encoder = True
    config.freeze_adapter = True
    config.ctc_weight = float(os.environ.get('CTC_WEIGHT', '0.3'))
    config.lm_weight = float(os.environ.get('LM_WEIGHT', '1.0'))

    base_model = SpeechLLMForCausalLM.from_pretrained(
        args.llm,
        config=config,
        torch_dtype=torch.bfloat16,
        device_map={'': local_rank},
    )
    model = PeftModel.from_pretrained(base_model, args.checkpoint)
    model = model.merge_and_unload()
    model.eval()

    # Template prefix/suffix for LLaMA format
    # <|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n<audio>语音转文本<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n
    prompt_prefix_ids = tokenizer.encode(
        "<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n", add_special_tokens=False
    )
    # audio placeholder token is 128002
    audio_placeholder_id = 128002
    prompt_suffix_ids = tokenizer.encode(
        "语音转文本<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n", add_special_tokens=False
    )

    if is_main:
        print("Model loaded!", flush=True)
        print(f"World size: {world_size}", flush=True)

    # Load full test set
    if is_main:
        print("Loading AISHELL-1 test set...", flush=True)
    ds = MsDataset.load('speech_asr/speech_asr_aishell1_trainsets', split='test')
    total_samples = len(ds)

    if is_main:
        print(f"Total test samples: {total_samples}", flush=True)

    # Split data across GPUs
    samples_per_gpu = (total_samples + world_size - 1) // world_size
    start_idx = local_rank * samples_per_gpu
    end_idx = min(start_idx + samples_per_gpu, total_samples)
    local_indices = list(range(start_idx, end_idx))

    results = []

    # Process samples one by one (batch generate not supported with dynamic audio insertion)
    for sample_idx in tqdm(range(len(local_indices)), desc=f"GPU {local_rank}", disable=not is_main):
        idx = local_indices[sample_idx]
        item = ds[idx]
        audio_path = item['Audio:FILE']
        ref_text = item['Text:LABEL'].replace(' ', '')

        # Load audio and compute fbank
        fbank = compute_fbank(audio_path)  # [T, 80]

        # Build input_ids
        input_ids_list = prompt_prefix_ids + [audio_placeholder_id] + prompt_suffix_ids
        input_ids = torch.tensor([input_ids_list], dtype=torch.long, device='cuda')
        attention_mask = torch.ones_like(input_ids)
        audios_tensor = fbank.unsqueeze(0).to(device='cuda', dtype=torch.bfloat16)
        audio_lengths = torch.tensor([fbank.shape[0]], dtype=torch.long, device='cuda')

        # Manual autoregressive generation (model.generate doesn't handle
        # attention_mask correctly after audio expansion in KV cache)
        max_new_tokens = 128
        eos_token_id = 128009  # <|eot_id|>
        generated_ids = []

        with torch.no_grad():
            # Step 1: Prefill with audio
            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                audios=audios_tensor,
                audio_lengths=audio_lengths,
                use_cache=True,
            )
            next_token = outputs.logits[0, -1, :].argmax().item()
            generated_ids.append(next_token)
            past_key_values = outputs.past_key_values

            # Step 2: Autoregressive decode
            for _ in range(max_new_tokens - 1):
                if generated_ids[-1] == eos_token_id:
                    break
                cur_len = past_key_values.get_seq_length()
                next_input = torch.tensor([[generated_ids[-1]]], dtype=torch.long, device='cuda')
                new_attn_mask = torch.ones(1, cur_len + 1, dtype=torch.long, device='cuda')
                outputs = model(
                    input_ids=next_input,
                    attention_mask=new_attn_mask,
                    past_key_values=past_key_values,
                    use_cache=True,
                )
                next_token = outputs.logits[0, -1, :].argmax().item()
                generated_ids.append(next_token)
                past_key_values = outputs.past_key_values

        hyp = tokenizer.decode(generated_ids, skip_special_tokens=True)

        # CTC shrink
        ctc_text = ""
        shrink_list = speech_model_module._last_shrink_tokens
        if shrink_list:
            non_blank = shrink_list[0]
            if len(non_blank) > 0:
                try:
                    ctc_text = tokenizer.decode(non_blank.tolist(), skip_special_tokens=True)
                except:
                    ctc_text = str(non_blank.tolist())

        results.append({
            'idx': idx,
            'reference': ref_text,
            'hypothesis': hyp,
            'ctc_shrink': ctc_text,
        })

    # Gather results from all GPUs
    if world_size > 1:
        all_results = [None] * world_size
        dist.all_gather_object(all_results, results)
        results = [r for sub in all_results for r in sub]

    # Main process: compute CER and save
    if is_main:
        # Sort by original index
        results.sort(key=lambda x: x['idx'])

        # Compute CER
        def levenshtein(s1, s2):
            """Compute Levenshtein distance."""
            if len(s1) < len(s2):
                return levenshtein(s2, s1)
            if len(s2) == 0:
                return len(s1)

            prev_row = range(len(s2) + 1)
            for i, c1 in enumerate(s1):
                curr_row = [i + 1]
                for j, c2 in enumerate(s2):
                    insertions = prev_row[j + 1] + 1
                    deletions = curr_row[j] + 1
                    substitutions = prev_row[j] + (c1 != c2)
                    curr_row.append(min(insertions, deletions, substitutions))
                prev_row = curr_row

            return prev_row[-1]

        total_edits = 0
        total_chars = 0
        ctc_total_edits = 0
        ctc_total_chars = 0

        for r in results:
            ref = r['reference']
            hyp = r['hypothesis']
            ctc = r['ctc_shrink']

            edits = levenshtein(ref, hyp)
            total_edits += edits
            total_chars += len(ref)
            r['cer'] = edits / len(ref) if len(ref) > 0 else 0

            ctc_edits = levenshtein(ref, ctc)
            ctc_total_edits += ctc_edits
            ctc_total_chars += len(ref)
            r['ctc_cer'] = ctc_edits / len(ref) if len(ref) > 0 else 0

        cer = total_edits / total_chars if total_chars > 0 else 0
        ctc_cer = ctc_total_edits / ctc_total_chars if ctc_total_chars > 0 else 0

        print(f"\n{'='*50}", flush=True)
        print(f"Total samples: {len(results)}", flush=True)
        print(f"Total characters: {total_chars}", flush=True)
        print(f"LLM  - edits: {total_edits}, CER: {cer:.4f} ({cer*100:.2f}%)", flush=True)
        print(f"CTC  - edits: {ctc_total_edits}, CER: {ctc_cer:.4f} ({ctc_cer*100:.2f}%)", flush=True)
        print(f"{'='*50}", flush=True)

        # Save results
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                'total_samples': len(results),
                'cer': cer,
                'ctc_cer': ctc_cer,
                'total_chars': total_chars,
                'total_edits': total_edits,
                'ctc_total_edits': ctc_total_edits,
                'results': results
            }, f, ensure_ascii=False, indent=2)

        print(f"Results saved to {output_file}", flush=True)

        # Show some examples
        print("\n--- Sample Results ---", flush=True)
        for r in results[:5]:
            print(f"Ref: {r['reference']}", flush=True)
            print(f"Hyp: {r['hypothesis']}", flush=True)
            print(f"CTC: {r['ctc_shrink']}", flush=True)
            print(f"CER: {r['cer']:.4f}  CTC_CER: {r['ctc_cer']:.4f}", flush=True)
            print(flush=True)

    if world_size > 1:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
