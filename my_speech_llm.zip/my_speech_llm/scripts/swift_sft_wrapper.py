#!/usr/bin/env python3
"""
Wrapper script to run swift sft with SpeechLLM model registered.

This script imports swift_speech_llm to register the model type,
then patches the trainer to pass asr_targets for CTC loss.
"""

import sys
import os

# Force add project root to path before any imports
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# Ensure swift_speech_llm is imported to register the model
try:
    import swift_speech_llm
    print(f"[SpeechLLM] swift_speech_llm imported successfully from {swift_speech_llm.__file__}")
except Exception as e:
    print(f"[SpeechLLM] ERROR importing swift_speech_llm: {e}")
    print(f"[SpeechLLM] sys.path = {sys.path}")
    raise

# Import swift modules
from swift.pipelines import sft_main
from swift.trainers.seq2seq_trainer import Seq2SeqTrainer
import torch


def patch_trainer_for_asr_targets():
    """Patch Seq2SeqTrainer to pass asr_targets for CTC loss and log loss_asr."""
    original_compute_loss = Seq2SeqTrainer.compute_loss

    def patched_compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        # Derive asr_targets from labels for CTC loss
        # Filter out special tokens like <|eot_id|> (128009) that are not part of ASR targets
        EOT_ID = 128009
        labels = inputs.get('labels')
        asr_targets = None
        if labels is not None:
            valid_tokens = [row[(row != -100) & (row != EOT_ID)] for row in labels]
            max_len = max(t.size(0) for t in valid_tokens) if valid_tokens else 0
            if max_len > 0:
                asr_targets = torch.full((labels.size(0), max_len), -100, dtype=torch.long, device=labels.device)
                for i, t in enumerate(valid_tokens):
                    asr_targets[i, :t.size(0)] = t

        # Add asr_targets to inputs
        if asr_targets is not None:
            inputs['asr_targets'] = asr_targets

        loss, outputs = original_compute_loss(
            self, model, inputs, return_outputs=True, num_items_in_batch=num_items_in_batch
        )

        # Log loss_asr and loss_lm using swift's custom_metrics
        if getattr(outputs, 'loss_asr', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['loss_asr'].update(outputs.loss_asr)
        if getattr(outputs, 'loss_lm', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['loss_lm'].update(outputs.loss_lm)

        return (loss, outputs) if return_outputs else loss

    Seq2SeqTrainer.compute_loss = patched_compute_loss
    print("[SpeechLLM] Patched Seq2SeqTrainer for loss_asr logging")


if __name__ == "__main__":
    patch_trainer_for_asr_targets()
    sft_main()
