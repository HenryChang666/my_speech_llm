# SpeechLLM Token 设计说明

## 基本事实

LLaMA-3.1 词表大小是 **128256**，有一批预留 token：
- `128000`: `<|begin_of_text|>`
- `128001`: `<|end_of_text|>`
- `128002`: `<|reserved_special_token_0|>` ← Phase 2 用这个做 placeholder
- `128009`: `<|eot_id|>`
- ...

**全程没有扩展词表**，`lm_head` 输出维度始终是 128256。

---

## 三个 Token 的职责

| Token | 值 | 阶段 | 用途 |
|---|---|---|---|
| `audio_placeholder_token` | **128002** | Phase 2 | 在 `input_ids` 中占位，forward 时被替换为音频特征向量 |
| `ctc_blank_token` | **128256** | Phase 1 & 2 | 仅作为 CTC loss 的 blank 索引，**不在词表中**，不参与 embedding |
| CTC 输出词表 | **0~128255** | Phase 1 | adapter 的 CTC head 输出维度，对应字符/subword 的 id |

---

## Phase 1 链路

```
fbank → SpeechEncoder → AlignmentAdapter
                              ↓
                    ctc_logits: [B, T, 128256]   # CTC head 输出
                              ↓
                    CTC loss(blank=128256)        # 128256 作为 blank 索引
                                                  # 超出词表但无所谓，只是数字
```

Phase 1 训练的 adapter 的 CTC head 输出维度是 **128256**（与 LLaMA 词表大小一致），
`blank=128256` 是第 128257 个位置，超出词表范围，但 CTC loss 允许这样做，不需要对应任何 embedding。

---

## Phase 2 链路

```
input_ids: [..., 128002, ...]        # 1个 placeholder（在词表内）
    ↓ embed_tokens 查表
inputs_embeds: [..., vec_128002, ...]
    ↓ 音频分支并行处理
fbank → encoder → adapter → ctc_shrink(blank=128256) → audio_feats: [N, 4096]
    ↓ 替换 placeholder
inputs_embeds: [..., audio_feats×N, ...]   # 1个位置扩展为N个音频特征
    ↓ LLaMA forward
logits: [B, L+N-1, 128256]          # lm_head 输出 128256 维，不变
```

---

## 容易误解的点

### 1. ctc_blank_token=128256 超出词表没关系

CTC loss 的 blank 是纯数字索引，不需要对应词表中的 token，永远不会被 embed 或 decode。
早期错误地认为需要 `resize_token_embeddings(128257)` 来"容纳"它——这是错的，
resize 会给 `lm_head` 多加一个随机初始化的维度，破坏原有训练好的权重。

### 2. Phase 1 的 CTC head 输出维度 128256 和词表大小相同，纯属巧合设计

两者数值相等，但含义不同：词表是 LLaMA 的 subword token 集合，CTC head 的 128256
是 adapter 训练时指定的输出大小（为了复用 LLM embedding 权重做 tie weights）。
blank=128256 超出这个范围作为专用 blank，不干扰任何字符 token。

### 3. audio_placeholder_token 必须在词表内

128002 是已有的 reserved token，`embed_tokens` 能正常查表。
`tokenizer.decode` 时会被 `skip_special_tokens=True` 过滤，不影响文本解码。

### 4. `<|audio_patch|>` 字符串的历史遗留 bug

早期 `replace_tag` 返回字符串 `<|audio_patch|>`，被 tokenizer 编码成 **6 个 token**，
然后 `_encode` 中替换回 1 个 128002。但**只更新了 `input_ids`，没有同步更新 `labels`**，
导致两者长度差 5，label 展开后超出 logits 长度被截断，丢失转录内容。

**修复**：`replace_tag` 直接返回 `[[128002]]`，从源头就是 1 个 token，
`input_ids` 和 `labels` 天然对齐。

```python
# 错误的做法（历史遗留）
def replace_tag(self, ...):
    return ['<|audio_patch|>']  # 会被 tokenizer 编成 6 个 token

# 正确的做法
def replace_tag(self, ...):
    return [[128002]]  # 直接返回 token id，Context = Union[str, List[int]]
```

---

## Phase 2 训练铁律：只训 LLM，不训 encoder/adapter

Phase 2 的训练目标是让 LLM 学会理解音频特征，**encoder 和 alignment adapter 的权重来自 Phase 1，在 Phase 2 中必须冻结**。

- `freeze_encoder = True`：encoder 冻结
- `freeze_adapter = True`：alignment adapter 冻结
- 只有 LLM 的 LoRA 权重参与训练

**原因**：
1. PEFT（LoRA）只保存 LLM 的 LoRA 权重，不保存 encoder/adapter 的权重
2. 如果 `freeze_adapter=False`，adapter 权重会在训练中更新，但更新后的权重**不会被 checkpoint 保存**
3. 推理时从 phase1 原始 ckpt 重新加载 adapter，用的是训练前的旧权重，导致训练和测试不一致，loss 差距巨大

```yaml
# 正确配置
freeze_vit: true        # 冻结 encoder
freeze_aligner: true    # 冻结 alignment adapter

# 错误配置（会导致训练/测试不一致）
freeze_aligner: false
```

---

## freeze 模块必须设为 eval 模式

**血泪教训**：`requires_grad=False` 只冻结梯度，**不会关闭 dropout**！

训练时整个模型处于 `train()` 模式，被 freeze 的 encoder/adapter 仍然会有 dropout 随机丢弃，导致：

1. 同样的输入 fbank，每次 forward 输出的特征都不同
2. 训练时和测试时特征不一致（train 模式 dropout 生效，eval 模式不生效）
3. `loss_asr` 每个 step 波动（本应稳定，因为 encoder/adapter 权重没变）

**症状**：训练 loss 很低，测试 loss 差距巨大，排查发现 encoder 输出就开始不一致。

**修复**：freeze 时必须同时调用 `.eval()` 关闭 dropout，**并且重写 `train()` 方法**：

```python
# 错误的做法（只冻结梯度，dropout 仍然生效）
if self.config.freeze_encoder:
    for param in self.encoder.parameters():
        param.requires_grad = False
    # 忘了 eval()，dropout 仍然会在训练时随机丢弃！

# 正确的做法
if self.config.freeze_encoder:
    for param in self.encoder.parameters():
        param.requires_grad = False
    self.encoder.eval()  # 关闭 dropout，确保输出确定性

if self.config.freeze_adapter:
    for param in self.adapter.parameters():
        param.requires_grad = False
    self.adapter.eval()  # 同理

# 重要：重写 train() 方法，防止被父类覆盖
def train(self, mode: bool = True):
    super().train(mode)
    # train() 会递归设置所有子模块，需要恢复 freeze 模块的 eval 状态
    if self._phase1_loaded:
        if self.config.freeze_encoder and self.encoder is not None:
            self.encoder.eval()
        if self.config.freeze_adapter and self.adapter is not None:
            self.adapter.eval()
    return self
```

**原因**：`model.train()` 会递归地把所有子模块设为 train 模式，包括刚设为 eval 的 encoder/adapter！必须重写 `train()` 方法来保持 eval 状态。

**验证方法**：用同一条数据，分别跑 train 模式和 eval 模式，对比 encoder 输出是否一致。

**正确行为的标志**：`loss_asr` 在每个训练 step 完全一致（因为 encoder/adapter 冻结且 eval，输入相同则输出相同，CTC loss 必然相同）。如果 `loss_asr` 波动，说明 dropout 还在生效，freeze 没有正确设置。

---

## 音频 token 插入后 attention_mask 必须同步更新

**血泪教训**：音频插入改变了序列长度，attention_mask 必须同步调整！

当 placeholder(1个) 被替换为 音频 token(N个) 时：
- `inputs_embeds`: 长度从 L 变成 L - 1 + N
- `attention_mask`: 必须在音频位置插入 N 个 1

**错误做法**：只对原始 mask 做 padding，不插入音频位置的 mask
```python
# 错误：音频位置的 mask=0，被当作 padding 忽略
padded_masks = F.pad(mask, (0, max_new_len - mask.shape[0]), value=0)
```

**正确做法**：拼接时同步更新 mask
```python
# 正确：音频位置的 mask=1
before_mask = cur_mask[:audio_pos]
after_mask = cur_mask[audio_pos + 1:]
audio_mask = torch.ones(v, dtype=cur_mask.dtype, device=cur_mask.device)
cur_new_mask = torch.cat([before_mask, audio_mask, after_mask], dim=0)
```

**症状**：如果 audio token 的 mask=0，LLM 会忽略这些 token，音频信息完全无效，模型无法学会音频-文本对齐。

---

## CTC loss 必须使用实际长度，不是 padding 后的长度

**问题**：batch 中每个样本的音频长度不同，`audio_features` 被 padding 到相同长度。如果 CTC loss 直接用 `audio_features.shape[1]` 作为 `input_lengths`，会导致 padding 部分也参与 loss 计算。

**正确做法**：传递 encoder 输出的实际长度 `out_lengths`，用于 CTC loss：

```python
# 错误：使用 padding 后的长度
input_lengths = torch.full(
    size=(audio_features.shape[0],),
    fill_value=audio_features.shape[1],  # 这是 padding 后的长度！
)

# 正确：使用实际长度
return_state["audio_feature_lengths"] = out_lengths  # 从 model 传递
input_lengths = audio_feature_lengths  # 实际长度
```

**验证方法**：用同一条数据，分别跑 train 模式和 eval 模式，对比 encoder 输出是否一致。
