#!/bin/bash
# Batch evaluate checkpoints across multiple versions

BASE=/root/workspace/my_speech_llm/checkpoints/phase2_lora_aishell1
VERSIONS=(v1-20260517-132725)
STEPS=(6000 8000 10000 12000 14000)

for ver in "${VERSIONS[@]}"; do
    for step in "${STEPS[@]}"; do
        ckpt="${BASE}/${ver}/checkpoint-${step}"
        if [ ! -d "$ckpt" ]; then
            echo "[SKIP] Not found: $ckpt"
            continue
        fi
        echo "========================================"
        echo "[EVAL] ${ver}/checkpoint-${step}"
        echo "========================================"
        bash /root/workspace/my_speech_llm/scripts/run_eval_full.sh "$ckpt"
    done
done

echo "All done."
