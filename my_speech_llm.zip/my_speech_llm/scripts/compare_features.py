#!/usr/bin/env python3
"""Compare LLM input features between train and test."""
import torch

print("Loading saved features...")
train_data = torch.load('/root/workspace/my_speech_llm/debug_train_llm_input.pt')
test_data = torch.load('/root/workspace/my_speech_llm/debug_test_llm_input.pt')

print("\n=== Train Features ===")
print(f"inputs_embeds shape: {train_data['inputs_embeds'].shape}")
print(f"label_adjustments: {train_data['label_adjustments']}")

print("\n=== Test Features ===")
print(f"inputs_embeds shape: {test_data['inputs_embeds'].shape}")
print(f"label_adjustments: {test_data['label_adjustments']}")

# Compare
train_embeds = train_data['inputs_embeds']
test_embeds = test_data['inputs_embeds']

if train_embeds.shape == test_embeds.shape:
    diff = (train_embeds - test_embeds).abs()
    print(f"\n=== Comparison ===")
    print(f"Shape match: YES")
    print(f"Max difference: {diff.max().item():.6f}")
    print(f"Mean difference: {diff.mean().item():.6f}")
    print(f"Features identical: {'YES' if diff.max().item() < 1e-5 else 'NO'}")
else:
    print(f"\n=== Comparison ===")
    print(f"Shape match: NO")
    print(f"Train: {train_embeds.shape}, Test: {test_embeds.shape}")
