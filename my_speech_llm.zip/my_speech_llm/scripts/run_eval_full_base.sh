#!/bin/bash
# Evaluate SpeechLLM on full AISHELL-1 test set with multi-GPU
#
# Usage:
#   bash run_eval_full.sh /path/to/checkpoint
#   bash run_eval_full.sh /path/to/checkpoint /path/to/output.json

export PYTHONPATH=/root/workspace/my_speech_llm:$PYTHONPATH
export PHASE1_CHECKPOINT=/root/workspace/my_speech_llm/checkpoints/phase1/ckpt_best.pt
export FREEZE_ENCODER=true
export FREEZE_ADAPTER=true

CHECKPOINT=${1:?Usage: bash run_eval_full.sh <checkpoint_path> [output_path]}

NUM_GPUS=8

CKPT_NAME=$(basename "${CHECKPOINT%/}")
OUTPUT=${2:-/root/workspace/my_speech_llm/results/$(echo "$CKPT_NAME" | sed 's/checkpoint-/checkpoint-base-/').json}
EXTRA_ARGS="--output $OUTPUT"

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
torchrun --nproc_per_node=$NUM_GPUS --master_port=29501 \
    /root/workspace/my_speech_llm/scripts/eval_aishell_full.py \
    --checkpoint "$CHECKPOINT" \
    $EXTRA_ARGS
