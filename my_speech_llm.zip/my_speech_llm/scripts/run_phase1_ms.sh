#!/usr/bin/env bash
# Phase 1 training launcher with auto-resume support
# Supports both baseline and multiscale models.
#
# Usage:
#   Baseline (default):
#     bash scripts/run_phase1.sh
#
#   Multiscale:
#     MODEL_TYPE=multiscale bash scripts/run_phase1.sh
#
#   Multi-GPU:
#     NGPU=4 MODEL_TYPE=multiscale bash scripts/run_phase1.sh
#
#   Background (nohup):
#     MODEL_TYPE=multiscale bash scripts/run_phase1.sh nohup
#
#   Force resume:
#     RESUME=/path/to/ckpt.pt bash scripts/run_phase1.sh

set -euo pipefail

NGPU=${NGPU:-8}
MODEL_TYPE=${MODEL_TYPE:-"multiscale"}
RESUME=${RESUME:-""}

# Select config based on MODEL_TYPE
if [ "$MODEL_TYPE" = "multiscale" ]; then
    CONFIG="configs/phase1_multiscale.yaml"
    echo "Model type: MULTISCALE"
else
    CONFIG="configs/phase1.yaml"
    echo "Model type: BASELINE"
fi

PYTHON=/root/workspace/envs/pdellm/bin/python
TORCHRUN=/root/workspace/envs/pdellm/bin/torchrun

# Suppress noisy logs
export NCCL_DEBUG=WARN
export TOKENIZERS_PARALLELISM=false

cd "$(dirname "$0")/.."   # always run from project root

# Build command
if [ "$NGPU" -gt 1 ]; then
    echo "Launching with torchrun on $NGPU GPUs"
    CMD="$TORCHRUN --nproc_per_node=$NGPU train_phase1.py --config $CONFIG"
else
    echo "Launching single-GPU"
    CMD="$PYTHON train_phase1.py --config $CONFIG"
fi

# Resume flag
if [ -n "$RESUME" ]; then
    CMD="$CMD --resume $RESUME"
    echo "Force resuming from: $RESUME"
else
    echo "Auto-resume enabled: will detect latest checkpoint if exists"
fi

echo "Config: $CONFIG"

# Run
if [ "${1:-}" = "nohup" ]; then
    LOG_FILE="logs/run_phase1_${MODEL_TYPE}_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p logs
    echo "Running with nohup, log: $LOG_FILE"
    nohup $CMD > "$LOG_FILE" 2>&1 &
    echo "Training started in background, PID: $!"
    echo "Monitor with: tail -f $LOG_FILE"
else
    exec $CMD
fi
