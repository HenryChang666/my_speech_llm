#!/bin/bash
# Evaluate SpeechLLM on full AISHELL-1 test set with multi-GPU
#
# Usage:
#   bash run_eval_full.sh /path/to/checkpoint
#   bash run_eval_full.sh /path/to/checkpoint /path/to/output.json

export PYTHONPATH=/root/workspace/my_speech_llm:$PYTHONPATH
export PHASE1_CHECKPOINT=/root/workspace/my_speech_llm/checkpoints/phase1_multiscale/ckpt_best.pt
export FREEZE_ENCODER=true
export FREEZE_ADAPTER=true

CHECKPOINT=${1:?Usage: bash run_eval_full.sh <checkpoint_path> [output_path]}
OUTPUT=${2:-}

NUM_GPUS=8

EXTRA_ARGS=""
if [ -n "$OUTPUT" ]; then
    EXTRA_ARGS="--output $OUTPUT"
fi

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
torchrun --nproc_per_node=$NUM_GPUS --master_port=29509 \
    /root/workspace/my_speech_llm/scripts/eval_aishell_full.py \
    --checkpoint "$CHECKPOINT" \
    $EXTRA_ARGS
