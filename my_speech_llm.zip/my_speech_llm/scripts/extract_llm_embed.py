#!/usr/bin/env python3
"""
Extract LLaMA-3 embed_tokens weight matrix and save as a standalone .pt file.
This is used to tie the CTC head weights in Phase 1 training.

Usage:
    python scripts/extract_llm_embed.py
"""

import torch
from transformers import AutoModelForCausalLM
import os

LLM_PATH = "/root/workspace/models/llama31-8b-instruct"
OUT_PATH = "/root/workspace/my_speech_llm/checkpoints/llm_embed_tokens.pt"

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)

print(f"Loading LLM from {LLM_PATH} ...")
# Load only the embedding layer — load_in_4bit or meta device avoids OOM
model = AutoModelForCausalLM.from_pretrained(
    LLM_PATH,
    torch_dtype=torch.float32,
    low_cpu_mem_usage=True,
    device_map="cpu",
)

embed_w = model.model.embed_tokens.weight.detach().clone()
print(f"embed_tokens shape: {embed_w.shape}")   # [128256, 4096]
torch.save(embed_w, OUT_PATH)
print(f"Saved → {OUT_PATH}")
del model
