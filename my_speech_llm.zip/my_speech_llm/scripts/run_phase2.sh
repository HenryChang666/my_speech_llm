#!/bin/bash
# SpeechLLM Phase 2 Training Script using swift sft
# LoRA 训练，使用 aishell1 train 集训练，test 集验证
export SPEECH_LLM_DEBUG=0
# Environment setup
export PYTHONPATH=/root/workspace/my_speech_llm:$PYTHONPATH

# Phase 1 checkpoint path
export PHASE1_CHECKPOINT="/root/workspace/my_speech_llm/checkpoints/phase1/ckpt_best.pt"

# Loss weights
export CTC_WEIGHT=0.3
export LM_WEIGHT=1.0

# Freeze settings (environment variables for model config)
export FREEZE_ENCODER="true"
export FREEZE_ADAPTER="true"

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Optional: resume from checkpoint
# Usage:
#   bash run_phase2_ms.sh /path/to/checkpoint
#   bash run_phase2_ms.sh --resume_from_checkpoint /path/to/checkpoint
RESUME_ARGS=""
if [ "$1" = "--resume_from_checkpoint" ] || [ "$1" = "--resume-from-checkpoint" ]; then
    CKPT_PATH="$2"
elif [ -n "$1" ]; then
    CKPT_PATH="$1"
fi
if [ -n "$CKPT_PATH" ]; then
    echo "Resuming from checkpoint: $CKPT_PATH"
    RESUME_ARGS="--resume_from_checkpoint $CKPT_PATH"
fi

# Run training with swift sft (LoRA)
# 训练集：aishell1 train，验证集：aishell1 test
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
torchrun --nproc_per_node=8 $SCRIPT_DIR/swift_sft_wrapper.py \
    --model /root/workspace/models/llama31-8b-instruct \
    --model_type speech_llm \
    --dataset speech_asr/speech_asr_aishell1_trainsets:train \
    --val_dataset speech_asr/speech_asr_aishell1_trainsets:test \
    --torch_dtype bfloat16 \
    --num_train_epochs 200 \
    --per_device_train_batch_size 16 \
    --per_device_eval_batch_size 16 \
    --learning_rate 1e-4 \
    --freeze_vit true \
    --freeze_aligner true \
    --gradient_accumulation_steps 4 \
    --eval_steps 500 \
    --save_steps 500 \
    --save_total_limit 150 \
    --logging_steps 50 \
    --max_length 2048 \
    --output_dir /root/workspace/my_speech_llm/checkpoints/phase2_lora_aishell1 \
    --warmup_ratio 0.05 \
    --dataloader_num_workers 4 \
    $RESUME_ARGS
