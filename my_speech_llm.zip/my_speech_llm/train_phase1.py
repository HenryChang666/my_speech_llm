#!/usr/bin/env python3
"""
Phase 1 training entry point (supports both baseline and multiscale).

model_type is determined by the config YAML:
    model_type: "baseline"     -> original SpeechEncoder + AlignmentAdapter
    model_type: "multiscale"   -> MultiscaleEncoder with interleaved conv/ctc

Single-GPU:
    python train_phase1.py --config configs/phase1.yaml
    python train_phase1.py --config configs/phase1_multiscale.yaml

Multi-GPU (torchrun):
    torchrun --nproc_per_node=4 train_phase1.py --config configs/phase1_multiscale.yaml

Resume:
    python train_phase1.py --config configs/phase1.yaml --resume checkpoints/phase1/ckpt_step_2000.pt
"""

import os
import sys
import argparse
import yaml
import logging
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
import torch.distributed as dist
from torch.utils.data import DistributedSampler, DataLoader

from transformers import AutoTokenizer

from data.dataset import AISHELLDataset, SpeechCollator

logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="Path to YAML config")
    p.add_argument("--resume", default=None,
                   help="Checkpoint path to resume from (auto-detect if not specified)")
    return p.parse_args()


def find_latest_checkpoint(output_dir: str) -> Optional[str]:
    if not os.path.isdir(output_dir):
        return None
    ckpt_files = [f for f in os.listdir(output_dir)
                  if f.endswith('.pt') and f.startswith('ckpt_')]
    if not ckpt_files:
        return None
    best_ckpt = os.path.join(output_dir, "ckpt_best.pt")
    if os.path.exists(best_ckpt):
        return best_ckpt
    step_ckpts = [f for f in ckpt_files if f.startswith('ckpt_step_')]
    if step_ckpts:
        step_nums = []
        for f in step_ckpts:
            try:
                step = int(f.replace('ckpt_step_', '').replace('.pt', ''))
                step_nums.append((step, f))
            except ValueError:
                continue
        if step_nums:
            step_nums.sort(reverse=True)
            return os.path.join(output_dir, step_nums[0][1])
    final_ckpt = os.path.join(output_dir, "ckpt_final.pt")
    if os.path.exists(final_ckpt):
        return final_ckpt
    return None


def setup_distributed():
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    if "WORLD_SIZE" in os.environ and int(os.environ["WORLD_SIZE"]) > 1:
        dist.init_process_group(backend="nccl")
        torch.cuda.set_device(local_rank)
    return local_rank


# -----------------------------------------------------------------------
# Baseline loaders (original)
# -----------------------------------------------------------------------

def build_loaders_baseline(cfg, tokenizer, local_rank):
    dc = cfg["data"]
    train_ds = AISHELLDataset("train", tokenizer,
                              max_frames=dc.get("max_frames", 3000),
                              max_tokens=dc.get("max_tokens", 256))
    test_ds = AISHELLDataset("test", tokenizer,
                             max_frames=dc.get("max_frames", 3000),
                             max_tokens=dc.get("max_tokens", 256))
    collator = SpeechCollator(pad_id=0)

    use_ddp = dist.is_available() and dist.is_initialized()
    train_sampler = DistributedSampler(train_ds, shuffle=True) if use_ddp else None
    test_sampler = DistributedSampler(test_ds, shuffle=False) if use_ddp else None

    train_loader = DataLoader(
        train_ds, batch_size=dc.get("batch_size", 16),
        sampler=train_sampler, shuffle=(train_sampler is None),
        num_workers=dc.get("num_workers", 4),
        collate_fn=collator, pin_memory=True,
        persistent_workers=(dc.get("num_workers", 4) > 0),
    )
    test_loader = DataLoader(
        test_ds, batch_size=dc.get("batch_size", 16),
        sampler=test_sampler, shuffle=False,
        num_workers=dc.get("num_workers", 4),
        collate_fn=collator, pin_memory=True,
        persistent_workers=(dc.get("num_workers", 4) > 0),
    )
    return train_loader, test_loader


# -----------------------------------------------------------------------
# Multiscale loaders (uses MultiscaleCollator for online tokenization)
# -----------------------------------------------------------------------

def build_loaders_multiscale(cfg, tokenizer, ctc_tokenizers, local_rank):
    from training.trainer_multiscale import MultiscaleCollator

    dc = cfg["data"]
    train_ds = AISHELLDataset("train", tokenizer,
                              max_frames=dc.get("max_frames", 3000),
                              max_tokens=dc.get("max_tokens", 256))
    test_ds = AISHELLDataset("test", tokenizer,
                             max_frames=dc.get("max_frames", 3000),
                             max_tokens=dc.get("max_tokens", 256))
    collator = MultiscaleCollator(pad_id=0, ctc_tokenizers=ctc_tokenizers)

    use_ddp = dist.is_available() and dist.is_initialized()
    train_sampler = DistributedSampler(train_ds, shuffle=True) if use_ddp else None
    test_sampler = DistributedSampler(test_ds, shuffle=False) if use_ddp else None

    train_loader = DataLoader(
        train_ds, batch_size=dc.get("batch_size", 16),
        sampler=train_sampler, shuffle=(train_sampler is None),
        num_workers=dc.get("num_workers", 4),
        collate_fn=collator, pin_memory=True,
        persistent_workers=(dc.get("num_workers", 4) > 0),
    )
    test_loader = DataLoader(
        test_ds, batch_size=dc.get("batch_size", 16),
        sampler=test_sampler, shuffle=False,
        num_workers=dc.get("num_workers", 4),
        collate_fn=collator, pin_memory=True,
        persistent_workers=(dc.get("num_workers", 4) > 0),
    )
    return train_loader, test_loader


# -----------------------------------------------------------------------
# Build intermediate CTC tokenizers from config
# -----------------------------------------------------------------------

def build_ctc_tokenizers(cfg) -> dict:
    """Parse interleaved config and build tokenizers for each ctc_N entry."""
    from data.multiscale_tokenizer import build_tokenizer

    interleaved = cfg.get("interleaved", {})
    tokenizers = {}

    for key, val in interleaved.items():
        if key.startswith("ctc_"):
            tok_cfg = val.get("tokenizer", {})
            if not tok_cfg:
                raise ValueError(f"{key} missing 'tokenizer' config")
            tokenizers[key] = build_tokenizer(tok_cfg)
            logger.info(f"  Built tokenizer for {key}: type={tok_cfg['type']}, "
                        f"vocab_size={tokenizers[key].vocab_size}")

    return tokenizers


# -----------------------------------------------------------------------
# LLM embed weights extraction (shared by both model types)
# -----------------------------------------------------------------------

def ensure_llm_embed_weights(cfg, local_rank, device):
    embed_path = cfg.get("llm_embed_weights_path", "")
    if not embed_path:
        return
    if os.path.exists(embed_path):
        return

    if local_rank == 0:
        logger.info("LLM embed weights not found — extracting now (CPU)...")
        from transformers import AutoModelForCausalLM
        llm = AutoModelForCausalLM.from_pretrained(
            "/root/workspace/models/llama31-8b-instruct",
            torch_dtype=torch.float32,
            low_cpu_mem_usage=True,
            device_map="cpu",
        )
        os.makedirs(os.path.dirname(embed_path), exist_ok=True)
        torch.save(llm.model.embed_tokens.weight.detach().clone(), embed_path)
        del llm
        logger.info(f"Saved embed weights -> {embed_path}")

    if dist.is_available() and dist.is_initialized():
        dist.barrier()


# -----------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------

def main():
    args = parse_args()
    local_rank = setup_distributed()

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    model_type = cfg.get("model_type", "baseline")
    if local_rank == 0:
        logging.basicConfig(level=logging.INFO,
                            format="%(asctime)s [%(levelname)s] %(message)s")
        logger.info(f"model_type = {model_type}")

    tokenizer = AutoTokenizer.from_pretrained("/root/workspace/models/llama31-8b-instruct")
    assert tokenizer.vocab_size <= cfg["adapter"]["vocab_size"], (
        f"vocab_size mismatch: tokenizer={tokenizer.vocab_size} "
        f"cfg={cfg['adapter']['vocab_size']}"
    )

    # Ensure LLM embed weights exist
    ensure_llm_embed_weights(cfg, local_rank,
                             torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu"))

    if model_type == "multiscale":
        # Build intermediate CTC tokenizers
        ctc_tokenizers = build_ctc_tokenizers(cfg)

        # Build data loaders with MultiscaleCollator
        train_loader, test_loader = build_loaders_multiscale(
            cfg, tokenizer, ctc_tokenizers, local_rank,
        )

        # Build multiscale trainer
        from training.trainer_multiscale import MultiscalePhase1Trainer
        trainer = MultiscalePhase1Trainer(
            cfg, local_rank=local_rank,
            tokenizer=tokenizer,
            ctc_tokenizers=ctc_tokenizers,
        )

    else:
        # Baseline model
        from training.trainer import Phase1Trainer
        train_loader, test_loader = build_loaders_baseline(cfg, tokenizer, local_rank)
        trainer = Phase1Trainer(cfg, local_rank=local_rank, tokenizer=tokenizer)

    # Resume
    resume_path = args.resume
    if resume_path is None:
        resume_path = find_latest_checkpoint(cfg["output_dir"])
        if resume_path and local_rank == 0:
            logger.info(f"Auto-detected checkpoint: {resume_path}")
    if resume_path:
        trainer.load_checkpoint(resume_path)

    # For baseline: tie LLM weights if not yet tied (handled inside trainer for multiscale)
    if model_type == "baseline":
        embed_path = cfg.get("llm_embed_weights_path", "")
        if embed_path and os.path.exists(embed_path):
            embed_w = torch.load(embed_path, map_location=trainer.device)
            adapter = trainer.adapter.module if hasattr(trainer.adapter, "module") else trainer.adapter
            if not adapter._weights_tied:
                adapter.tie_ctc_weights(embed_w)

    # Train
    trainer.train(train_loader, val_loader=None, test_loader=test_loader)


if __name__ == "__main__":
    main()
