"""
Swift integration for my_speech_llm Phase 2 training.

This module provides:
1. Custom Speech-LLM model implementation compatible with transformers
2. Swift model loader and template registration
3. Training script compatible with `swift sft`
"""

from .model import SpeechLLMConfig, SpeechLLMForCausalLM

__all__ = [
    "SpeechLLMConfig",
    "SpeechLLMForCausalLM",
]
