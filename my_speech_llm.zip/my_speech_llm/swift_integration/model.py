"""
Speech-LLM Model for Phase 2 Training

Architecture:
    SpeechEncoder (from Phase 1, frozen)
    -> AlignmentAdapter (from Phase 1, fine-tunable)
    -> CTCShrinker (rule-based, adjacent same-token pooling)
    -> LLM (LLaMA-3.1-8B)

Losses:
    1. CTC loss at adapter output (for alignment supervision)
    2. LM loss at LLM output (for transcription generation)

Reference: Soundwave architecture with modifications:
    - No learned LookBackModule (LBM)
    - Rule-based shrinking instead
    - Audio patch token: 128256 (extended vocab)

This model is designed to be registered with transformers AutoModel
and used with ms-swift training framework.
"""

import os
import sys
import json
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple, List, Union

from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    LlamaConfig,
    LlamaForCausalLM,
    LlamaModel,
    PretrainedConfig,
    PreTrainedModel,
)
from transformers.modeling_outputs import CausalLMOutputWithPast, BaseModelOutputWithPast
from transformers.utils import logging
from dataclasses import dataclass

from models.encoder import SpeechEncoder
from models.multiscale_encoder import MultiscaleEncoder, validate_interleaved_config
from models.alignment_adapter import AlignmentAdapter


logger = logging.get_logger(__name__)


@dataclass
class SpeechLLMOutputWithPast(CausalLMOutputWithPast):
    """Custom output with loss_asr and loss_lm for logging by swift."""
    loss_asr: Optional[torch.FloatTensor] = None
    loss_lm: Optional[torch.FloatTensor] = None


# Module-level cache for last shrink tokens (non-blank), accessible from outside
_last_shrink_tokens = []  # list of 1D token id tensors, one per sample in batch


class SpeechLLMConfig(LlamaConfig):
    """
    Configuration class for SpeechLLM.

    Extends LlamaConfig with additional parameters for speech processing.
    """
    model_type = "speech_llm"

    def __init__(
        self,
        # Phase 1 checkpoint path
        phase1_checkpoint: str = None,
        # Audio placeholder token in input_ids (must exist in vocab)
        # Using <|reserved_special_token_0|> (128002)
        audio_placeholder_token: int = 128002,
        # CTC blank token (just an index, doesn't need to be in vocab)
        ctc_blank_token: int = 128256,
        # Loss weights
        ctc_weight: float = 0.3,
        lm_weight: float = 1.0,
        # Freeze settings
        freeze_encoder: bool = True,
        freeze_adapter: bool = False,
        # Encoder type: "base" or "multiscale"
        encoder_type: str = "base",
        # LLM pad token (for padding during training)
        llm_pad_token_id: int = 128009,  # <|eot_id|>
        # Tokenizer path for decoding CTC output (optional, for debug)
        tokenizer_path: str = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.phase1_checkpoint = phase1_checkpoint
        self.audio_placeholder_token = audio_placeholder_token
        self.ctc_blank_token = ctc_blank_token
        self.ctc_weight = ctc_weight
        self.lm_weight = lm_weight
        self.freeze_encoder = freeze_encoder
        self.freeze_adapter = freeze_adapter
        self.encoder_type = encoder_type
        self.llm_pad_token_id = llm_pad_token_id
        self.tokenizer_path = tokenizer_path


def ctc_shrink(
    features: torch.Tensor,
    ctc_logits: torch.Tensor,
    padding_mask: torch.Tensor,
    blank_id: int = 128256,
) -> Tuple[List[torch.Tensor], List[torch.Tensor], List[int]]:
    """
    Shrink audio features based on CTC predictions.

    Rule (matching Soundwave):
    - Merge consecutive frames with the SAME CTC prediction (including blanks)
    - This is NOT standard CTC decoding - we keep blanks!

    Args:
        features:     [B, T, D]  aligned features from adapter
        ctc_logits:   [B, T, V]  CTC logits
        padding_mask: [B, T]     True = padding position
        blank_id:     CTC blank token id

    Returns:
        shrink_features: list of [T_i, D] tensors (variable length per sample)
        shrink_tokens:   list of [T_i] token ids for each sample
        lengths:         list of shrunk lengths
    """
    batch_size = features.size(0)

    # Greedy decode CTC predictions
    pred_tokens = ctc_logits.argmax(dim=-1)  # [B, T]

    shrink_features = []
    shrink_tokens = []
    lengths = []

    for b in range(batch_size):
        # Get valid frames (non-padding)
        valid_mask = ~padding_mask[b]  # [T]
        valid_tokens = pred_tokens[b][valid_mask]  # [T_valid]
        valid_features = features[b][valid_mask]   # [T_valid, D]

        if len(valid_tokens) == 0:
            # Edge case: empty sequence
            shrink_features.append(valid_features[:1] if valid_features.size(0) > 0 else features[b, :1])
            shrink_tokens.append(torch.tensor([blank_id], dtype=torch.long, device=features.device))
            lengths.append(1)
            continue

        # Soundwave shrink logic: keep first token, then only keep if different from previous
        shrink_mask = torch.ones(len(valid_tokens), dtype=torch.bool, device=features.device)
        shrink_mask[1:] = valid_tokens[1:] != valid_tokens[:-1]

        # Apply mask to get shrunk tokens and features
        shrunk_tokens_b = valid_tokens[shrink_mask]

        # For features, we merge consecutive same tokens by mean pooling
        shrunk_feats = []
        i = 0
        while i < len(valid_tokens):
            # Find end of current segment with same token
            j = i
            while j < len(valid_tokens) and valid_tokens[j] == valid_tokens[i]:
                j += 1
            # Mean pool the segment
            segment = valid_features[i:j]  # [n, D]
            pooled = segment.mean(dim=0)   # [D]
            shrunk_feats.append(pooled)
            i = j

        if len(shrunk_feats) > 0:
            shrink_features.append(torch.stack(shrunk_feats))
            shrink_tokens.append(shrunk_tokens_b)
            lengths.append(len(shrunk_feats))
        else:
            # Edge case
            shrink_features.append(valid_features[:1])
            shrink_tokens.append(valid_tokens[:1])
            lengths.append(1)

    return shrink_features, shrink_tokens, lengths


def pad_shrunk_features(
    shrink_features: List[torch.Tensor],
    pad_value: float = 0.0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Pad shrunk features to same length for batching.

    Args:
        shrink_features: list of [T_i, D] tensors
        pad_value: padding value

    Returns:
        padded: [B, T_max, D]
        mask:   [B, T_max]  True = valid, False = padding
    """
    batch_size = len(shrink_features)
    max_len = max(f.size(0) for f in shrink_features)
    dim = shrink_features[0].size(1)

    padded = torch.full((batch_size, max_len, dim), pad_value,
                       dtype=shrink_features[0].dtype, device=shrink_features[0].device)
    mask = torch.zeros(batch_size, max_len, dtype=torch.bool, device=shrink_features[0].device)

    for i, feat in enumerate(shrink_features):
        length = feat.size(0)
        padded[i, :length] = feat
        mask[i, :length] = True

    return padded, mask


class SpeechLLMModel(LlamaModel):
    """
    SpeechLLM Model extending LlamaModel.

    Extends LlamaModel to handle audio inputs and CTC-based shrinking.
    """
    config_class = SpeechLLMConfig

    def __init__(self, config: SpeechLLMConfig):
        super().__init__(config)
        self.config = config

        # Initialize encoder and adapter (will be loaded lazily from checkpoint)
        self.encoder = None
        self.adapter = None
        self._phase1_loaded = False
        self._checkpoint_cache = None  # Cache checkpoint data for lazy loading

        # Audio placeholder token (in input_ids) and CTC blank token
        self.audio_placeholder_token = config.audio_placeholder_token
        self.llm_pad_token_id = config.llm_pad_token_id

        # CTC loss function (blank token for CTC, can be any index)
        self.ctc_loss_fn = nn.CTCLoss(
            blank=config.ctc_blank_token,
            reduction='mean',
            zero_infinity=True,
        )

        # Tokenizer for decoding CTC output (optional, for debug)
        self._tokenizer = None
        if config.tokenizer_path:
            try:
                from transformers import AutoTokenizer
                self._tokenizer = AutoTokenizer.from_pretrained(config.tokenizer_path)
                logger.info(f"Tokenizer loaded from {config.tokenizer_path} for CTC decoding debug")
            except Exception as e:
                logger.warning(f"Failed to load tokenizer from {config.tokenizer_path}: {e}")

        # Pre-load checkpoint config (but don't load weights yet)
        if config.phase1_checkpoint:
            self._preload_checkpoint_config(config.phase1_checkpoint)

        # 冻结 embed_tokens，不训练 token embedding
        if hasattr(self, 'embed_tokens') and self.embed_tokens is not None:
            self.embed_tokens.weight.requires_grad = False
            logger.info("embed_tokens frozen (requires_grad=False)")

    def _preload_checkpoint_config(self, checkpoint_path: str):
        """Pre-load checkpoint config to determine encoder type, but don't load weights yet."""
        ckpt = torch.load(checkpoint_path, map_location="cpu")
        cfg = ckpt.get("cfg", {})
        enc_cfg = cfg.get("encoder", {})

        # Detect if multiscale checkpoint
        is_multiscale = False
        if cfg.get("interleaved"):
            is_multiscale = True
        else:
            for key in ckpt.get("encoder", {}).keys():
                if key.startswith("conv_modules.") or key.startswith("ctc_heads."):
                    is_multiscale = True
                    break

        self.config.encoder_type = "multiscale" if is_multiscale else "base"

        # Cache checkpoint data for lazy loading
        self._checkpoint_cache = {
            "path": checkpoint_path,
            "ckpt": ckpt,
            "cfg": cfg,
            "enc_cfg": enc_cfg,
            "is_multiscale": is_multiscale,
        }
        logger.info(f"Cached checkpoint config from {checkpoint_path}, encoder_type: {self.config.encoder_type}")

    def _lazy_load_phase1_components(self):
        """Load encoder and adapter from Phase 1 checkpoint (lazy, on first forward)."""
        if self._phase1_loaded:
            return

        if self._checkpoint_cache is None:
            raise ValueError("No checkpoint cached for lazy loading")

        cache = self._checkpoint_cache
        ckpt = cache["ckpt"]
        cfg = cache["cfg"]
        enc_cfg = cache["enc_cfg"]
        is_multiscale = cache["is_multiscale"]

        logger.info("Lazy loading Phase 1 components...")

        if is_multiscale:
            interleaved_cfg = cfg.get("interleaved", {})

            # Build ctc_tokenizers if present
            ctc_tokenizers = {}
            for key, val in interleaved_cfg.items():
                if key.startswith("ctc_") and "tokenizer" in val:
                    tokenizer_cfg = val["tokenizer"]
                    vocab_path = tokenizer_cfg.get("vocab_path", "")
                    vocab_size = tokenizer_cfg.get("vocab_size", 100)
                    if vocab_path and os.path.exists(vocab_path):
                        try:
                            with open(vocab_path, 'r', encoding='utf-8') as f:
                                vocab = json.load(f)
                                vocab_size = len(vocab)
                                logger.info(f"Loaded {key} vocab from {vocab_path}, size: {vocab_size}")
                        except Exception as e:
                            logger.warning(f"Failed to load vocab from {vocab_path}: {e}")

                    class DummyTokenizer:
                        def __init__(self, vocab_size):
                            self.vocab_size = vocab_size
                    ctc_tokenizers[key] = DummyTokenizer(vocab_size)

            num_layers = enc_cfg.get("num_layers", 12)
            interleaved_modules = validate_interleaved_config(interleaved_cfg, num_layers)

            self.encoder = MultiscaleEncoder(
                input_dim=enc_cfg.get("input_dim", 80),
                conv_channels=enc_cfg.get("conv_channels", 1024),
                embed_dim=enc_cfg.get("embed_dim", 512),
                conv_kernel_sizes=tuple(enc_cfg.get("conv_kernel_sizes", [5, 5])),
                num_layers=num_layers,
                num_heads=enc_cfg.get("num_heads", 8),
                ffn_dim=enc_cfg.get("ffn_dim", 2048),
                dropout=enc_cfg.get("dropout", 0.15),
                interleaved_modules=interleaved_modules if interleaved_modules else None,
                ctc_tokenizers=ctc_tokenizers if ctc_tokenizers else None,
            )
        else:
            self.encoder = SpeechEncoder(
                input_dim=enc_cfg.get("input_dim", 80),
                conv_channels=enc_cfg.get("conv_channels", 1024),
                embed_dim=enc_cfg.get("embed_dim", 512),
                conv_kernel_sizes=tuple(enc_cfg.get("conv_kernel_sizes", [5, 5])),
                conv_strides=tuple(enc_cfg.get("conv_strides", [2] * len(enc_cfg.get("conv_kernel_sizes", [5, 5])))),
                num_layers=enc_cfg.get("num_layers", 12),
                num_heads=enc_cfg.get("num_heads", 8),
                ffn_dim=enc_cfg.get("ffn_dim", 2048),
                dropout=enc_cfg.get("dropout", 0.15),
            )

        # Build adapter
        ada_cfg = cfg.get("adapter", {})
        self.adapter = AlignmentAdapter(
            encoder_dim=enc_cfg.get("embed_dim", 512),
            llm_hidden_size=ada_cfg.get("llm_hidden_size", self.config.hidden_size),
            llm_num_heads=ada_cfg.get("llm_num_heads", self.config.num_attention_heads),
            vocab_size=ada_cfg.get("vocab_size", 128256),
            ffn_multiplier=ada_cfg.get("ffn_multiplier", 2),
            dropout=ada_cfg.get("dropout", 0.1),
        )

        # Get target device and dtype from LLM
        target_device = next(self.parameters()).device
        target_dtype = next(self.parameters()).dtype

        # Move encoder and adapter to target device FIRST
        self.encoder = self.encoder.to(device=target_device, dtype=target_dtype)
        self.adapter = self.adapter.to(device=target_device, dtype=target_dtype)

        # NOW load weights (modules are on correct device/dtype)
        # Load with strict=True, weights will be cast to module's dtype automatically
        self.encoder.load_state_dict(ckpt["encoder"], strict=True)
        self.adapter.load_state_dict(ckpt["adapter"], strict=True)

        # Cast again in case checkpoint weights overrode the dtype
        self.encoder = self.encoder.to(dtype=target_dtype)
        self.adapter = self.adapter.to(dtype=target_dtype)

        # Tie CTC weights to LLM embed_tokens
        self.adapter.tie_ctc_weights(self.embed_tokens.weight.data.clone())

        # Apply freeze settings
        if self.config.freeze_encoder:
            for param in self.encoder.parameters():
                param.requires_grad = False
            # 重要：freeze 时必须设为 eval 模式，否则 dropout 会在训练时随机丢弃
            self.encoder.eval()
            logger.info("Encoder frozen and set to eval mode")

        if self.config.freeze_adapter:
            for param in self.adapter.parameters():
                param.requires_grad = False
            # 重要：freeze 时必须设为 eval 模式，否则 dropout 会在训练时随机丢弃
            self.adapter.eval()
            logger.info("Adapter frozen and set to eval mode")

        # Free checkpoint cache to save memory
        self._checkpoint_cache = None
        self._phase1_loaded = True
        logger.info("Phase 1 components loaded successfully")

    def train(self, mode: bool = True):
        """Override train() to preserve eval mode for frozen modules."""
        super().train(mode)
        # Restore eval mode for frozen modules (train() recursively sets all children)
        if self._phase1_loaded:
            if self.config.freeze_encoder and self.encoder is not None:
                self.encoder.eval()
            if self.config.freeze_adapter and self.adapter is not None:
                self.adapter.eval()
        return self

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        # Audio inputs
        audios: Optional[torch.FloatTensor] = None,
        audio_lengths: Optional[torch.LongTensor] = None,
        # CTC targets
        asr_targets: Optional[torch.LongTensor] = None,
    ) -> Union[Tuple, BaseModelOutputWithPast]:
        """
        Forward pass with audio and text.

        Args:
            audios: [B, T, 80] mel-spectrogram features
            audio_lengths: [B] original lengths before padding
            asr_targets: [B, L] CTC target token ids (transcription)
        """
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        # If no audio, just use parent forward
        # Also skip audio processing during decode phase (past_key_values present, single new token)
        _has_audio_placeholder = (input_ids == self.audio_placeholder_token).any() if input_ids is not None else False
        _is_decode_step = (past_key_values is not None and
                           input_ids is not None and input_ids.shape[1] == 1)
        if audios is None or _is_decode_step:
            return super().forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_values=past_key_values,
                inputs_embeds=inputs_embeds,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                cache_position=cache_position,
            )

        # Lazy load encoder and adapter on first audio forward
        self._lazy_load_phase1_components()

        # Process audio
        # 1. Encode audio
        if self.encoder is None or self.adapter is None:
            raise ValueError("Encoder and adapter not loaded. Please provide phase1_checkpoint.")

        # Encode audio (with gradient enabled based on freeze settings)
        encoder_requires_grad = any(p.requires_grad for p in self.encoder.parameters())

        # Save original audios before dtype cast (for debug comparison)
        audios_orig = audios.clone()

        # DEBUG: Check encoder training mode
        _debug = os.environ.get("SPEECH_LLM_DEBUG", "0") == "1"
        if _debug: print(f"[DEBUG] Encoder training mode: {self.encoder.training}", flush=True)
        if _debug: print(f"[DEBUG] Adapter training mode: {self.adapter.training}", flush=True)

        # Cast audios to model dtype to avoid float/bfloat16 mismatch
        model_dtype = next(self.encoder.parameters()).dtype
        audios = audios.to(model_dtype)

        with torch.set_grad_enabled(encoder_requires_grad):
            enc_out, out_lengths, enc_pad_mask = self.encoder(audios, audio_lengths)[:3]

        # 2. Align to LLM space
        aligned, ctc_logits = self.adapter(enc_out, enc_pad_mask)

        _debug = os.environ.get("SPEECH_LLM_DEBUG", "0") == "1"

        # DEBUG: shrink前的特征维度
        if _debug: print(f"\n[DEBUG] === Audio Processing ===", flush=True)
        if _debug: print(f"[DEBUG] aligned features (before shrink): shape={aligned.shape}", flush=True)
        if _debug: print(f"[DEBUG] ctc_logits: shape={ctc_logits.shape}", flush=True)

        # 3. Shrink audio features (use ctc_blank_token for CTC shrink)
        shrink_features, shrink_tokens, _ = ctc_shrink(
            aligned, ctc_logits, enc_pad_mask, self.config.ctc_blank_token
        )

        # DEBUG: shrink后的特征维度和解码文本
        if _debug: print(f"[DEBUG] shrink_features (after shrink): {len(shrink_features)} samples", flush=True)
        # 保存 shrink tokens 供外部读取（去掉 blank）
        global _last_shrink_tokens
        _last_shrink_tokens = []
        self.last_shrink_tokens = []
        for i, (feat, tok) in enumerate(zip(shrink_features, shrink_tokens)):
            if _debug: print(f"[DEBUG]   sample {i}: feat shape={feat.shape}, tokens len={len(tok)}", flush=True)
            non_blank_tokens = tok[tok != self.config.ctc_blank_token]
            self.last_shrink_tokens.append(non_blank_tokens)
            _last_shrink_tokens.append(non_blank_tokens)
            if len(non_blank_tokens) > 0:
                if _debug: print(f"[DEBUG]   sample {i} shrink decoded tokens (first 20): {non_blank_tokens[:20].tolist()}", flush=True)
                if self._tokenizer is not None:
                    try:
                        decoded_text = self._tokenizer.decode(non_blank_tokens.tolist(), skip_special_tokens=True)
                        if _debug: print(f"[DEBUG]   sample {i} shrink decoded text: {decoded_text}", flush=True)
                    except Exception as e:
                        if _debug: print(f"[DEBUG]   sample {i} shrink decode failed: {e}", flush=True)

        # Pad shrunk features
        shrunk, shrunk_mask = pad_shrunk_features(shrink_features)
        if _debug: print(f"[DEBUG] shrunk (padded): shape={shrunk.shape}", flush=True)

        # 4. Merge audio with text
        # Find audio placeholder positions
        audio_patch_mask = (input_ids == self.audio_placeholder_token)
        has_audio = audio_patch_mask.any(dim=1)

        if inputs_embeds is None:
            # audio_placeholder_token (128002) is a valid token in vocab, so we can directly embed it
            inputs_embeds = self.embed_tokens(input_ids)

        # DEBUG: LLM输入端，拼接前的状态
        if _debug: print(f"\n[DEBUG] === LLM Input (Before Merge) ===", flush=True)
        if _debug: print(f"[DEBUG] input_ids shape: {input_ids.shape}", flush=True)
        if _debug: print(f"[DEBUG] inputs_embeds shape: {inputs_embeds.shape}", flush=True)
        if _debug: print(f"[DEBUG] audio_placeholder_token positions: {audio_patch_mask.nonzero().tolist()}", flush=True)
        # 打印第一个样本的input_ids内容（前50个token）
        if _debug: print(f"[DEBUG] sample 0 input_ids (first 50): {input_ids[0, :50].tolist()}", flush=True)
        # 解码 input_ids 为中文文本
        if self._tokenizer is not None:
            try:
                # 解码时跳过特殊 token（包括 audio placeholder）
                decoded_input = self._tokenizer.decode(input_ids[0].tolist(), skip_special_tokens=True)
                if _debug: print(f"[DEBUG] sample 0 input_ids decoded text: {decoded_input}", flush=True)
            except Exception as e:
                if _debug: print(f"[DEBUG] sample 0 input_ids decode failed: {e}", flush=True)
        # 找到placeholder位置并打印周围内容
        for b in range(min(2, input_ids.shape[0])):
            pos = (input_ids[b] == self.audio_placeholder_token).nonzero()
            if len(pos) > 0:
                p = pos[0].item()
                if _debug: print(f"[DEBUG] sample {b}: placeholder at pos {p}, context: {input_ids[b, max(0,p-5):p+5].tolist()}", flush=True)

        # Replace audio patch tokens with shrunk features
        new_input_embeds = []
        new_attention_masks = []  # 同时构建新的 attention_mask
        # Track label adjustments: for each sample, store (audio_pos, num_audio_tokens)
        label_adjustments = []

        for b, (cur_input_ids, cur_input_embeds, shrink_feature, s_mask) in enumerate(
            zip(input_ids, inputs_embeds, shrunk, shrunk_mask)
        ):
            v = s_mask.sum().item()  # actual audio length for this sample

            # Find audio placeholder position
            audio_patch_positions = torch.where(cur_input_ids == self.audio_placeholder_token)[0]
            if len(audio_patch_positions) == 0:
                new_input_embeds.append(cur_input_embeds)
                # attention_mask 也直接用原来的
                if attention_mask is not None:
                    new_attention_masks.append(attention_mask[b])
                label_adjustments.append((0, 0))  # no adjustment
                continue

            audio_pos = audio_patch_positions[0].item()

            # Build new embeddings: before + audio + after
            # Note: cur_input_embeds[audio_pos] is the embedding of placeholder token
            before_embeds = cur_input_embeds[:audio_pos]
            after_embeds = cur_input_embeds[audio_pos + 1:]
            audio_embeds = shrink_feature[:v]

            # Build new attention_mask: before + audio(全1) + after
            if attention_mask is not None:
                cur_mask = attention_mask[b]
                before_mask = cur_mask[:audio_pos]
                after_mask = cur_mask[audio_pos + 1:]
                audio_mask = torch.ones(v, dtype=cur_mask.dtype, device=cur_mask.device)
                cur_new_mask = torch.cat([before_mask, audio_mask, after_mask], dim=0)
                new_attention_masks.append(cur_new_mask)

            # DEBUG: 拼接前各部分
            if b == 0:
                if _debug: print(f"\n[DEBUG] === Merge Details (sample 0) ===", flush=True)
                if _debug: print(f"[DEBUG] audio_pos: {audio_pos}, v (audio tokens): {v}", flush=True)
                if _debug: print(f"[DEBUG] before_embeds shape: {before_embeds.shape}", flush=True)
                if _debug: print(f"[DEBUG] audio_embeds shape: {audio_embeds.shape}", flush=True)
                if _debug: print(f"[DEBUG] after_embeds shape: {after_embeds.shape}", flush=True)
                if _debug: print(f"[DEBUG] text before audio: {cur_input_ids[:audio_pos].tolist()}", flush=True)
                if _debug: print(f"[DEBUG] text after audio: {cur_input_ids[audio_pos+1:].tolist()}", flush=True)

            cur_new_embeds = torch.cat([before_embeds, audio_embeds, after_embeds], dim=0)
            
            # DEBUG: 拼接后
            if b == 0:
                if _debug: print(f"[DEBUG] merged embeds shape: {cur_new_embeds.shape}", flush=True)
            
            new_input_embeds.append(cur_new_embeds)
            # Store position and length for label adjustment
            # audio_pos: where audio starts in new sequence
            # v: number of audio tokens (replacing 1 placeholder token)
            label_adjustments.append((audio_pos, v))

        # Pad to same length
        max_new_len = max(emb.shape[0] for emb in new_input_embeds)
        padded_embeds = torch.stack([
            F.pad(emb, (0, 0, 0, max_new_len - emb.shape[0]))
            for emb in new_input_embeds
        ], dim=0)

        # Pad attention_mask (现在已经包含了音频位置)
        if len(new_attention_masks) > 0:
            padded_masks = torch.stack([
                F.pad(mask, (0, max_new_len - mask.shape[0]), value=0)
                for mask in new_attention_masks
            ], dim=0)
        else:
            padded_masks = None

        inputs_embeds = padded_embeds
        if padded_masks is not None:
            attention_mask = padded_masks

        # Save features for debugging (compare train vs test)
        save_path = os.environ.get("SAVE_LLM_INPUT_PATH", None)
        if save_path:
            torch.save({
                'inputs_embeds': inputs_embeds.cpu(),
                'input_ids_original': input_ids.cpu() if input_ids is not None else None,
                'label_adjustments': label_adjustments,
                # 原始 fbank 输入给 encoder 的
                'fbank_original': audios_orig.cpu() if audios_orig is not None else None,
                # encoder 输出
                'enc_out': enc_out.cpu() if enc_out is not None else None,
                # adapter 输出 (shrink前)
                'aligned': aligned.cpu() if aligned is not None else None,
                # shrink 后
                'shrink_features': [f.cpu() for f in shrink_features] if shrink_features else None,
            }, save_path)
            if _debug: print(f"[DEBUG] Saved features to {save_path}", flush=True)

        # Cast inputs_embeds to LLM dtype (e.g. bfloat16) to avoid dtype mismatch
        llm_dtype = next(self.embed_tokens.parameters()).dtype
        inputs_embeds = inputs_embeds.to(llm_dtype)

        # When audio is present, we must not pass position_ids because:
        # 1. The original position_ids are based on token sequence length
        # 2. After inserting audio features, inputs_embeds is longer than original position_ids
        # 3. LlamaModel will auto-generate correct position_ids from inputs_embeds.shape[1]
        position_ids = None

        # cache_position must also be reset to match the new (expanded) sequence length
        # Otherwise rotary embedding gets wrong cos/sin dimensions
        if cache_position is not None:
            seq_len = inputs_embeds.shape[1]
            if past_key_values is not None:
                past_len = past_key_values.get_seq_length() if hasattr(past_key_values, 'get_seq_length') else 0
            else:
                past_len = 0
            cache_position = torch.arange(past_len, past_len + seq_len, device=inputs_embeds.device)

        # Call parent forward (always return dict to attach audio_features)
        return_state = super().forward(
            input_ids=None,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,  # Force dict to attach audio_features
            cache_position=cache_position,
        )

        # Add audio_features for CTC loss computation in the CausalLM forward
        return_state["audio_features"] = ctc_logits
        return_state["label_adjustments"] = label_adjustments
        return_state["audio_feature_lengths"] = out_lengths  # 每个 sample 的实际音频特征长度

        return return_state


class SpeechLLMForCausalLM(LlamaForCausalLM):
    """
    SpeechLLM for Causal Language Modeling.

    Combines CTC loss from audio encoder with LM loss from text generation.
    """
    config_class = SpeechLLMConfig

    def __init__(self, config: SpeechLLMConfig):
        super().__init__(config)
        self.model = SpeechLLMModel(config)
        self.post_init()

    def get_model(self):
        return self.model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        # Audio inputs
        audios: Optional[torch.FloatTensor] = None,
        audio_lengths: Optional[torch.LongTensor] = None,
        # CTC targets
        asr_targets: Optional[torch.LongTensor] = None,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        """
        Forward pass with audio and text.

        Args:
            asr_targets: [B, L] CTC target token ids (transcription)
        """
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        # Forward through model
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
            audios=audios,
            audio_lengths=audio_lengths,
            asr_targets=asr_targets,
        )
        hidden_states = outputs[0]
        logits = self.lm_head(hidden_states)

        loss = None
        loss_lm = torch.tensor(0.0, device=logits.device)
        loss_asr = torch.tensor(0.0, device=logits.device)

        # Get audio_features and lengths from model outputs
        audio_features = None
        audio_feature_lengths = None
        if isinstance(outputs, dict):
            audio_features = outputs.get("audio_features")
            audio_feature_lengths = outputs.get("audio_feature_lengths")
        elif hasattr(outputs, "audio_features"):
            audio_features = outputs.audio_features
            audio_feature_lengths = getattr(outputs, "audio_feature_lengths", None)

        # Compute CTC loss (independent of labels)
        if asr_targets is not None and audio_features is not None:
            mask_asr_targets = (asr_targets != -100)
            target_lengths = mask_asr_targets.sum(1)
            # 使用实际长度，不是 padding 后的长度
            if audio_feature_lengths is not None:
                input_lengths = audio_feature_lengths
            else:
                # Fallback: 假设所有样本都是完整长度（可能不正确）
                input_lengths = torch.full(
                    size=(audio_features.shape[0],),
                    fill_value=audio_features.shape[1],
                    dtype=torch.long,
                    device=audio_features.device,
                )
            asr_targets_ctc = asr_targets.to(audio_features.device)
            log_probs = F.log_softmax(audio_features, dim=-1).transpose(0, 1)
            with torch.backends.cudnn.flags(enabled=False):
                loss_asr = F.ctc_loss(
                    log_probs, asr_targets_ctc, input_lengths, target_lengths,
                    blank=self.config.ctc_blank_token,
                    reduction='mean', zero_infinity=True,
                )
            loss_asr = loss_asr.to(logits.device)

        if labels is not None:
            # LM loss
            _debug = os.environ.get("SPEECH_LLM_DEBUG", "0") == "1"
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            # DEBUG: 原始labels信息
            if _debug: print(f"\n[DEBUG] === Labels Processing ===", flush=True)
            if _debug: print(f"[DEBUG] Original labels shape: {labels.shape}", flush=True)
            if _debug: print(f"[DEBUG] shift_labels shape (before adjust): {shift_labels.shape}", flush=True)
            if _debug: print(f"[DEBUG] shift_logits shape: {shift_logits.shape}", flush=True)
            # 打印第一个样本的labels内容
            non_ignored = (shift_labels[0] != -100).nonzero()
            if len(non_ignored) > 0:
                start = non_ignored[0].item()
                end = non_ignored[-1].item()
                if _debug: print(f"[DEBUG] sample 0: non-ignored labels range [{start}, {end}]", flush=True)
                if _debug: print(f"[DEBUG] sample 0: labels content (non-ignored): {shift_labels[0, start:end+1].tolist()}", flush=True)

            # Adjust labels for audio feature insertion
            label_adjustments = None
            if isinstance(outputs, dict):
                label_adjustments = outputs.get("label_adjustments")
            elif hasattr(outputs, "label_adjustments"):
                label_adjustments = outputs.label_adjustments

            if _debug: print(f"[DEBUG] label_adjustments: {label_adjustments}", flush=True)

            if label_adjustments is not None and len(label_adjustments) > 0:
                batch_expanded_labels = []
                for i, (audio_pos, audio_len) in enumerate(label_adjustments):
                    if audio_len == 0:
                        batch_expanded_labels.append(shift_labels[i])
                        continue

                    orig_labels = shift_labels[i]

                    before_labels = orig_labels[:audio_pos]
                    audio_labels = torch.full(
                        (audio_len,), -100, dtype=torch.long, device=orig_labels.device
                    )
                    # AUD occupies 1 slot in input_ids, replaced by audio_len slots in
                    # inputs_embeds. shift_labels[audio_pos] is the label for the token
                    # right after AUD (= labels[audio_pos+1]), which has no corresponding
                    # logit since that slot is absorbed into the audio expansion. Skip it.
                    after_labels = orig_labels[audio_pos + 1:]

                    expanded = torch.cat([before_labels, audio_labels, after_labels], dim=0)
                    
                    # DEBUG: 展示label扩展过程
                    if i == 0:
                        if _debug: print(f"\n[DEBUG] === Label Expansion (sample 0) ===", flush=True)
                        if _debug: print(f"[DEBUG] audio_pos: {audio_pos}, audio_len: {audio_len}", flush=True)
                        if _debug: print(f"[DEBUG] before_labels shape: {before_labels.shape}, content: {before_labels.tolist()[:20]}...", flush=True)
                        if _debug: print(f"[DEBUG] audio_labels shape: {audio_labels.shape} (all -100)", flush=True)
                        if _debug: print(f"[DEBUG] after_labels shape: {after_labels.shape}, content (first 30): {after_labels.tolist()[:30]}", flush=True)
                        if _debug: print(f"[DEBUG] expanded labels shape: {expanded.shape}", flush=True)
                    
                    batch_expanded_labels.append(expanded)

                # Pad to match shift_logits sequence length
                target_len = shift_logits.size(1)
                if _debug: print(f"\n[DEBUG] target_len (from shift_logits): {target_len}", flush=True)
                padded_labels = torch.full(
                    (len(batch_expanded_labels), target_len), -100,
                    dtype=torch.long, device=shift_labels.device
                )
                for i, l in enumerate(batch_expanded_labels):
                    if l.size(0) <= target_len:
                        padded_labels[i, :l.size(0)] = l
                    else:
                        # expanded is longer than target_len: this means the audio-expanded
                        # sequence exceeds max_length. Truncate from the FRONT (keep the
                        # response labels at the end, discard early -100 padding).
                        padded_labels[i] = l[-target_len:]
                        if i == 0:
                            if _debug: print(f"[DEBUG] WARNING: expanded labels ({l.size(0)}) > target_len ({target_len}), truncated", flush=True)
                shift_labels = padded_labels
                
                # DEBUG: 最终的labels
                if _debug: print(f"\n[DEBUG] === Final Labels ===", flush=True)
                if _debug: print(f"[DEBUG] final shift_labels shape: {shift_labels.shape}", flush=True)
                non_ignored_final = (shift_labels[0] != -100).nonzero()
                if len(non_ignored_final) > 0:
                    start = non_ignored_final[0].item()
                    end = non_ignored_final[-1].item()
                    if _debug: print(f"[DEBUG] sample 0: final non-ignored labels range [{start}, {end}]", flush=True)
                    if _debug: print(f"[DEBUG] sample 0: final labels content (non-ignored): {shift_labels[0, start:end+1].tolist()}", flush=True)
                shift_labels = padded_labels

            loss_fct = nn.CrossEntropyLoss()
            shift_logits = shift_logits.view(-1, self.config.vocab_size)
            shift_labels = shift_labels.view(-1)
            shift_labels = shift_labels.to(shift_logits.device)

            loss_lm = loss_fct(shift_logits, shift_labels)

            # Combined loss
            # When freeze_adapter=True, CTC loss is excluded from backprop
            # (adapter weights are frozen, no point training LLM with CTC gradient)
            # loss_asr is still computed and reported for monitoring purposes
            lm_weight = self.config.lm_weight
            if self.config.freeze_adapter:
                loss = lm_weight * loss_lm
            else:
                ctc_weight = self.config.ctc_weight
                loss = lm_weight * loss_lm + ctc_weight * loss_asr

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        # Create output with loss_asr for swift logging
        output = SpeechLLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            loss_asr=loss_asr if loss_asr.item() > 0 else None,
            loss_lm=loss_lm if loss_lm.item() > 0 else None,
        )

        return output

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        **kwargs,
    ):
        """Prepare inputs for generation."""
        model_inputs = super().prepare_inputs_for_generation(
            input_ids,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
            **kwargs,
        )

        # Pass audio inputs
        if "audios" in kwargs:
            model_inputs["audios"] = kwargs["audios"]
        if "audio_lengths" in kwargs:
            model_inputs["audio_lengths"] = kwargs["audio_lengths"]

        return model_inputs

    def _update_model_kwargs_for_generation(self, outputs, model_kwargs, **kwargs):
        """Override to fix cache_position and attention_mask after audio token insertion in prefill."""
        model_kwargs = super()._update_model_kwargs_for_generation(outputs, model_kwargs, **kwargs)

        # After prefill, cache_position and attention_mask are based on original input_ids length
        # (before audio insertion). But KV cache actually holds more tokens (audio tokens inserted).
        # Fix both by reading actual KV cache length.
        past_key_values = model_kwargs.get("past_key_values", None)
        if past_key_values is not None and hasattr(past_key_values, "get_seq_length"):
            actual_len = past_key_values.get_seq_length()
            # Fix cache_position
            cache_position = model_kwargs.get("cache_position", None)
            if cache_position is not None and cache_position[-1].item() != actual_len:
                model_kwargs["cache_position"] = torch.tensor(
                    [actual_len], dtype=cache_position.dtype, device=cache_position.device
                )
            # Fix attention_mask: extend to actual_len if shorter
            attention_mask = model_kwargs.get("attention_mask", None)
            if attention_mask is not None:
                current_len = attention_mask.shape[1]
                if current_len < actual_len:
                    extra = torch.ones(
                        attention_mask.shape[0], actual_len - current_len,
                        dtype=attention_mask.dtype, device=attention_mask.device
                    )
                    model_kwargs["attention_mask"] = torch.cat([attention_mask, extra], dim=1)

        return model_kwargs


# Register with transformers
AutoConfig.register("speech_llm", SpeechLLMConfig)
AutoModelForCausalLM.register(SpeechLLMConfig, SpeechLLMForCausalLM)
