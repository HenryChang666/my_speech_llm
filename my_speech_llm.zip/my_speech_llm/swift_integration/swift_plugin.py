"""
Swift plugin for SpeechLLM integration.

This module registers the SpeechLLM model with ms-swift framework.
"""

import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import torch
from typing import Optional, Dict, Any

# Import transformers components
from transformers import AutoTokenizer, PretrainedConfig

# Import swift components
try:
    from swift.model import register_model, ModelMeta, ModelGroup, Model, ModelLoader
    from swift.model.constant import MLLMModelType
    from swift.template import register_template, TemplateMeta, Template
    from swift.template.constant import MLLMTemplateType
    from swift.utils import get_logger, Processor

    SWIFT_AVAILABLE = True
except ImportError:
    SWIFT_AVAILABLE = False
    print("Warning: ms-swift not available. Skipping swift plugin registration.")

from .model import SpeechLLMConfig, SpeechLLMForCausalLM

logger = get_logger() if SWIFT_AVAILABLE else None


class SpeechLLMLoader(ModelLoader):
    """
    Custom model loader for SpeechLLM.

    Handles loading of SpeechLLM with Phase 1 checkpoint initialization.
    """

    def get_config(self, model_dir: str) -> PretrainedConfig:
        """Get model config."""
        # Load base LLaMA config and convert to SpeechLLMConfig
        from transformers import AutoConfig

        base_config = AutoConfig.from_pretrained(model_dir)

        # Create SpeechLLMConfig from base config
        config = SpeechLLMConfig.from_dict(base_config.to_dict())

        # Set phase1 checkpoint from environment or config
        phase1_checkpoint = os.environ.get("PHASE1_CHECKPOINT", None)
        if phase1_checkpoint:
            config.phase1_checkpoint = phase1_checkpoint

        # Set other config values from environment
        if os.environ.get("FREEZE_ENCODER", "true").lower() == "true":
            config.freeze_encoder = True
        if os.environ.get("FREEZE_ADAPTER", "false").lower() == "true":
            config.freeze_adapter = True

        config.ctc_weight = float(os.environ.get("CTC_WEIGHT", "0.3"))
        config.lm_weight = float(os.environ.get("LM_WEIGHT", "1.0"))

        return config

    def get_model(self, model_dir: str, config, processor, model_kwargs) -> torch.nn.Module:
        """Load SpeechLLM model."""
        if self.torch_dtype is not None:
            model_kwargs["torch_dtype"] = self.torch_dtype

        # Load model
        model = SpeechLLMForCausalLM.from_pretrained(
            model_dir,
            config=config,
            **model_kwargs
        )

        return model

    def get_processor(self, model_dir: str, config: PretrainedConfig) -> Processor:
        """Get tokenizer/processor."""
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        # No need to add audio_patch_token - we use existing reserved token (128002)
        return tokenizer


def register_speech_llm():
    """Register SpeechLLM with swift."""
    if not SWIFT_AVAILABLE:
        return

    # Register model
    register_model(
        ModelMeta(
            MLLMModelType.speech_llm,
            [
                ModelGroup([
                    Model("my_speech_llm/phase2", "my_speech_llm/phase2"),
                ]),
            ],
            SpeechLLMLoader,
            template=MLLMTemplateType.speech_llm,
            model_arch="speech_llm",
            architectures=["SpeechLLMForCausalLM"],
            requires=["transformers>=4.40"],
            tags=["audio"],
        )
    )

    # Register template
    register_template(
        TemplateMeta(
            MLLMTemplateType.speech_llm,
            prefix=["<|begin_of_text|>"],
            prompt=[
                "<|start_header_id|>user<|end_header_id|>\n\n<audio_patch>{{QUERY}}<|eot_id|>"
                "<|start_header_id|>assistant<|end_header_id|>\n\n"
            ],
            chat_sep=["<|eot_id|>"],
            suffix=["<|eot_id|>"],
            system_prefix=["<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n{{SYSTEM}}<|eot_id|>"],
        )
    )

    logger.info("SpeechLLM registered with swift")


# Auto-register when module is imported
if SWIFT_AVAILABLE:
    # Add model type to MLLMModelType if not present
    if not hasattr(MLLMModelType, "speech_llm"):
        MLLMModelType.speech_llm = "speech_llm"

    # Add template type if not present
    try:
        from swift.template.constant import MLLMTemplateType
        if not hasattr(MLLMTemplateType, "speech_llm"):
            MLLMTemplateType.speech_llm = "speech_llm"
    except:
        pass

    register_speech_llm()
