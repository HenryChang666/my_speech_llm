"""
Custom trainer for SpeechLLM Phase 2 training.

This trainer integrates with ms-swift's training loop while handling
audio inputs and dual loss (CTC + LM).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Any

from transformers import Trainer
from transformers.trainer_pt_utils import LabelSmoother

IGNORE_TOKEN_ID = LabelSmoother.ignore_index


class SpeechLLMTrainer(Trainer):
    """
    Custom trainer for SpeechLLM with dual loss.

    Handles:
    1. Audio input processing
    2. CTC loss computation
    3. LM loss computation
    4. Combined loss with weighting
    """

    def __init__(
        self,
        ctc_weight: float = 0.3,
        lm_weight: float = 1.0,
        audio_patch_token: int = 128002,  # For backward compatibility, used as placeholder
        ctc_blank_token: int = 128256,     # CTC blank token
        **kwargs
    ):
        super().__init__(**kwargs)
        self.ctc_weight = ctc_weight
        self.lm_weight = lm_weight
        self.audio_patch_token = audio_patch_token  # placeholder in input_ids
        self.ctc_blank_token = ctc_blank_token

        # CTC loss function (blank token for CTC)
        self.ctc_loss_fn = nn.CTCLoss(
            blank=ctc_blank_token,
            reduction='mean',
            zero_infinity=True,
        )

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        """
        Compute combined CTC + LM loss.

        Args:
            inputs: dict with keys:
                - input_ids: [B, L]
                - labels: [B, L]
                - attention_mask: [B, L]
                - audios: [B, T, 80] (optional)
                - audio_lengths: [B] (optional)
                - asr_targets: [B, L] CTC targets (optional)
        """
        # Extract audio inputs
        audios = inputs.pop("audios", None)
        audio_lengths = inputs.pop("audio_lengths", None)
        asr_targets = inputs.pop("asr_targets", None)

        # Forward pass
        outputs = model(
            **inputs,
            audios=audios,
            audio_lengths=audio_lengths,
            asr_targets=asr_targets,
        )

        # Get losses from outputs
        loss = outputs.loss

        if return_outputs:
            return loss, outputs
        return loss

    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        """Prediction step for evaluation."""
        # Extract audio inputs
        audios = inputs.pop("audios", None) if "audios" in inputs else None
        audio_lengths = inputs.pop("audio_lengths", None) if "audio_lengths" in inputs else None
        asr_targets = inputs.pop("asr_targets", None) if "asr_targets" in inputs else None

        # Add to inputs if present
        if audios is not None:
            inputs["audios"] = audios
        if audio_lengths is not None:
            inputs["audio_lengths"] = audio_lengths
        if asr_targets is not None:
            inputs["asr_targets"] = asr_targets

        return super().prediction_step(model, inputs, prediction_loss_only, ignore_keys)


def data_collator(features, pad_token_id=128009, audio_pad_val=0.0) -> Dict[str, Any]:
    """
    Custom data collator for SpeechLLM.

    Handles batching of audio and text data.
    """
    # Separate audio and text features
    batch = {}

    # Pad input_ids
    if "input_ids" in features[0]:
        input_ids = [f["input_ids"] for f in features]
        max_len = max(len(x) for x in input_ids)
        padded_ids = torch.full((len(features), max_len), pad_token_id, dtype=torch.long)
        for i, ids in enumerate(input_ids):
            padded_ids[i, :len(ids)] = torch.tensor(ids, dtype=torch.long)
        batch["input_ids"] = padded_ids

    # Pad labels
    if "labels" in features[0]:
        labels = [f["labels"] for f in features]
        max_len = max(len(x) for x in labels)
        padded_labels = torch.full((len(features), max_len), IGNORE_TOKEN_ID, dtype=torch.long)
        for i, lbl in enumerate(labels):
            padded_labels[i, :len(lbl)] = torch.tensor(lbl, dtype=torch.long)
        batch["labels"] = padded_labels

    # Pad attention_mask
    if "attention_mask" in features[0]:
        attention_masks = [f["attention_mask"] for f in features]
        max_len = max(len(x) for x in attention_masks)
        padded_mask = torch.zeros((len(features), max_len), dtype=torch.long)
        for i, mask in enumerate(attention_masks):
            padded_mask[i, :len(mask)] = torch.tensor(mask, dtype=torch.long)
        batch["attention_mask"] = padded_mask

    # Pad audio features
    if "audios" in features[0] and features[0]["audios"] is not None:
        audios = [f["audios"] for f in features]
        max_len = max(a.shape[0] for a in audios)
        max_fbank_dim = audios[0].shape[-1] if len(audios[0].shape) > 1 else 80

        padded_audios = torch.full(
            (len(features), max_len, max_fbank_dim),
            audio_pad_val,
            dtype=torch.float32
        )
        audio_lengths = []
        for i, audio in enumerate(audios):
            length = audio.shape[0]
            padded_audios[i, :length] = torch.tensor(audio, dtype=torch.float32)
            audio_lengths.append(length)

        batch["audios"] = padded_audios
        batch["audio_lengths"] = torch.tensor(audio_lengths, dtype=torch.long)

    # Pad asr_targets (CTC targets)
    if "asr_targets" in features[0] and features[0]["asr_targets"] is not None:
        asr_targets = [f["asr_targets"] for f in features]
        max_len = max(len(x) for x in asr_targets)
        padded_targets = torch.full((len(features), max_len), IGNORE_TOKEN_ID, dtype=torch.long)
        for i, tgt in enumerate(asr_targets):
            padded_targets[i, :len(tgt)] = torch.tensor(tgt, dtype=torch.long)
        batch["asr_targets"] = padded_targets

    return batch
