"""
Swift plugin for SpeechLLM - registers the model with ms-swift

This file should be imported before running swift sft:
    PYTHONPATH=/root/my_speech_llm:$PYTHONPATH swift sft ...

Example usage:
    cd /root/my_speech_llm
    PYTHONPATH=/root/my_speech_llm:$PYTHONPATH swift sft \
        --model /root/workspace/models/llama31-8b-instruct \
        --model_type speech_llm \
        --dataset <your_dataset> \
        --torch_dtype bfloat16 \
        --freeze_vit true \
        --freeze_aligner false \
        ...
"""

import os
import sys
import torch
import json
from pathlib import Path
from typing import List, Literal, Dict, Any, Optional

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
from swift.model import register_model, ModelMeta, ModelGroup, Model
from swift.model.register import ModelLoader
from swift.model.constant import MLLMModelType
from swift.model.model_arch import register_model_arch, MultiModelKeys
from swift.template import register_template, TemplateMeta, Template
from swift.template.base import StdTemplateInputs, Context
from swift.template.constant import MLLMTemplateType
from swift.utils import get_logger
from functools import partial

from models.encoder import SpeechEncoder
from models.multiscale_encoder import MultiscaleEncoder, validate_interleaved_config
from models.alignment_adapter import AlignmentAdapter

logger = get_logger()

# Register SpeechLLMConfig with transformers AutoConfig
# This must happen before any model loading
from swift_integration.model import SpeechLLMConfig, SpeechLLMForCausalLM
AutoConfig.register("speech_llm", SpeechLLMConfig)
AutoModelForCausalLM.register(SpeechLLMConfig, SpeechLLMForCausalLM)
logger.info("SpeechLLMConfig and SpeechLLMForCausalLM registered with transformers")


class SpeechLLMLoader(ModelLoader):
    """Custom loader for SpeechLLM that loads Phase 1 components"""

    def get_config(self, model_dir: str):
        """Get config and add SpeechLLM specific parameters"""
        from swift_integration.model import SpeechLLMConfig

        # Load base LLaMA config
        base_config = AutoConfig.from_pretrained(model_dir, trust_remote_code=True)

        # Convert to SpeechLLMConfig
        config_dict = base_config.to_dict()

        # Load Phase 1 checkpoint path from environment
        phase1_ckpt = os.environ.get(
            "PHASE1_CHECKPOINT",
            "/root/workspace/my_speech_llm/checkpoints/phase1_multiscale/ckpt_best.pt"
        )

        # Create SpeechLLMConfig
        config = SpeechLLMConfig.from_dict(config_dict)
        config.phase1_checkpoint = phase1_ckpt
        config.ctc_weight = float(os.environ.get("CTC_WEIGHT", "0.3"))
        config.lm_weight = float(os.environ.get("LM_WEIGHT", "1.0"))
        config.freeze_encoder = os.environ.get("FREEZE_ENCODER", "true").lower() == "true"
        config.freeze_adapter = os.environ.get("FREEZE_ADAPTER", "false").lower() == "true"
        config.tokenizer_path = model_dir  # For decoding CTC output in debug

        logger.info(f"SpeechLLMConfig created with phase1_checkpoint: {phase1_ckpt}")
        logger.info(f"  ctc_weight: {config.ctc_weight}, lm_weight: {config.lm_weight}")
        logger.info(f"  freeze_encoder: {config.freeze_encoder}, freeze_adapter: {config.freeze_adapter}")

        return config

    def get_model(self, model_dir: str, config, processor, model_kwargs) -> "PreTrainedModel":
        """Load model with Phase 1 components"""
        from swift_integration.model import SpeechLLMForCausalLM

        # Set auto_model_cls for proper loading
        self.auto_model_cls = SpeechLLMForCausalLM

        # Load the model
        model = SpeechLLMForCausalLM.from_pretrained(
            model_dir,
            config=config,
            trust_remote_code=True,
            **model_kwargs
        )

        logger.info(f"SpeechLLM model loaded from {model_dir}")
        logger.info(f"  Total parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M")

        return model


class SpeechLLMTemplate(Template):
    """Template for SpeechLLM with audio input"""

    # Input placeholder token: must exist in LLaMA vocab
    # Using <|reserved_special_token_0|> (128002) as audio placeholder
    audio_placeholder_token = 128002

    def replace_tag(self, media_type: Literal['image', 'video', 'audio'], index: int,
                    inputs: StdTemplateInputs) -> List[Context]:
        assert media_type == 'audio'
        # Directly return token id 128002 as audio placeholder
        # Context = Union[str, List[int]], so returning List[int] works
        # This avoids the need for complex token replacement logic later
        return [[self.audio_placeholder_token]]  # [[128002]] - list of token ids

    def _encode(self, inputs: StdTemplateInputs) -> Dict[str, Any]:
        encoded = super()._encode(inputs)
        if inputs.audios:
            # Load audio and convert to fbank features (same as phase1)
            from data.dataset import compute_fbank
            import torch

            # Take the first audio (single audio per sample for ASR)
            audio_path = inputs.audios[0]
            fbank = compute_fbank(audio_path)  # [T, 80]

            encoded['audios'] = fbank  # [T, 80]
            encoded['audio_lengths'] = torch.tensor(fbank.shape[0], dtype=torch.long)

        # Note: No need to replace tokens anymore
        # replace_tag now directly returns token id 128002
        # So input_ids and labels are already correctly aligned

        return encoded

    def _data_collator(self, batch: List[Dict[str, Any]], *, padding_to: Optional[int] = None) -> Dict[str, Any]:
        res = super()._data_collator(batch, padding_to=padding_to)
        # Handle audio batching - audios are [T, 80] tensors, pad to [B, T_max, 80]
        from torch.nn.utils.rnn import pad_sequence

        audios = [b['audios'] for b in batch if b.get('audios') is not None]
        audio_lengths = [b['audio_lengths'] for b in batch if b.get('audio_lengths') is not None]

        if audios:
            res['audios'] = pad_sequence(audios, batch_first=True, padding_value=0.0)
            res['audio_lengths'] = torch.stack(audio_lengths)
        return res


# Register model type if not exists
if not hasattr(MLLMModelType, "speech_llm"):
    MLLMModelType.speech_llm = "speech_llm"

# Register model architecture for freeze_vit/freeze_aligner support
# Note: vision_tower is empty because encoder is lazy-loaded (None at init time)
# We handle freeze_encoder manually in model.py
register_model_arch(
    MultiModelKeys(
        arch_name="speech_llm",
        language_model='model',  # LLM part
        aligner='model.adapter',  # Adapter part
        vision_tower=[],  # Encoder is lazy-loaded, handle freeze_encoder manually
    ),
    exist_ok=True
)

# Register the model
register_model(
    ModelMeta(
        MLLMModelType.speech_llm,
        [ModelGroup([Model("my_speech_llm/phase2", "my_speech_llm/phase2")])],
        SpeechLLMLoader,
        template="speech_llm",  # Use string directly
        model_arch="speech_llm",
        architectures=["SpeechLLMForCausalLM"],
        tags=["audio"],
    ),
    exist_ok=True
)

# Register template using string type
# Note: <audio> tag is automatically inserted by swift before query for audio datasets
# Do NOT add <audio> or <audio_patch> in the prompt manually
register_template(
    TemplateMeta(
        "speech_llm",  # Use string directly instead of MLLMTemplateType
        prefix=["<|begin_of_text|>"],
        prompt=[
            "<|start_header_id|>user<|end_header_id|>\n\n{{QUERY}}<|eot_id|>"
            "<|start_header_id|>assistant<|end_header_id|>\n\n"
        ],
        chat_sep=["<|eot_id|>"],
        suffix=["<|eot_id|>"],
        system_prefix=["<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n{{SYSTEM}}<|eot_id|>"],
        template_cls=SpeechLLMTemplate,  # Use our custom template class!
    ),
    exist_ok=True
)

logger.info("SpeechLLM registered with swift successfully!")
