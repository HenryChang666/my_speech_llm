"""
Chat template for Phase 2 speech-to-text training.

Based on Soundwave and LLaMA-3 format:
- System prompt (optional)
- User message with audio placeholder
- Assistant response (transcription)

Special tokens:
- audio_placeholder_token: 128002 (<|reserved_special_token_0|>) - placeholder in input_ids
- ctc_blank_token: 128256 - used only for CTC loss, not in vocab
- llm_pad_token_id: 128009 (<|eot_id|>)
- bos_token_id: 128000 (<|begin_of_text|>)
- eos_token_id: 128001 (<|end_of_text|>)

LLaMA-3 chat format:
<|begin_of_text|><|start_header_id|>system<|end_header_id|>

You are a helpful assistant<|eot_id|><|start_header_id|>user<|end_header_id|>

[audio tokens]<|eot_id|><|start_header_id|>assistant<|end_header_id|>

[transcription]<|eot_id|>
"""

from typing import Dict, List, Optional
import torch


class SpeechChatTemplate:
    """
    Build chat-formatted inputs for speech-to-text training.
    
    Args:
        tokenizer: HuggingFace tokenizer with special tokens
        audio_patch_token: token id for audio placeholder (default: 128002)
        max_length: maximum sequence length
    """
    
    def __init__(
        self,
        tokenizer,
        audio_patch_token: int = 128002,  # <|reserved_special_token_0|>
        max_length: int = 2048,
    ):
        self.tokenizer = tokenizer
        self.audio_patch_token = audio_patch_token
        self.max_length = max_length
        
        # LLaMA-3 special token ids
        self.bos_id = 128000  # <|begin_of_text|>
        self.eos_id = 128001  # <|end_of_text|>
        self.eot_id = 128009  # <|eot_id|> (end of turn)
        self.start_header_id = 128006  # <|start_header_id|>
        self.end_header_id = 128007    # <|end_header_id|>
        
    def build_prompt(
        self,
        transcription: str,
        system_prompt: Optional[str] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Build a complete chat prompt for training.
        
        Args:
            transcription: ground truth text
            system_prompt: optional system instruction
            
        Returns:
            Dict with:
                - input_ids: full token sequence
                - labels: labels for LM loss (-100 for non-assistant tokens)
                - attention_mask: attention mask
        """
        # Build token lists
        tokens = []
        labels = []
        
        # BOS
        tokens.append(self.bos_id)
        labels.append(-100)  # Don't predict BOS
        
        # System section (optional)
        if system_prompt:
            tokens.extend([
                self.start_header_id,
                self.tokenizer.encode("system", add_special_tokens=False)[0],
                self.end_header_id,
            ])
            labels.extend([-100, -100, -100])
            
            sys_tokens = self.tokenizer.encode(system_prompt, add_special_tokens=False)
            tokens.extend(sys_tokens)
            labels.extend([-100] * len(sys_tokens))
            
            tokens.append(self.eot_id)
            labels.append(-100)
        
        # User section with audio
        tokens.extend([
            self.start_header_id,
            self.tokenizer.encode("user", add_special_tokens=False)[0],
            self.end_header_id,
        ])
        labels.extend([-100, -100, -100])
        
        # Audio patch token - ONLY 1 placeholder (will be replaced by v shrunk features)
        # This matches Soundwave's audio_patch_size=1
        tokens.append(self.audio_patch_token)
        labels.append(-100)  # Don't predict audio tokens
        
        tokens.append(self.eot_id)
        labels.append(-100)
        
        # Assistant section
        tokens.extend([
            self.start_header_id,
            self.tokenizer.encode("assistant", add_special_tokens=False)[0],
            self.end_header_id,
        ])
        labels.extend([-100, -100, -100])
        
        # Transcription (what we want the model to predict)
        trans_tokens = self.tokenizer.encode(transcription, add_special_tokens=False)
        tokens.extend(trans_tokens)
        labels.extend(trans_tokens)  # Predict these!
        
        # EOS
        tokens.append(self.eot_id)
        labels.append(self.eot_id)  # Predict EOT
        
        # Truncate if needed
        if len(tokens) > self.max_length:
            tokens = tokens[:self.max_length]
            labels = labels[:self.max_length]
            # Ensure last token is EOT if truncated
            tokens[-1] = self.eot_id
            labels[-1] = self.eot_id
        
        # Convert to tensors
        input_ids = torch.tensor(tokens, dtype=torch.long)
        labels_tensor = torch.tensor(labels, dtype=torch.long)
        attention_mask = torch.ones_like(input_ids)
        
        return {
            "input_ids": input_ids,
            "labels": labels_tensor,
            "attention_mask": attention_mask,
        }
    
    def build_inference_prompt(
        self,
        system_prompt: Optional[str] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Build prompt for inference (no labels, no transcription).
        """
        tokens = []
        
        # BOS
        tokens.append(self.bos_id)
        
        # System
        if system_prompt:
            tokens.extend([
                self.start_header_id,
                self.tokenizer.encode("system", add_special_tokens=False)[0],
                self.end_header_id,
            ])
            sys_tokens = self.tokenizer.encode(system_prompt, add_special_tokens=False)
            tokens.extend(sys_tokens)
            tokens.append(self.eot_id)
        
        # User with audio
        tokens.extend([
            self.start_header_id,
            self.tokenizer.encode("user", add_special_tokens=False)[0],
            self.end_header_id,
        ])
        
        # Audio patch token - ONLY 1 placeholder
        tokens.append(self.audio_patch_token)
        tokens.append(self.eot_id)
        
        # Assistant header (model should generate after this)
        tokens.extend([
            self.start_header_id,
            self.tokenizer.encode("assistant", add_special_tokens=False)[0],
            self.end_header_id,
        ])
        
        input_ids = torch.tensor(tokens, dtype=torch.long)
        attention_mask = torch.ones_like(input_ids)
        
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from transformers import AutoTokenizer
    
    tokenizer = AutoTokenizer.from_pretrained("/root/workspace/models/llama31-8b-instruct")
    
    template = SpeechChatTemplate(
        tokenizer=tokenizer,
        audio_patch_token=128002,  # <|reserved_special_token_0|>
        max_length=512,
    )
    
    result = template.build_prompt(
        transcription="你好世界",
        system_prompt="You are a helpful assistant.",
    )
    
    print(f"Input IDs shape: {result['input_ids'].shape}")
    print(f"Labels shape: {result['labels'].shape}")
    
    # Count audio patch tokens
    audio_patch_count = (result['input_ids'] == 128002).sum().item()
    print(f"Num audio patch tokens: {audio_patch_count}")
    
    # Decode to check format
    decoded = tokenizer.decode(result['input_ids'])
    print(f"\nDecoded prompt:\n{decoded[:200]}...")
