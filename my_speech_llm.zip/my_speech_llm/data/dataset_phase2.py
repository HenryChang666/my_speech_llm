"""
Phase 2 Dataset for Swift training.

Combines:
    1. Audio loading and fbank extraction
    2. Chat template formatting
    3. CTC shrink (to determine num_audio_patches)
    
Compatible with Swift's multimodal training pipeline.
"""

import os
import csv
import torch
import numpy as np
import soundfile as sf
import torchaudio.compliance.kaldi as kaldi
from torch.utils.data import Dataset
from typing import Dict, List, Optional
from pathlib import Path

from data.dataset import _CSV_MAP, _WAV_ROOT_MAP, compute_fbank
from data.template import SpeechChatTemplate


class AISHELLPhase2Dataset(Dataset):
    """
    AISHELL dataset for Phase 2: speech-to-text with chat template.
    
    Each sample returns:
        - fbank: [T, 80] audio features
        - fbank_length: int
        - transcription: str
        - input_ids: [L] token ids with ONE audio_patch_token
        - labels: [L] with -100 for non-assistant tokens
        - attention_mask: [L]
    """
    
    def __init__(
        self,
        split: str,
        tokenizer,
        template: SpeechChatTemplate,
        max_frames: int = 3000,
        max_tokens: int = 256,
        system_prompt: Optional[str] = None,
    ):
        assert split in _CSV_MAP, f"Unknown split '{split}'"
        
        self.split = split
        self.tokenizer = tokenizer
        self.template = template
        self.max_frames = max_frames
        self.max_tokens = max_tokens
        self.system_prompt = system_prompt
        self.wav_root = _WAV_ROOT_MAP[split]
        
        self.samples = self._load_csv(_CSV_MAP[split])
        print(f"[AISHELLPhase2Dataset] split={split} samples={len(self.samples)}")
    
    def _load_csv(self, csv_path: Path) -> List[Dict]:
        """Load and filter samples."""
        samples = []
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                audio_rel = row["Audio:FILE"].strip()
                text = row["Text:LABEL"].strip().replace(" ", "")
                wav_path = str(self.wav_root / audio_rel)
                
                if not os.path.exists(wav_path):
                    continue
                
                # Check token length
                tokens = self.tokenizer.encode(text, add_special_tokens=False)
                if len(tokens) == 0 or len(tokens) > self.max_tokens:
                    continue
                
                samples.append({
                    "wav_path": wav_path,
                    "text": text,
                })
        
        return samples
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Optional[Dict]:
        item = self.samples[idx]
        
        try:
            # Load audio
            fbank = compute_fbank(item["wav_path"])  # [T, 80]
        except Exception as e:
            print(f"[Warning] failed to load {item['wav_path']}: {e}")
            return None
        
        if fbank.size(0) > self.max_frames:
            return None
        
        # Build chat prompt (1 audio_patch_token placeholder)
        prompt_data = self.template.build_prompt(
            transcription=item["text"],
            system_prompt=self.system_prompt,
        )
        
        return {
            "fbank": fbank,
            "fbank_length": fbank.size(0),
            "transcription": item["text"],
            "input_ids": prompt_data["input_ids"],
            "labels": prompt_data["labels"],
            "attention_mask": prompt_data["attention_mask"],
        }


class Phase2Collator:
    """
    Collator for Phase 2 training.
    
    Handles:
        - Padding fbank and text sequences
        - Creating batch tensors
    """
    
    def __init__(self, pad_id: int = 0, audio_pad_val: float = 0.0):
        self.pad_id = pad_id
        self.audio_pad_val = audio_pad_val
    
    def __call__(self, batch: List[Optional[Dict]]) -> Optional[Dict]:
        # Filter None
        batch = [b for b in batch if b is not None]
        if len(batch) == 0:
            return None
        
        # Pad fbank
        fbanks = [b["fbank"] for b in batch]
        max_fbank_len = max(f.size(0) for f in fbanks)
        
        fbank_padded = torch.full(
            (len(batch), max_fbank_len, 80),
            self.audio_pad_val,
            dtype=fbanks[0].dtype,
        )
        fbank_lengths = []
        for i, f in enumerate(fbanks):
            fbank_padded[i, :f.size(0)] = f
            fbank_lengths.append(f.size(0))
        
        # Pad text sequences
        input_ids = [b["input_ids"] for b in batch]
        labels = [b["labels"] for b in batch]
        attention_mask = [b["attention_mask"] for b in batch]
        
        max_text_len = max(len(x) for x in input_ids)
        
        input_ids_padded = torch.full((len(batch), max_text_len), self.pad_id, dtype=torch.long)
        labels_padded = torch.full((len(batch), max_text_len), -100, dtype=torch.long)
        attention_mask_padded = torch.zeros((len(batch), max_text_len), dtype=torch.long)
        
        for i in range(len(batch)):
            l = len(input_ids[i])
            input_ids_padded[i, :l] = input_ids[i]
            labels_padded[i, :l] = labels[i]
            attention_mask_padded[i, :l] = attention_mask[i]
        
        return {
            "fbank": fbank_padded,
            "fbank_lengths": torch.tensor(fbank_lengths, dtype=torch.long),
            "input_ids": input_ids_padded,
            "labels": labels_padded,
            "attention_mask": attention_mask_padded,
            "transcriptions": [b["transcription"] for b in batch],
        }


# ---------------------------------------------------------------------------
# Swift-compatible wrapper
# ---------------------------------------------------------------------------

def build_phase2_dataloader(
    split: str,
    tokenizer,
    template: SpeechChatTemplate,
    batch_size: int = 4,
    num_workers: int = 4,
    max_frames: int = 3000,
    max_tokens: int = 256,
    system_prompt: Optional[str] = None,
) -> torch.utils.data.DataLoader:
    """Build DataLoader for Phase 2."""
    from torch.utils.data import DataLoader
    
    dataset = AISHELLPhase2Dataset(
        split=split,
        tokenizer=tokenizer,
        template=template,
        max_frames=max_frames,
        max_tokens=max_tokens,
        system_prompt=system_prompt,
    )
    
    collator = Phase2Collator()
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(split == "train"),
        num_workers=num_workers,
        collate_fn=collator,
        pin_memory=True,
        persistent_workers=(num_workers > 0),
    )


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from transformers import AutoTokenizer
    
    tokenizer = AutoTokenizer.from_pretrained("/root/workspace/models/llama31-8b-instruct")
    template = SpeechChatTemplate(
        tokenizer=tokenizer,
        audio_patch_token=128002,  # <|reserved_special_token_0|>
        max_length=512,
    )
    
    dataset = AISHELLPhase2Dataset(
        split="train",
        tokenizer=tokenizer,
        template=template,
        max_frames=3000,
        system_prompt="You are a helpful speech recognition assistant.",
    )
    
    print(f"Dataset size: {len(dataset)}")
    
    item = dataset[0]
    if item:
        print(f"\nSample keys: {item.keys()}")
        print(f"Fbank shape: {item['fbank'].shape}")
        print(f"Input IDs shape: {item['input_ids'].shape}")
        print(f"Labels shape: {item['labels'].shape}")
        print(f"Transcription: {item['transcription'][:50]}")
        
        # Test collator
        collator = Phase2Collator()
        batch = collator([dataset[i] for i in range(4)])
        print(f"\nBatch fbank: {batch['fbank'].shape}")
        print(f"Batch input_ids: {batch['input_ids'].shape}")
