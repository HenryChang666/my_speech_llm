"""
Multi-scale tokenizer registry for multi-scale CTC training.

Supported tokenizer types:
    spm      : SentencePiece model  (requires model_path)
    char     : Character-level      (requires vocab_path or auto-builds from data)
    pinyin   : Pinyin syllable      (uses pypinyin, optional with_tone)
    phoneme  : Initial + Final      (uses pypinyin, optional with_tone)

Each tokenizer implements:
    encode(text) -> List[int]     token ids (no blank)
    decode(ids)  -> str           reconstructed text
    vocab_size   -> int           number of actual tokens (blank = vocab_size)

Config format (YAML):
    tokenizer:
      type: "spm"
      model_path: "/path/to/model.model"

    tokenizer:
      type: "phoneme"
      with_tone: true
"""

import json
import re
from abc import ABC, abstractmethod
from typing import List, Dict, Optional


# -----------------------------------------------------------------------
# Base class
# -----------------------------------------------------------------------

class BaseTokenizer(ABC):
    """Base class for multi-scale CTC tokenizers."""

    @abstractmethod
    def encode(self, text: str) -> List[int]:
        """Encode text to token ids (no blank token)."""
        ...

    @abstractmethod
    def decode(self, ids: List[int]) -> str:
        """Decode token ids back to text."""
        ...

    @property
    @abstractmethod
    def vocab_size(self) -> int:
        """Number of actual tokens. Blank id = vocab_size."""
        ...

    @property
    def blank_id(self) -> int:
        return self.vocab_size


# -----------------------------------------------------------------------
# SentencePiece tokenizer
# -----------------------------------------------------------------------

class SpmTokenizer(BaseTokenizer):
    """SentencePiece unigram/BPE tokenizer."""

    def __init__(self, model_path: str):
        import sentencepiece as spm
        self.sp = spm.SentencePieceProcessor()
        self.sp.load(model_path)

    def encode(self, text: str) -> List[int]:
        return self.sp.encode(text, out_type=int)

    def decode(self, ids: List[int]) -> str:
        return self.sp.decode(ids)

    @property
    def vocab_size(self) -> int:
        return self.sp.vocab_size()


# -----------------------------------------------------------------------
# Character-level tokenizer
# -----------------------------------------------------------------------

class CharTokenizer(BaseTokenizer):
    """Character-level tokenizer with a fixed vocabulary.

    vocab_path should be a JSON file: {"char": id, ...}
    If not provided, can be built from text data via build_from_texts().
    """

    def __init__(self, vocab_path: Optional[str] = None):
        self._char2id: Dict[str, int] = {}
        self._id2char: Dict[int, str] = {}
        self._unk_id = 0

        if vocab_path is not None:
            self._load_vocab(vocab_path)

    def _load_vocab(self, path: str):
        with open(path, 'r', encoding='utf-8') as f:
            self._char2id = json.load(f)
        self._id2char = {v: k for k, v in self._char2id.items()}
        if '<unk>' in self._char2id:
            self._unk_id = self._char2id['<unk>']

    def build_from_texts(self, texts: List[str], min_freq: int = 1) -> 'CharTokenizer':
        """Build character vocab from training texts."""
        from collections import Counter
        counter = Counter()
        for text in texts:
            for ch in text:
                if ch.strip():
                    counter[ch] += 1
        chars = [ch for ch, cnt in counter.most_common() if cnt >= min_freq]
        self._char2id = {'<unk>': 0}
        for i, ch in enumerate(chars):
            self._char2id[ch] = i + 1
        self._id2char = {v: k for k, v in self._char2id.items()}
        self._unk_id = 0
        return self

    def save_vocab(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self._char2id, f, ensure_ascii=False, indent=2)

    def encode(self, text: str) -> List[int]:
        ids = []
        for ch in text:
            if ch.strip():
                ids.append(self._char2id.get(ch, self._unk_id))
        return ids

    def decode(self, ids: List[int]) -> str:
        return ''.join(self._id2char.get(i, '<unk>') for i in ids)

    @property
    def vocab_size(self) -> int:
        return len(self._char2id)


# -----------------------------------------------------------------------
# Pinyin tokenizer
# -----------------------------------------------------------------------

class PinyinTokenizer(BaseTokenizer):
    """Pinyin syllable-level tokenizer using pypinyin.

    Each Chinese character -> one pinyin syllable token.
    with_tone=True:  rén, gōng, zhì, néng (with diacritics)
    with_tone=False: ren, gong, zhi, neng
    """

    def __init__(self, with_tone: bool = False, vocab_path: Optional[str] = None):
        from pypinyin import pinyin, lazy_pinyin, Style
        self._pinyin = pinyin
        self._lazy_pinyin = lazy_pinyin
        self._Style = Style
        self.with_tone = with_tone
        self._py2id: Dict[str, int] = {}
        self._id2py: Dict[int, str] = {}

        if vocab_path is not None:
            self._load_vocab(vocab_path)

    def _load_vocab(self, path: str):
        with open(path, 'r', encoding='utf-8') as f:
            self._py2id = json.load(f)
        self._id2py = {v: k for k, v in self._py2id.items()}

    def build_from_texts(self, texts: List[str]) -> 'PinyinTokenizer':
        """Scan texts to build pinyin vocab."""
        from collections import Counter
        counter = Counter()
        for text in texts:
            pys = self._text_to_pinyins(text)
            counter.update(pys)
        syls = sorted(counter.keys())
        self._py2id = {'<unk>': 0}
        for i, sy in enumerate(syls):
            self._py2id[sy] = i + 1
        self._id2py = {v: k for k, v in self._py2id.items()}
        return self

    def save_vocab(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self._py2id, f, ensure_ascii=False, indent=2)

    def _text_to_pinyins(self, text: str) -> List[str]:
        if self.with_tone:
            return [p[0] for p in self._pinyin(text, style=self._Style.TONE)]
        else:
            return self._lazy_pinyin(text)

    def encode(self, text: str) -> List[int]:
        pys = self._text_to_pinyins(text)
        return [self._py2id.get(py, 0) for py in pys]

    def decode(self, ids: List[int]) -> str:
        return ' '.join(self._id2py.get(i, '<unk>') for i in ids)

    @property
    def vocab_size(self) -> int:
        return len(self._py2id)


# -----------------------------------------------------------------------
# Phoneme (Initial + Final) tokenizer
# -----------------------------------------------------------------------

class PhonemeTokenizer(BaseTokenizer):
    """Initial + Final phoneme tokenizer using pypinyin.

    Each Chinese character -> 1-2 phoneme tokens (initial + final).
    Zero-initial syllables produce only a final.
    with_tone=True:  finals keep tone diacritics (é, ōng, etc.)
    with_tone=False: finals are plain (e, ong, etc.)
    """

    # 23 Mandarin initials (longest first for matching)
    INITIALS = [
        'zh', 'ch', 'sh',
        'b', 'p', 'm', 'f',
        'd', 't', 'n', 'l',
        'g', 'k', 'h',
        'j', 'q', 'x',
        'r', 'z', 'c', 's',
        'y', 'w',
    ]

    def __init__(self, with_tone: bool = True, vocab_path: Optional[str] = None):
        from pypinyin import pinyin, lazy_pinyin, Style
        self._pinyin = pinyin
        self._lazy_pinyin = lazy_pinyin
        self._Style = Style
        self.with_tone = with_tone
        self._ph2id: Dict[str, int] = {}
        self._id2ph: Dict[int, str] = {}

        if vocab_path is not None:
            self._load_vocab(vocab_path)

    def _load_vocab(self, path: str):
        with open(path, 'r', encoding='utf-8') as f:
            self._ph2id = json.load(f)
        self._id2ph = {v: k for k, v in self._ph2id.items()}

    @staticmethod
    def _split_pinyin(py_str: str) -> tuple:
        """Split a pinyin string into (initial, final)."""
        clean = re.sub(r'[0-9]', '', py_str)
        initial = ''
        for init in sorted(PhonemeTokenizer.INITIALS, key=len, reverse=True):
            if clean.startswith(init):
                initial = init
                break
        final = py_str[len(initial):]
        return initial, final

    def _text_to_phonemes(self, text: str) -> List[str]:
        if self.with_tone:
            pys = [p[0] for p in self._pinyin(text, style=self._Style.TONE)]
        else:
            pys = self._lazy_pinyin(text)
        phonemes = []
        for py in pys:
            init, final = self._split_pinyin(py)
            if init:
                phonemes.append(init)
            if final:
                phonemes.append(final)
        return phonemes

    def build_from_texts(self, texts: List[str]) -> 'PhonemeTokenizer':
        """Scan texts to build phoneme vocab."""
        from collections import Counter
        counter = Counter()
        for text in texts:
            phs = self._text_to_phonemes(text)
            counter.update(phs)
        phs_sorted = sorted(counter.keys())
        self._ph2id = {'<unk>': 0}
        for i, ph in enumerate(phs_sorted):
            self._ph2id[ph] = i + 1
        self._id2ph = {v: k for k, v in self._ph2id.items()}
        return self

    def save_vocab(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self._ph2id, f, ensure_ascii=False, indent=2)

    def encode(self, text: str) -> List[int]:
        phs = self._text_to_phonemes(text)
        return [self._ph2id.get(ph, 0) for ph in phs]

    def decode(self, ids: List[int]) -> str:
        return ' '.join(self._id2ph.get(i, '<unk>') for i in ids)

    @property
    def vocab_size(self) -> int:
        return len(self._ph2id)


# -----------------------------------------------------------------------
# Factory
# -----------------------------------------------------------------------

def build_tokenizer(cfg: dict) -> BaseTokenizer:
    """Build a tokenizer from a config dict.

    Args:
        cfg: dict with at least 'type' key, plus type-specific params.
            type="spm"     -> model_path (required)
            type="char"    -> vocab_path (required)
            type="pinyin"  -> with_tone (default False), vocab_path (required)
            type="phoneme" -> with_tone (default True),  vocab_path (required)

    Returns:
        BaseTokenizer instance
    """
    tok_type = cfg["type"]

    if tok_type == "spm":
        assert "model_path" in cfg, "spm tokenizer requires 'model_path'"
        return SpmTokenizer(model_path=cfg["model_path"])

    elif tok_type == "char":
        assert "vocab_path" in cfg, "char tokenizer requires 'vocab_path'"
        return CharTokenizer(vocab_path=cfg["vocab_path"])

    elif tok_type == "pinyin":
        assert "vocab_path" in cfg, "pinyin tokenizer requires 'vocab_path'"
        return PinyinTokenizer(
            with_tone=cfg.get("with_tone", False),
            vocab_path=cfg["vocab_path"],
        )

    elif tok_type == "phoneme":
        assert "vocab_path" in cfg, "phoneme tokenizer requires 'vocab_path'"
        return PhonemeTokenizer(
            with_tone=cfg.get("with_tone", True),
            vocab_path=cfg["vocab_path"],
        )

    else:
        raise ValueError(f"Unknown tokenizer type: {tok_type}. "
                         f"Supported: spm, char, pinyin, phoneme")
