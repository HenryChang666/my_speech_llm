"""
AISHELLDataset  —  Phase 1 training

Data layout (modelscope cache):
    CSV files (no hash):
        dcd916f7...  -> train  (Audio:FILE relative to trainsets extracted dir)
        b3600d9d...  -> dev
        2d31b77c...  -> test

    Wav root dirs:
        .../extracted/<hash_train>/speech_asr_aishell_trainsets/
        .../extracted/<hash_dev>/speech_asr_aishell_devsets/
        .../extracted/<hash_test>/speech_asr_aishell_testsets/

CSV format:
    Audio:FILE,Text:LABEL
    speech_asr_aishell_trainsets/wav/train/S0002/BAC009S0002W0122.wav,而 对 楼 市 ...
    (Text:LABEL is space-separated Chinese characters)

CTC target format:
    Pure transcription token ids, no BOS/EOS/special tokens.
    This matches Soundwave's design: CTC is only supervised on the speech content.
    The blank token (audio_patch_token=128256) is handled by the CTC loss itself.

Each item returned by __getitem__:
    fbank         : [T, 80]         float32  mel filterbank (80-dim, 25ms/10ms)
    fbank_length  : int             number of valid frames (= T, no padding here)
    ctc_ids       : [L]  LongTensor  LLaMA-3 token ids of the transcription (no BOS/EOS)
    ctc_length    : int             L
    text          : str             original transcription

Collator pads fbank to max_T and ctc_ids to max_L in the batch.
"""

import os
import csv
import torch
import numpy as np
import soundfile as sf
import torchaudio.compliance.kaldi as kaldi
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
from typing import List, Dict, Tuple, Optional
from pathlib import Path
from transformers import AutoTokenizer


# ---------------------------------------------------------------------------
# Hard-coded paths (derived from the modelscope download log)
# ---------------------------------------------------------------------------
_MS_BASE = Path("/root/.cache/modelscope/hub/datasets/speech_asr/speech_asr_aishell1_trainsets/master/data_files")

# CSV meta files (no extension, identified by content inspection)
_CSV_MAP = {
    "train":      _MS_BASE / "dcd916f7a01b91236cd9f05c4f59c75a",
    "validation": _MS_BASE / "b3600d9d588428d3d97a652dd9f7aa06",
    "test":       _MS_BASE / "2d31b77cb9581850863b4cfa5b004d11",
}

# Wav root directories (extracted zip contents)
_WAV_ROOT_MAP = {
    "train":      _MS_BASE / "extracted/9d1055bfede3920a4384f00c40b89c47f0c00ca1b8926613a76d28ce27a28418",
    "validation": _MS_BASE / "extracted/bcd95ebccbcf812b344ba13b6ca59a26cb8c41370f482f27da9aeedc5360e907",
    "test":       _MS_BASE / "extracted/037bf9a958c0e200c49ae900894ba0af40f592bb98f2dab81415c11e8ceac132",
}


# ---------------------------------------------------------------------------
# Fbank feature extractor  (matches fairseq/kaldi convention)
# ---------------------------------------------------------------------------

def compute_fbank(
    wav_path: str,
    num_mel_bins: int = 80,
    frame_length: float = 25.0,   # ms
    frame_shift: float = 10.0,    # ms
    target_sample_rate: int = 16000,
) -> torch.Tensor:
    """Load wav (via soundfile) and compute 80-dim fbank features.

    Returns:
        fbank: [T, 80]  float32
    """
    wav_np, sample_rate = sf.read(wav_path, dtype="float32")
    if wav_np.ndim == 2:
        wav_np = wav_np.mean(axis=1)

    waveform = torch.from_numpy(wav_np).unsqueeze(0)  # [1, T]

    if sample_rate != target_sample_rate:
        import torchaudio
        waveform = torchaudio.functional.resample(waveform, sample_rate, target_sample_rate)

    fbank = kaldi.fbank(
        waveform,
        num_mel_bins=num_mel_bins,
        frame_length=frame_length,
        frame_shift=frame_shift,
        sample_frequency=float(target_sample_rate),
        use_energy=False,
    )
    return fbank  # [T, 80]


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class AISHELLDataset(Dataset):
    """AISHELL-1 dataset reading directly from the modelscope cache.

    Args:
        split      : "train" | "validation" | "test"
        tokenizer  : HuggingFace tokenizer (LLaMA-3) for encoding transcriptions
        max_frames : drop utterances longer than this (in fbank frames)
        max_tokens : drop utterances whose token sequence is longer than this
    """

    def __init__(
        self,
        split: str,
        tokenizer,
        max_frames: int = 3000,
        max_tokens: int = 256,
    ):
        assert split in _CSV_MAP, f"Unknown split '{split}'"
        self.tokenizer = tokenizer
        self.wav_root = _WAV_ROOT_MAP[split]
        self.max_frames = max_frames
        self.max_tokens = max_tokens

        self.samples = self._load_csv(_CSV_MAP[split])
        print(f"[AISHELLDataset] split={split}  samples={len(self.samples)}")

    def _load_csv(self, csv_path: Path) -> List[Dict]:
        samples = []
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                audio_rel = row["Audio:FILE"].strip()
                text = row["Text:LABEL"].strip()
                # text is space-separated characters → join
                text = text.replace(" ", "")
                wav_path = str(self.wav_root / audio_rel)
                if not os.path.exists(wav_path):
                    continue
                # CTC target: pure transcription tokens, no special tokens
                # This matches Soundwave's design — blank (audio_patch_token=128256)
                # is handled by CTC loss, not inserted into target sequence
                token_ids = self.tokenizer.encode(text, add_special_tokens=False)
                if len(token_ids) == 0 or len(token_ids) > self.max_tokens:
                    continue
                samples.append({
                    "wav_path": wav_path,
                    "text": text,
                    "token_ids": token_ids,
                })
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int) -> Optional[Dict]:
        item = self.samples[idx]
        try:
            fbank = compute_fbank(item["wav_path"])  # [T, 80]
        except Exception as e:
            print(f"[Warning] failed to load {item['wav_path']}: {e}")
            return None

        if fbank.size(0) > self.max_frames:
            return None

        return {
            "fbank":        fbank,
            "fbank_length": fbank.size(0),
            "ctc_ids":      torch.tensor(item["token_ids"], dtype=torch.long),
            "ctc_length":   len(item["token_ids"]),
            "text":         item["text"],
        }


# ---------------------------------------------------------------------------
# Collator
# ---------------------------------------------------------------------------

class SpeechCollator:
    """Pad fbank and ctc_ids within a batch."""

    def __init__(self, pad_id: int = 0):
        self.pad_id = pad_id

    def __call__(self, batch: List[Optional[Dict]]) -> Optional[Dict]:
        batch = [b for b in batch if b is not None]
        if len(batch) == 0:
            return None

        fbanks = [b["fbank"] for b in batch]
        fbank_lengths = torch.tensor([b["fbank_length"] for b in batch], dtype=torch.long)
        ctc_ids = [b["ctc_ids"] for b in batch]
        ctc_lengths = torch.tensor([b["ctc_length"] for b in batch], dtype=torch.long)
        texts = [b["text"] for b in batch]

        fbank_padded = pad_sequence(fbanks, batch_first=True, padding_value=0.0)
        ctc_padded = pad_sequence(ctc_ids, batch_first=True, padding_value=self.pad_id)

        return {
            "fbank":         fbank_padded,
            "fbank_lengths": fbank_lengths,
            "ctc_ids":       ctc_padded,
            "ctc_lengths":   ctc_lengths,
            "texts":         texts,
        }


def build_dataloader(
    split: str,
    tokenizer,
    batch_size: int = 16,
    num_workers: int = 4,
    max_frames: int = 3000,
    max_tokens: int = 256,
) -> DataLoader:
    dataset = AISHELLDataset(split, tokenizer, max_frames=max_frames, max_tokens=max_tokens)
    collator = SpeechCollator(pad_id=0)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(split == "train"),
        num_workers=num_workers,
        collate_fn=collator,
        pin_memory=True,
        persistent_workers=(num_workers > 0),
    )


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    tokenizer = AutoTokenizer.from_pretrained("/root/workspace/models/llama31-8b-instruct")
    ds = AISHELLDataset("train", tokenizer)

    item = ds[0]
    print(f"fbank shape  : {item['fbank'].shape}")
    print(f"fbank_length : {item['fbank_length']}")
    print(f"ctc_ids      : {item['ctc_ids'][:10]}  (first 10 tokens)")
    print(f"ctc_length   : {item['ctc_length']}")
    print(f"text         : {item['text'][:30]}")
    # Verify no special tokens in ctc_ids
    assert 128000 not in item['ctc_ids'].tolist(), "BOS should not be in ctc_ids"
    assert 128001 not in item['ctc_ids'].tolist(), "EOS should not be in ctc_ids"
    assert 128256 not in item['ctc_ids'].tolist(), "audio_patch should not be in ctc_ids"
    print("ctc_ids format OK (no special tokens)")

import torch
import numpy as np
import soundfile as sf
import torchaudio.compliance.kaldi as kaldi
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
from typing import List, Dict, Tuple, Optional
from pathlib import Path
from transformers import AutoTokenizer


# ---------------------------------------------------------------------------
# Hard-coded paths (derived from the modelscope download log)
# ---------------------------------------------------------------------------
_MS_BASE = Path("/root/.cache/modelscope/hub/datasets/speech_asr/speech_asr_aishell1_trainsets/master/data_files")

# CSV meta files (no extension, identified by content inspection)
_CSV_MAP = {
    "train":      _MS_BASE / "dcd916f7a01b91236cd9f05c4f59c75a",
    "validation": _MS_BASE / "b3600d9d588428d3d97a652dd9f7aa06",
    "test":       _MS_BASE / "2d31b77cb9581850863b4cfa5b004d11",
}

# Wav root directories (extracted zip contents)
_WAV_ROOT_MAP = {
    "train":      _MS_BASE / "extracted/9d1055bfede3920a4384f00c40b89c47f0c00ca1b8926613a76d28ce27a28418",
    "validation": _MS_BASE / "extracted/bcd95ebccbcf812b344ba13b6ca59a26cb8c41370f482f27da9aeedc5360e907",
    "test":       _MS_BASE / "extracted/037bf9a958c0e200c49ae900894ba0af40f592bb98f2dab81415c11e8ceac132",
}


# ---------------------------------------------------------------------------
# Fbank feature extractor  (matches fairseq/kaldi convention)
# ---------------------------------------------------------------------------

def compute_fbank(
    wav_path: str,
    num_mel_bins: int = 80,
    frame_length: float = 25.0,   # ms
    frame_shift: float = 10.0,    # ms
    target_sample_rate: int = 16000,
) -> torch.Tensor:
    """Load wav (via soundfile) and compute 80-dim fbank features.

    Returns:
        fbank: [T, 80]  float32
    """
    # Use soundfile directly — torchaudio 2.10 defaults to torchcodec which
    # requires an extra install; soundfile is already available and handles
    # 16-bit PCM wav files produced by AISHELL perfectly.
    wav_np, sample_rate = sf.read(wav_path, dtype="float32")  # numpy [T] or [T, C]
    if wav_np.ndim == 2:
        wav_np = wav_np.mean(axis=1)

    waveform = torch.from_numpy(wav_np).unsqueeze(0)  # [1, T]

    # Resample if needed
    if sample_rate != target_sample_rate:
        import torchaudio
        waveform = torchaudio.functional.resample(waveform, sample_rate, target_sample_rate)

    # torchaudio kaldi-compatible fbank  (output: [T, num_mel_bins])
    fbank = kaldi.fbank(
        waveform,
        num_mel_bins=num_mel_bins,
        frame_length=frame_length,
        frame_shift=frame_shift,
        sample_frequency=float(target_sample_rate),
        use_energy=False,
    )
    return fbank  # [T, 80]


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class AISHELLDataset(Dataset):
    """AISHELL-1 dataset reading directly from the modelscope cache.

    Args:
        split      : "train" | "validation" | "test"
        tokenizer  : HuggingFace tokenizer (LLaMA-3) for encoding transcriptions
        max_frames : drop utterances longer than this (in fbank frames)
        max_tokens : drop utterances whose token sequence is longer than this
    """

    def __init__(
        self,
        split: str,
        tokenizer,
        max_frames: int = 3000,   # 30 s at 10 ms shift
        max_tokens: int = 256,
    ):
        assert split in _CSV_MAP, f"Unknown split '{split}'"
        self.tokenizer = tokenizer
        self.wav_root = _WAV_ROOT_MAP[split]
        self.max_frames = max_frames
        self.max_tokens = max_tokens

        self.samples = self._load_csv(_CSV_MAP[split])
        # For train/val: keep all samples
        # For test: optionally limit for faster eval (but default is full test set)
        if split == "test":
            # Keep all by default, but you can uncomment below to limit:
            # self.samples = self.samples[:1000]  # e.g. first 1000 for quick test
            pass
        print(f"[AISHELLDataset] split={split}  samples={len(self.samples)}")

    def _load_csv(self, csv_path: Path) -> List[Dict]:
        samples = []
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                audio_rel = row["Audio:FILE"].strip()
                text = row["Text:LABEL"].strip()
                # text is space-separated characters, join them
                text = text.replace(" ", "")
                wav_path = str(self.wav_root / audio_rel)
                if not os.path.exists(wav_path):
                    continue
                # Tokenise immediately so we can filter by length
                token_ids = self.tokenizer.encode(text, add_special_tokens=False)
                if len(token_ids) == 0 or len(token_ids) > self.max_tokens:
                    continue
                samples.append({
                    "wav_path": wav_path,
                    "text": text,
                    "token_ids": token_ids,
                })
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int) -> Optional[Dict]:
        item = self.samples[idx]
        try:
            fbank = compute_fbank(item["wav_path"])  # [T, 80]
        except Exception as e:
            print(f"[Warning] failed to load {item['wav_path']}: {e}")
            return None

        if fbank.size(0) > self.max_frames:
            return None

        return {
            "fbank":        fbank,                                          # [T, 80]
            "fbank_length": fbank.size(0),                                  # int
            "ctc_ids":      torch.tensor(item["token_ids"], dtype=torch.long),
            "ctc_length":   len(item["token_ids"]),
            "text":         item["text"],
        }


# ---------------------------------------------------------------------------
# Collator
# ---------------------------------------------------------------------------

class SpeechCollator:
    """Pad fbank and ctc_ids within a batch.

    fbank:   [B, T_max, 80]
    ctc_ids: [B, L_max]        (padded with pad_id = 0 by default, ignored in CTC)
    """

    def __init__(self, pad_id: int = 0):
        self.pad_id = pad_id

    def __call__(self, batch: List[Optional[Dict]]) -> Optional[Dict]:
        # Drop None items (failed loads)
        batch = [b for b in batch if b is not None]
        if len(batch) == 0:
            return None

        fbanks = [b["fbank"] for b in batch]
        fbank_lengths = torch.tensor([b["fbank_length"] for b in batch], dtype=torch.long)
        ctc_ids = [b["ctc_ids"] for b in batch]
        ctc_lengths = torch.tensor([b["ctc_length"] for b in batch], dtype=torch.long)
        texts = [b["text"] for b in batch]

        # Pad fbank: pad_sequence expects [T, C] tensors and returns [T_max, B, C]
        fbank_padded = pad_sequence(fbanks, batch_first=True, padding_value=0.0)  # [B, T_max, 80]

        # Pad ctc_ids
        ctc_padded = pad_sequence(ctc_ids, batch_first=True, padding_value=self.pad_id)  # [B, L_max]

        return {
            "fbank":        fbank_padded,   # [B, T_max, 80]
            "fbank_lengths": fbank_lengths,  # [B]
            "ctc_ids":      ctc_padded,     # [B, L_max]
            "ctc_lengths":  ctc_lengths,    # [B]
            "texts":        texts,
        }


def build_dataloader(
    split: str,
    tokenizer,
    batch_size: int = 16,
    num_workers: int = 4,
    max_frames: int = 3000,
    max_tokens: int = 256,
) -> DataLoader:
    dataset = AISHELLDataset(split, tokenizer, max_frames=max_frames, max_tokens=max_tokens)
    collator = SpeechCollator(pad_id=0)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(split == "train"),
        num_workers=num_workers,
        collate_fn=collator,
        pin_memory=True,
        persistent_workers=(num_workers > 0),
    )


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    tokenizer = AutoTokenizer.from_pretrained("/root/workspace/models/llama31-8b-instruct")
    ds = AISHELLDataset("train", tokenizer)

    item = ds[0]
    print(f"fbank shape  : {item['fbank'].shape}")
    print(f"fbank_length : {item['fbank_length']}")
    print(f"ctc_ids      : {item['ctc_ids'][:10]}  (first 10 tokens)")
    print(f"ctc_length   : {item['ctc_length']}")
    print(f"text         : {item['text'][:30]}")

    collator = SpeechCollator()
    batch = collator([ds[i] for i in range(4)])
    print(f"\nBatch fbank      : {batch['fbank'].shape}")
    print(f"Batch fbank_lens : {batch['fbank_lengths']}")
    print(f"Batch ctc_ids    : {batch['ctc_ids'].shape}")
    print(f"Batch ctc_lens   : {batch['ctc_lengths']}")
