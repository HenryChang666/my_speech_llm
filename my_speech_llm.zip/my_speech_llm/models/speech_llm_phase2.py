"""
Phase 2 Speech-LLM Model

Architecture:
    SpeechEncoder (from Phase 1, frozen)
    -> AlignmentAdapter (from Phase 1, fine-tunable)
    -> CTCShrinker (rule-based, adjacent same-token pooling)
    -> LLM (LLaMA-3-8B)

Losses:
    1. CTC loss at adapter output (for alignment supervision)
    2. LM loss at LLM output (for transcription generation)

Reference: Soundwave architecture with modifications:
    - No learned LookBackModule (LBM)
    - Rule-based shrinking instead
    - Audio patch token: 128256
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple
from transformers import LlamaForCausalLM, LlamaConfig

from models.encoder import SpeechEncoder
from models.alignment_adapter import AlignmentAdapter
from models.shrink import CTCShrinker


class SpeechLLMPhase2(nn.Module):
    """
    End-to-end speech-to-text model for Phase 2 training.
    
    Args:
        encoder: SpeechEncoder (pretrained from Phase 1)
        adapter: AlignmentAdapter (pretrained from Phase 1)
        llm: LLaMA-3-8B model
        audio_patch_token: token id for audio patches (128256)
        ctc_weight: weight for CTC loss
        lm_weight: weight for LM loss
        freeze_encoder: whether to freeze encoder
        freeze_adapter: whether to freeze adapter
    """
    
    def __init__(
        self,
        encoder: SpeechEncoder,
        adapter: AlignmentAdapter,
        llm: LlamaForCausalLM,
        audio_patch_token: int = 128256,
        ctc_weight: float = 0.3,
        lm_weight: float = 1.0,
        freeze_encoder: bool = True,
        freeze_adapter: bool = False,
        blank_id: int = 128001,
        llm_pad_token_id: int = 128009,  # Soundwave uses eot_id as pad
    ):
        super().__init__()
        
        self.encoder = encoder
        self.adapter = adapter
        self.llm = llm
        self.shrinker = CTCShrinker(blank_id=blank_id)
        
        self.audio_patch_token = audio_patch_token
        self.ctc_weight = ctc_weight
        self.lm_weight = lm_weight
        self.blank_id = blank_id
        self.llm_pad_token_id = llm_pad_token_id
        
        # Freeze settings
        if freeze_encoder:
            for param in self.encoder.parameters():
                param.requires_grad = False
        
        if freeze_adapter:
            for param in self.adapter.parameters():
                param.requires_grad = False
        
        # CTC loss
        self.ctc_loss_fn = nn.CTCLoss(
            blank=blank_id,
            reduction='mean',
            zero_infinity=True,
        )
        
        # LM loss
        self.lm_loss_fn = nn.CrossEntropyLoss(ignore_index=-100)
    
    def forward(
        self,
        fbank: torch.Tensor,           # [B, T, 80]
        fbank_lengths: torch.Tensor,   # [B]
        input_ids: torch.Tensor,       # [B, L]  chat-formatted input
        labels: torch.Tensor,          # [B, L]  with -100 for non-prediction positions
        attention_mask: torch.Tensor,  # [B, L]
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass with dual loss.
        
        Returns:
            Dict with:
                - loss: total weighted loss
                - ctc_loss: CTC loss value
                - lm_loss: LM loss value
                - logits: LLM logits for generation
        """
        # 1. Encode audio (frozen encoder → no grad)
        encoder_requires_grad = any(p.requires_grad for p in self.encoder.parameters())
        with torch.set_grad_enabled(encoder_requires_grad):
            enc_out, out_lengths, enc_pad_mask = self.encoder(fbank, fbank_lengths)[:3]
            # Note: MultiscaleEncoder returns 4 values (x, lengths, mask, ctc_outputs)
            # We only need the first 3, same as SpeechEncoder
        
        # 2. Align to LLM space
        aligned, ctc_logits = self.adapter(enc_out, enc_pad_mask)
        # aligned: [B, T', D_llm], ctc_logits: [B, T', V]
        
        # 3. CTC loss (for alignment supervision)
        log_probs = torch.log_softmax(ctc_logits, dim=-1).transpose(0, 1)  # [T', B, V]
        
        # Need to get CTC targets from labels (extract assistant response)
        ctc_loss = self._compute_ctc_loss(
            log_probs, out_lengths, labels
        )
        
        # 4. Shrink audio features
        shrunk, shrunk_mask, shrunk_tokens = self.shrinker(
            aligned, ctc_logits, enc_pad_mask
        )
        # shrunk: [B, T_shrunk, D_llm]
        
        # 5. Replace audio patch tokens with shrunk features
        # This also updates labels to account for sequence extension
        inputs_embeds, new_attention_mask, new_labels, label_extend = self._merge_audio_text(
            input_ids=input_ids,
            audio_features=shrunk,
            audio_mask=shrunk_mask,
            attention_mask=attention_mask,
            labels=labels,
        )
        
        # 6. Forward through LLM (without passing labels, we compute loss manually)
        llm_outputs = self.llm(
            inputs_embeds=inputs_embeds,
            attention_mask=new_attention_mask,
            return_dict=True,
        )
        
        # 7. Compute LM loss manually (matching Soundwave's logic)
        logits = llm_outputs.logits
        lm_loss = self._compute_lm_loss(logits, new_labels)
        
        # 8. Combined loss
        total_loss = self.ctc_weight * ctc_loss + self.lm_weight * lm_loss
        
        return {
            "loss": total_loss,
            "ctc_loss": ctc_loss.detach(),
            "lm_loss": lm_loss.detach() if lm_loss is not None else torch.tensor(0.0),
            "logits": logits,
        }
    
    def _compute_lm_loss(
        self,
        logits: torch.Tensor,   # [B, L, V]
        labels: torch.Tensor,   # [B, L]
    ) -> torch.Tensor:
        """
        Compute LM loss with proper shift (predict next token).
        Matches Soundwave's loss computation.
        """
        # Shift so that tokens < n predict n
        shift_logits = logits[..., :-1, :].contiguous()  # [B, L-1, V]
        shift_labels = labels[..., 1:].contiguous()       # [B, L-1]
        
        # Flatten
        shift_logits = shift_logits.view(-1, shift_logits.size(-1))
        shift_labels = shift_labels.view(-1)
        
        # Cross entropy (ignore -100)
        loss = self.lm_loss_fn(shift_logits, shift_labels)
        
        return loss
    
    def _compute_ctc_loss(
        self,
        log_probs: torch.Tensor,       # [T', B, V]
        input_lengths: torch.Tensor,   # [B]
        labels: torch.Tensor,          # [B, L]
    ) -> torch.Tensor:
        """
        Extract transcription from labels and compute CTC loss.
        
        Labels format: chat template with -100 for non-assistant tokens.
        We need to extract the assistant response part.
        """
        # For simplicity, use the full labels (excluding -100)
        # In practice, you might want to extract only the assistant part
        
        batch_size = labels.size(0)
        
        # Flatten targets and filter out -100
        targets_list = []
        target_lengths = []
        
        for b in range(batch_size):
            valid = labels[b][labels[b] != -100]
            # Remove special tokens (eos, eot, etc.)
            valid = valid[valid < 128000]  # Keep only normal tokens
            targets_list.append(valid)
            target_lengths.append(len(valid))
        
        # Pad targets
        max_len = max(target_lengths) if target_lengths else 1
        targets = torch.full((batch_size, max_len), self.blank_id,
                            dtype=torch.long, device=labels.device)
        for b, t in enumerate(targets_list):
            if len(t) > 0:
                targets[b, :len(t)] = t
        
        target_lengths = torch.tensor(target_lengths, dtype=torch.long, device=labels.device)
        
        # Compute CTC loss
        with torch.backends.cudnn.flags(enabled=False):
            loss = self.ctc_loss_fn(
                log_probs,
                targets,
                input_lengths,
                target_lengths,
            )
        
        return loss
    
    def _merge_audio_text(
        self,
        input_ids: torch.Tensor,       # [B, L]
        audio_features: torch.Tensor,  # [B, T_audio, D]  已经 padded
        audio_mask: torch.Tensor,      # [B, T_audio]     True = valid
        attention_mask: torch.Tensor,  # [B, L] 输入的 attention_mask
        labels: torch.Tensor,          # [B, L] 原始 labels
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
        """
        Replace single audio_patch_token with multiple shrunk audio features.
        
        This matches Soundwave's merging logic:
        - Find audio_patch_token position
        - Replace 1 token with v shrunk features
        - Pad to max length in batch
        
        Args:
            input_ids: token ids with ONE audio_patch_token placeholder
            audio_features: shrunk audio features [B, T_audio, D]
            audio_mask: valid audio positions [B, T_audio]
            attention_mask: original attention mask [B, L]
            labels: original labels [B, L]
            
        Returns:
            inputs_embeds: [B, L_new, D] with audio features inserted
            new_attention_mask: [B, L_new] updated attention mask
            new_labels: [B, L_new] updated labels with shift
            label_extend: how much the sequence was extended
        """
        batch_size, seq_len = input_ids.shape
        _, max_audio_len, hidden_dim = audio_features.shape
        
        # Get text embeddings
        text_embeds = self.llm.model.embed_tokens(input_ids)  # [B, L, D]
        
        # Find audio patch position (same for all samples in batch)
        audio_patch_mask = (input_ids == self.audio_patch_token)  # [B, L]
        
        # Get actual audio lengths
        audio_lengths = audio_mask.sum(dim=1).long()  # [B]
        max_audio_len_in_batch = audio_lengths.max().item()
        
        # Build new sequences
        new_embeds_list = []
        new_attention_masks = []
        new_labels_list = []
        label_shifts = []
        
        for b in range(batch_size):
            # Find audio patch position
            patch_pos = audio_patch_mask[b].nonzero(as_tuple=True)[0]
            if len(patch_pos) == 0:
                # No audio patch, keep original
                new_embeds_list.append(text_embeds[b])
                new_attention_masks.append(attention_mask[b])
                new_labels_list.append(labels[b])
                label_shifts.append(0)
                continue
            
            audio_pos = patch_pos[0].item()
            v = audio_lengths[b].item()  # actual shrunk audio length
            
            # Text before audio
            before_embeds = text_embeds[b, :audio_pos]
            before_mask = attention_mask[b, :audio_pos]
            before_labels = labels[b, :audio_pos]
            
            # Audio features
            audio_embeds = audio_features[b, :v]  # [v, D]
            audio_attention = torch.ones(v, dtype=attention_mask.dtype, device=attention_mask.device)
            # Audio positions should not be predicted (label = -100)
            audio_labels = torch.full((v,), -100, dtype=torch.long, device=labels.device)
            
            # Text after audio (skip the audio_patch_token itself, num_patches=1)
            after_embeds = text_embeds[b, audio_pos + 1:]
            after_mask = attention_mask[b, audio_pos + 1:]
            after_labels = labels[b, audio_pos + 1:]
            
            # Padding to max_audio_len_in_batch
            pad_len = max_audio_len_in_batch - v
            if pad_len > 0:
                pad_embeds = self.llm.model.embed_tokens(
                    torch.full((pad_len,), self.llm_pad_token_id, 
                              dtype=torch.long, device=input_ids.device)
                )
                pad_attention = torch.zeros(pad_len, dtype=attention_mask.dtype, device=attention_mask.device)
                pad_labels = torch.full((pad_len,), -100, dtype=torch.long, device=labels.device)
                
                # Concatenate: before + audio + pad + after
                cur_embeds = torch.cat([before_embeds, audio_embeds, pad_embeds, after_embeds], dim=0)
                cur_mask = torch.cat([before_mask, audio_attention, pad_attention, after_mask], dim=0)
                cur_labels = torch.cat([before_labels, audio_labels, pad_labels, after_labels], dim=0)
            else:
                # Concatenate: before + audio + after
                cur_embeds = torch.cat([before_embeds, audio_embeds, after_embeds], dim=0)
                cur_mask = torch.cat([before_mask, audio_attention, after_mask], dim=0)
                cur_labels = torch.cat([before_labels, audio_labels, after_labels], dim=0)
            
            new_embeds_list.append(cur_embeds)
            new_attention_masks.append(cur_mask)
            new_labels_list.append(cur_labels)
            label_shifts.append(v - 1)  # v - num_patches (num_patches=1)
        
        # Pad to same length
        max_new_len = max(emb.shape[0] for emb in new_embeds_list)
        
        padded_embeds = torch.stack([
            F.pad(emb, (0, 0, 0, max_new_len - emb.shape[0])) 
            for emb in new_embeds_list
        ], dim=0)  # [B, L_new, D]
        
        padded_masks = torch.stack([
            F.pad(mask, (0, max_new_len - mask.shape[0]), value=0)
            for mask in new_attention_masks
        ], dim=0)  # [B, L_new]
        
        padded_labels = torch.stack([
            F.pad(lbl, (0, max_new_len - lbl.shape[0]), value=-100)
            for lbl in new_labels_list
        ], dim=0)  # [B, L_new]
        
        label_extend = max_audio_len_in_batch - 1  # max extension
        
        return padded_embeds, padded_masks, padded_labels, label_extend
    
    @torch.no_grad()
    def generate(
        self,
        fbank: torch.Tensor,
        fbank_lengths: torch.Tensor,
        prompt_input_ids: torch.Tensor,
        prompt_attention_mask: torch.Tensor,
        max_new_tokens: int = 256,
        **generation_kwargs
    ) -> torch.Tensor:
        """
        Inference: generate transcription from audio.
        
        Args:
            fbank: audio features [B, T, 80]
            fbank_lengths: valid lengths [B]
            prompt_input_ids: prompt with ONE audio_patch_token [B, L_prompt]
            prompt_attention_mask: [B, L_prompt]
            max_new_tokens: max tokens to generate
            
        Returns:
            generated_ids: [B, L_generated]
        """
        self.eval()
        
        # Encode and shrink audio
        enc_out, out_lengths, enc_pad_mask = self.encoder(fbank, fbank_lengths)[:3]
        aligned, ctc_logits = self.adapter(enc_out, enc_pad_mask)
        shrunk, shrunk_mask, _ = self.shrinker(aligned, ctc_logits, enc_pad_mask)
        
        # Merge with prompt (inference mode, no labels)
        inputs_embeds, new_attention_mask = self._merge_audio_text_inference(
            input_ids=prompt_input_ids,
            audio_features=shrunk,
            audio_mask=shrunk_mask,
            attention_mask=prompt_attention_mask,
        )
        
        # Generate
        outputs = self.llm.generate(
            inputs_embeds=inputs_embeds,
            attention_mask=new_attention_mask,
            max_new_tokens=max_new_tokens,
            **generation_kwargs,
        )
        
        return outputs
    
    def _merge_audio_text_inference(
        self,
        input_ids: torch.Tensor,
        audio_features: torch.Tensor,
        audio_mask: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Inference version of merge - no labels, no padding needed.
        """
        batch_size, seq_len = input_ids.shape
        _, max_audio_len, hidden_dim = audio_features.shape
        
        # Get text embeddings
        text_embeds = self.llm.model.embed_tokens(input_ids)
        
        # Find audio patch position
        audio_patch_mask = (input_ids == self.audio_patch_token)
        
        new_embeds_list = []
        new_attention_masks = []
        
        for b in range(batch_size):
            patch_pos = audio_patch_mask[b].nonzero(as_tuple=True)[0]
            if len(patch_pos) == 0:
                new_embeds_list.append(text_embeds[b])
                new_attention_masks.append(attention_mask[b])
                continue
            
            audio_pos = patch_pos[0].item()
            v = audio_mask[b].sum().item()
            
            # Concatenate: before + audio + after
            before_embeds = text_embeds[b, :audio_pos]
            before_mask = attention_mask[b, :audio_pos]
            
            audio_embeds = audio_features[b, :v]
            audio_attention = torch.ones(v, dtype=attention_mask.dtype, device=attention_mask.device)
            
            after_embeds = text_embeds[b, audio_pos + 1:]
            after_mask = attention_mask[b, audio_pos + 1:]
            
            cur_embeds = torch.cat([before_embeds, audio_embeds, after_embeds], dim=0)
            cur_mask = torch.cat([before_mask, audio_attention, after_mask], dim=0)
            
            new_embeds_list.append(cur_embeds)
            new_attention_masks.append(cur_mask)
        
        # Pad to same length
        max_new_len = max(emb.shape[0] for emb in new_embeds_list)
        
        padded_embeds = torch.stack([
            F.pad(emb, (0, 0, 0, max_new_len - emb.shape[0])) 
            for emb in new_embeds_list
        ], dim=0)
        
        padded_masks = torch.stack([
            F.pad(mask, (0, max_new_len - mask.shape[0]), value=0)
            for mask in new_attention_masks
        ], dim=0)
        
        return padded_embeds, padded_masks


def build_phase2_model(
    phase1_checkpoint: str,
    llm_path: str = "/root/workspace/models/llama31-8b-instruct",
    audio_patch_token: int = 128256,
    **kwargs
) -> SpeechLLMPhase2:
    """
    Build Phase 2 model from Phase 1 checkpoint.
    
    Supports both baseline SpeechEncoder and MultiscaleEncoder checkpoints.
    
    Args:
        phase1_checkpoint: path to Phase 1 checkpoint
        llm_path: path to LLaMA-3-8B
        audio_patch_token: audio patch token id
        **kwargs: additional args for SpeechLLMPhase2
        
    Returns:
        SpeechLLMPhase2 model
    """
    from transformers import AutoModelForCausalLM
    from models.multiscale_encoder import MultiscaleEncoder, validate_interleaved_config
    
    # Load Phase 1 components
    ckpt = torch.load(phase1_checkpoint, map_location="cpu")
    
    # Build encoder and adapter from config
    cfg = ckpt.get("cfg", {})
    encoder_cfg = cfg.get("encoder", {})
    
    # Detect if multiscale checkpoint
    is_multiscale = False
    if cfg.get("interleaved"):
        is_multiscale = True
    else:
        # Check state_dict keys
        for key in ckpt.get("encoder", {}).keys():
            if key.startswith("conv_modules.") or key.startswith("ctc_heads."):
                is_multiscale = True
                break
    
    if is_multiscale:
        # Build MultiscaleEncoder
        interleaved_cfg = cfg.get("interleaved", {})
        
        # Build ctc_tokenizers if present
        ctc_tokenizers = {}
        for key, val in interleaved_cfg.items():
            if key.startswith("ctc_") and "tokenizer" in val:
                tokenizer_cfg = val["tokenizer"]
                class DummyTokenizer:
                    def __init__(self, vocab_size):
                        self.vocab_size = vocab_size
                ctc_tokenizers[key] = DummyTokenizer(tokenizer_cfg.get("vocab_size", 100))
        
        num_layers = encoder_cfg.get("num_layers", 12)
        interleaved_modules = validate_interleaved_config(interleaved_cfg, num_layers)
        
        encoder = MultiscaleEncoder(
            input_dim=encoder_cfg.get("input_dim", 80),
            conv_channels=encoder_cfg.get("conv_channels", 1024),
            embed_dim=encoder_cfg.get("embed_dim", 512),
            conv_kernel_sizes=tuple(encoder_cfg.get("conv_kernel_sizes", [5, 5])),
            num_layers=num_layers,
            num_heads=encoder_cfg.get("num_heads", 8),
            ffn_dim=encoder_cfg.get("ffn_dim", 2048),
            dropout=encoder_cfg.get("dropout", 0.15),
            interleaved_modules=interleaved_modules if interleaved_modules else None,
            ctc_tokenizers=ctc_tokenizers if ctc_tokenizers else None,
        )
    else:
        # Build baseline SpeechEncoder
        encoder = SpeechEncoder(
            input_dim=encoder_cfg.get("input_dim", 80),
            conv_channels=encoder_cfg.get("conv_channels", 1024),
            embed_dim=encoder_cfg.get("embed_dim", 512),
            conv_kernel_sizes=tuple(encoder_cfg.get("conv_kernel_sizes", [5, 5])),
            num_layers=encoder_cfg.get("num_layers", 12),
            num_heads=encoder_cfg.get("num_heads", 8),
            ffn_dim=encoder_cfg.get("ffn_dim", 2048),
            dropout=encoder_cfg.get("dropout", 0.15),
        )
    
    encoder.load_state_dict(ckpt["encoder"])
    
    adapter_cfg = cfg.get("adapter", {})
    adapter = AlignmentAdapter(
        encoder_dim=encoder_cfg.get("embed_dim", 512),
        llm_hidden_size=adapter_cfg.get("llm_hidden_size", 4096),
        llm_num_heads=adapter_cfg.get("llm_num_heads", 32),
        vocab_size=adapter_cfg.get("vocab_size", 128256),
        ffn_multiplier=adapter_cfg.get("ffn_multiplier", 2),
        dropout=adapter_cfg.get("dropout", 0.1),
    )
    adapter.load_state_dict(ckpt["adapter"])
    
    # Load LLM
    llm = AutoModelForCausalLM.from_pretrained(
        llm_path,
        torch_dtype=torch.bfloat16,
        device_map="auto",
    )
    
    # Tie CTC weights to LLM embed_tokens
    adapter.tie_ctc_weights(llm.model.embed_tokens.weight.data.clone())
    
    # Build Phase 2 model
    model = SpeechLLMPhase2(
        encoder=encoder,
        adapter=adapter,
        llm=llm,
        audio_patch_token=audio_patch_token,
        **kwargs,
    )
    
    return model
