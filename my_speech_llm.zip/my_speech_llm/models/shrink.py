"""
CTC-based shrink module for Phase 2.

Implements rule-based shrinking: adjacent features with the same CTC prediction
are merged by mean pooling.

Reference: Soundwave's shrink logic (Soundwave.py lines 111-124), but replacing
the learned LookBackModule (LBM) with simple mean pooling.

Key difference from standard CTC:
- Standard CTC: remove blanks AND merge consecutive same tokens
- Soundwave shrink: keep blanks, only merge consecutive same tokens
"""

import torch
import torch.nn as nn
from typing import Tuple, List


def ctc_shrink(
    features: torch.Tensor,
    ctc_logits: torch.Tensor,
    padding_mask: torch.Tensor,
    blank_id: int = 128001,
) -> Tuple[List[torch.Tensor], List[torch.Tensor], List[int]]:
    """
    Shrink audio features based on CTC predictions.
    
    Rule (matching Soundwave):
    - Merge consecutive frames with the SAME CTC prediction (including blanks)
    - This is NOT standard CTC decoding - we keep blanks!
    
    Soundwave code reference:
        tokens = predict_logits.argmax(dim=-1)
        shrink_mask = tokens.roll(1) != tokens  # True if different from previous
        shrink_mask[:,0] = True                  # First token always kept
        shrink_2d = audio_features[shrink_mask]  # Select where mask is True
    
    Args:
        features:     [B, T, D]  aligned features from adapter
        ctc_logits:   [B, T, V]  CTC logits
        padding_mask: [B, T]     True = padding position
        blank_id:     CTC blank token id (not used here, kept for API compatibility)
        
    Returns:
        shrink_features: list of [T_i, D] tensors (variable length per sample)
        shrink_tokens:   list of [T_i] token ids for each sample
        lengths:         list of shrunk lengths
    """
    batch_size = features.size(0)
    
    # Greedy decode CTC predictions
    pred_tokens = ctc_logits.argmax(dim=-1)  # [B, T]
    
    shrink_features = []
    shrink_tokens = []
    lengths = []
    
    for b in range(batch_size):
        # Get valid frames (non-padding)
        valid_mask = ~padding_mask[b]  # [T]
        valid_tokens = pred_tokens[b][valid_mask]  # [T_valid]
        valid_features = features[b][valid_mask]   # [T_valid, D]
        
        if len(valid_tokens) == 0:
            # Edge case: empty sequence
            shrink_features.append(valid_features[:1] if valid_features.size(0) > 0 else features[b, :1])
            shrink_tokens.append(torch.tensor([blank_id], dtype=torch.long, device=features.device))
            lengths.append(1)
            continue
        
        # Soundwave shrink logic: keep first token, then only keep if different from previous
        # shrink_mask[i] = True if tokens[i] != tokens[i-1] (or i == 0)
        shrink_mask = torch.ones(len(valid_tokens), dtype=torch.bool, device=features.device)
        shrink_mask[1:] = valid_tokens[1:] != valid_tokens[:-1]
        
        # Apply mask to get shrunk tokens and features
        shrunk_tokens_b = valid_tokens[shrink_mask]
        
        # For features, we need to merge consecutive same tokens by mean pooling
        # (Soundwave just selects, but we want mean pooling for better quality)
        shrunk_feats = []
        i = 0
        while i < len(valid_tokens):
            # Find end of current segment with same token
            j = i
            while j < len(valid_tokens) and valid_tokens[j] == valid_tokens[i]:
                j += 1
            # Mean pool the segment
            segment = valid_features[i:j]  # [n, D]
            pooled = segment.mean(dim=0)   # [D]
            shrunk_feats.append(pooled)
            i = j
        
        if len(shrunk_feats) > 0:
            shrink_features.append(torch.stack(shrunk_feats))
            shrink_tokens.append(shrunk_tokens_b)
            lengths.append(len(shrunk_feats))
        else:
            # Edge case
            shrink_features.append(valid_features[:1])
            shrink_tokens.append(valid_tokens[:1])
            lengths.append(1)
    
    return shrink_features, shrink_tokens, lengths


def pad_shrunk_features(
    shrink_features: List[torch.Tensor],
    pad_value: float = 0.0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Pad shrunk features to same length for batching.
    
    Args:
        shrink_features: list of [T_i, D] tensors
        pad_value: padding value
        
    Returns:
        padded: [B, T_max, D]
        mask:   [B, T_max]  True = valid, False = padding
    """
    batch_size = len(shrink_features)
    max_len = max(f.size(0) for f in shrink_features)
    dim = shrink_features[0].size(1)
    
    padded = torch.full((batch_size, max_len, dim), pad_value, 
                        dtype=shrink_features[0].dtype,
                        device=shrink_features[0].device)
    mask = torch.zeros(batch_size, max_len, dtype=torch.bool,
                       device=shrink_features[0].device)
    
    for i, feat in enumerate(shrink_features):
        length = feat.size(0)
        padded[i, :length] = feat
        mask[i, :length] = True
    
    return padded, mask


class CTCShrinker(nn.Module):
    """
    Wrapper module for CTC shrinking with optional configuration.
    """
    
    def __init__(self, blank_id: int = 128001):
        super().__init__()
        self.blank_id = blank_id
    
    def forward(
        self,
        features: torch.Tensor,
        ctc_logits: torch.Tensor,
        padding_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            features:     [B, T, D]
            ctc_logits:   [B, T, V]
            padding_mask: [B, T]
            
        Returns:
            shrunk:       [B, T', D]  padded shrunk features
            shrunk_mask:  [B, T']     True = valid
            shrunk_tokens: [B, T']    CTC predictions after shrink
        """
        shrink_feats, shrink_toks, lengths = ctc_shrink(
            features, ctc_logits, padding_mask, self.blank_id
        )
        
        # Pad to batch
        shrunk, shrunk_mask = pad_shrunk_features(shrink_feats)
        
        # Pad tokens
        max_len = shrunk.size(1)
        batch_size = len(shrink_toks)
        shrunk_tokens = torch.full((batch_size, max_len), self.blank_id,
                                   dtype=torch.long, device=shrunk.device)
        for i, toks in enumerate(shrink_toks):
            shrunk_tokens[i, :len(toks)] = toks
        
        return shrunk, shrunk_mask, shrunk_tokens


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    B, T, D, V = 2, 10, 512, 128256
    
    features = torch.randn(B, T, D)
    ctc_logits = torch.randn(B, T, V)
    padding_mask = torch.zeros(B, T, dtype=torch.bool)
    padding_mask[1, 8:] = True  # sample 1 has 2 padding frames
    
    # Make some consecutive predictions same
    ctc_logits[0, 0:3, 100] = 10.0  # token 100 for frames 0-2
    ctc_logits[0, 3:6, 200] = 10.0  # token 200 for frames 3-5
    ctc_logits[0, 6:8, 100] = 10.0  # token 100 for frames 6-7
    
    shrinker = CTCShrinker(blank_id=128001)
    shrunk, mask, tokens = shrinker(features, ctc_logits, padding_mask)
    
    print(f"Input:  {features.shape}")
    print(f"Shrunk: {shrunk.shape}")
    print(f"Mask:   {mask.shape}")
    print(f"Tokens: {tokens.shape}")
    print(f"Sample 0 tokens: {tokens[0][:5]}")
