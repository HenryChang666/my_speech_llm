"""
Alignment Adapter

Mirrors Soundwave's alignment projection, adapted for our encoder:

Soundwave pipeline (from Soundwave.py):
    audio_feature = self.audio_tower(audio).last_hidden_state   # [B, T_w, 1280]  whisper dim
    audio_feature = audio_feature.view(..., T_w//2, 2*1280)     # 2× time-merge → [B, T_w//2, 2560]
    audio_feature = self.mm_projector1(audio_feature)            # Linear(adapter_size*2, hidden_size)
    audio_feature = self.asr_transformer_encoder(audio_feature)  # 1-layer Transformer
    audio_feature = self.out_norm(audio_feature)                 # LayerNorm
    predict_logits = self.audio_feature_head(audio_feature)      # Linear → vocab_size+1 (for CTC)

Our pipeline (encoder already outputs [B, T', encoder_dim]):
    - No time-merge needed (encoder already at 4× compression)
    - mm_projector1  : Linear(encoder_dim, llm_hidden_size)
    - asr_transformer_encoder: 1-layer Transformer (d_model=llm_hidden_size)
    - out_norm       : LayerNorm(llm_hidden_size)
    - audio_feature_head: [vocab_size+1, llm_hidden_size]
        - rows 0..vocab_size-1: tied (frozen) to LLM embed_tokens
        - row vocab_size (= audio_patch_token = blank): trainable

Key design (from Soundwave):
    - audio_patch_token (128256) is BOTH the CTC blank AND the LLM audio placeholder
    - Soundwave vocab_size = 128257 (128256 LLaMA tokens + 1 <audio_patch>)
    - The blank embedding (row 128256) is learned from scratch
    - All other embeddings are frozen (tied to LLM embed_tokens)
"""

import torch
import torch.nn as nn
from typing import Tuple, Optional


class AlignmentAdapter(nn.Module):
    """Alignment Adapter: projects encoder output to LLM hidden space + CTC head.

    Args:
        encoder_dim       : output dim of SpeechEncoder
        llm_hidden_size   : hidden dim of the LLM (LLaMA-3-8B → 4096)
        llm_num_heads     : attention heads in the LLM (LLaMA-3-8B → 32)
        vocab_size        : LLM vocabulary size WITHOUT audio_patch (128256)
        ffn_multiplier    : FFN dim = llm_hidden_size * ffn_multiplier (Soundwave uses 2)
        dropout           : dropout probability (Soundwave uses 0.1)
        audio_patch_token : token id for <audio_patch> = blank (128256)
    """

    def __init__(
        self,
        encoder_dim: int = 512,
        llm_hidden_size: int = 4096,
        llm_num_heads: int = 32,
        vocab_size: int = 128256,       # LLaMA-3 vocab WITHOUT audio_patch
        ffn_multiplier: int = 2,
        dropout: float = 0.1,
        audio_patch_token: int = 128256,
    ):
        super().__init__()

        self.vocab_size = vocab_size
        self.audio_patch_token = audio_patch_token
        self.ctc_vocab_size = vocab_size + 1   # 128257: includes audio_patch/blank

        # mm_projector: Linear(encoder_dim, llm_hidden_size)
        self.mm_projector = nn.Linear(encoder_dim, llm_hidden_size)

        # 1-layer Transformer encoder (norm_first=True matches Soundwave)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=llm_hidden_size,
            nhead=llm_num_heads,
            dim_feedforward=llm_hidden_size * ffn_multiplier,
            dropout=dropout,
            norm_first=True,
            batch_first=True,
        )
        self.asr_transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=1)

        # out_norm
        self.out_norm = nn.LayerNorm(llm_hidden_size)

        # CTC head: [ctc_vocab_size, llm_hidden_size]
        # We store it as two separate parts:
        #   - llm_embed_weight: [vocab_size, D]  → frozen, tied to LLM embed_tokens
        #   - blank_embedding:  [1, D]            → trainable (the <audio_patch>/blank row)
        # At forward time we cat them: [vocab_size+1, D] → linear projection
        self.blank_embedding = nn.Parameter(
            torch.zeros(1, llm_hidden_size)
        )
        nn.init.normal_(self.blank_embedding, mean=0.0, std=0.02)

        # Placeholder for frozen LLM embeddings (set via tie_ctc_weights)
        self.register_buffer("llm_embed_weight", torch.zeros(vocab_size, llm_hidden_size))
        self._weights_tied = False

    # ------------------------------------------------------------------
    def tie_ctc_weights(self, embed_tokens_weight: torch.Tensor):
        """Set the frozen LLM embedding matrix for CTC.

        Args:
            embed_tokens_weight: [vocab_size, llm_hidden_size] from LLM embed_tokens
        """
        # Use only the first self.vocab_size rows (embed may be extended to 128257)
        self.llm_embed_weight = embed_tokens_weight[:self.vocab_size].detach().clone()
        self._weights_tied = True

    # ------------------------------------------------------------------
    def _get_ctc_weight(self) -> torch.Tensor:
        """Build full CTC weight matrix [ctc_vocab_size, D] at forward time.
        
        Rows 0..vocab_size-1: frozen LLM embeddings
        Row vocab_size (= audio_patch_token): trainable blank_embedding
        """
        # llm_embed_weight is a buffer (no grad), blank_embedding is Parameter (has grad)
        return torch.cat([self.llm_embed_weight, self.blank_embedding], dim=0)
        # shape: [vocab_size+1, llm_hidden_size] = [128257, 4096]

    # ------------------------------------------------------------------
    def forward(
        self,
        encoder_out: torch.Tensor,
        src_key_padding_mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            encoder_out          : [B, T', encoder_dim]
            src_key_padding_mask : [B, T']  True=pad position

        Returns:
            aligned_features : [B, T', llm_hidden_size]   → input to LLM
            ctc_logits       : [B, T', ctc_vocab_size]    → for CTC loss (128257 classes)
        """
        # 1. Project to LLM dim
        x = self.mm_projector(encoder_out)          # [B, T', llm_hidden_size]

        # 2. 1-layer Transformer
        x = self.asr_transformer_encoder(
            x,
            src_key_padding_mask=src_key_padding_mask,
        )

        # 3. Normalise
        x = self.out_norm(x)                        # [B, T', llm_hidden_size]

        # 4. CTC logits: x @ W^T  where W = [ctc_vocab_size, D]
        ctc_weight = self._get_ctc_weight()         # [128257, 4096]
        ctc_logits = x @ ctc_weight.T               # [B, T', 128257]

        return x, ctc_logits


# ---------------------------------------------------------------------------
# Sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    ENCODER_DIM = 1024
    LLM_DIM = 4096
    VOCAB = 128256
    HEADS = 32

    adapter = AlignmentAdapter(
        encoder_dim=ENCODER_DIM,
        llm_hidden_size=LLM_DIM,
        llm_num_heads=HEADS,
        vocab_size=VOCAB,
    )

    # Simulate tie
    fake_embed = torch.randn(VOCAB, LLM_DIM)
    adapter.tie_ctc_weights(fake_embed)

    B, T_prime = 2, 100
    enc_out = torch.randn(B, T_prime, ENCODER_DIM)
    pad_mask = torch.zeros(B, T_prime, dtype=torch.bool)
    pad_mask[1, 80:] = True

    aligned, ctc_logits = adapter(enc_out, pad_mask)
    print(f"aligned:    {aligned.shape}")     # [2, 100, 4096]
    print(f"ctc_logits: {ctc_logits.shape}")  # [2, 100, 128257]

    # Check only blank_embedding has grad
    trainable = [(n, p.shape) for n, p in adapter.named_parameters() if p.requires_grad]
    print(f"Trainable params in adapter (excl. LLM embed): {[n for n,_ in trainable]}")
    assert any("blank_embedding" in n for n, _ in trainable)
    assert not any("llm_embed_weight" in n for n, _ in trainable)
    print("OK")
