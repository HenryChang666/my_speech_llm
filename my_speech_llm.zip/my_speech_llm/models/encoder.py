"""
Speech Encoder: Conv1dSubsampler (4x compression) + Transformer Encoder

Architecture mirrors the NATS2TEncoder in fairseq/models/nat_s2t/nat_s2t_model.py,
but implemented entirely in plain PyTorch — no fairseq dependency.

Input:  fbank features  [B, T, input_dim]  (e.g. 80-dim mel filterbank)
        src_lengths     [B]                (number of valid fbank frames per sample)

Output: encoder_out     [B, T', embed_dim]  (T' ≈ T/4 after conv subsampling)
        output_lengths  [B]
        padding_mask    [B, T']             (True = padding position)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def lengths_to_padding_mask(lengths: torch.Tensor) -> torch.Tensor:
    """Convert a 1-D tensor of valid lengths to a boolean padding mask.

    Returns a [B, T_max] tensor where True = padding (invalid) position.
    """
    bsz = lengths.size(0)
    max_len = lengths.max().item()
    mask = torch.arange(max_len, device=lengths.device).unsqueeze(0).expand(bsz, -1)
    return mask >= lengths.unsqueeze(1)  # True where padding


def make_positions(tensor: torch.Tensor, padding_mask: torch.Tensor) -> torch.Tensor:
    """Sinusoidal positional encodings matching fairseq's PositionalEmbedding.

    Args:
        tensor: [T, B, C]  – used only to read dtype/device
        padding_mask: [B, T]  – True = padding
    Returns:
        positions: [T, B, C]
    """
    T, B, C = tensor.shape
    positions = torch.arange(T, device=tensor.device).unsqueeze(1)  # [T, 1]
    div_term = torch.exp(
        torch.arange(0, C, 2, device=tensor.device, dtype=torch.float)
        * (-math.log(10000.0) / C)
    )
    pe = torch.zeros(T, C, device=tensor.device, dtype=tensor.dtype)
    pe[:, 0::2] = torch.sin(positions.float() * div_term)
    pe[:, 1::2] = torch.cos(positions.float() * div_term)
    # broadcast over batch
    return pe.unsqueeze(1).expand(T, B, C)


# ---------------------------------------------------------------------------
# Conv1dSubsampler  (直接复现 fairseq 的实现)
# ---------------------------------------------------------------------------

class Conv1dSubsampler(nn.Module):
    """Two-layer 1-D convolution with stride=2 each → 4× time compression.

    fairseq reference:
        fairseq/models/speech_to_text/modules/convolution.py :: Conv1dSubsampler

    Input  x: [B, T, in_channels]   (fbank frames, in_channels = input_dim)
    Output  : [T', B, out_channels]  (T' ≈ T // 4), plus output_lengths [B]
    """

    def __init__(
        self,
        in_channels: int,       # e.g. 80 for fbank
        mid_channels: int,      # internal conv width, e.g. 1024
        out_channels: int,      # encoder embed dim, e.g. 512
        kernel_sizes: Tuple[int, ...] = (5, 5),
    ):
        super().__init__()
        assert len(kernel_sizes) == 2, "Exactly 2 conv layers expected"

        self.conv_layers = nn.ModuleList()
        in_ch = in_channels
        for i, k in enumerate(kernel_sizes):
            out_ch = mid_channels if i < len(kernel_sizes) - 1 else out_channels
            self.conv_layers.append(
                nn.Conv1d(in_ch, out_ch, kernel_size=k, stride=2, padding=k // 2)
            )
            in_ch = out_ch

    def get_out_seq_lens_tensor(self, in_lengths: torch.Tensor) -> torch.Tensor:
        """Compute output lengths after each strided conv."""
        out = in_lengths.float()
        for conv in self.conv_layers:
            out = torch.floor((out + 2 * conv.padding[0] - conv.dilation[0] * (conv.kernel_size[0] - 1) - 1) / conv.stride[0] + 1)
        return out.long()

    def forward(
        self, src_tokens: torch.Tensor, src_lengths: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        src_tokens: [B, T, in_channels]
        src_lengths: [B]
        Returns:
            x:              [T', B, out_channels]
            output_lengths: [B]
        """
        # [B, T, C] → [B, C, T]
        x = src_tokens.transpose(1, 2)
        for conv in self.conv_layers:
            x = conv(x)
            x = F.glu(x, dim=1)  # GLU halves the channel dim — NOTE: needs 2× channels
        # → [B, C, T'] → [T', B, C]
        x = x.transpose(1, 2).transpose(0, 1)
        output_lengths = self.get_out_seq_lens_tensor(src_lengths)
        return x, output_lengths


# NOTE: fairseq's Conv1dSubsampler uses GLU which halves channels.
# The mid_channels should therefore be 2× what you want at each intermediate layer.
# We replicate this faithfully below.

class SpeechConvSubsampler(nn.Module):
    """Faithful replication of fairseq Conv1dSubsampler with GLU.

    Layer i: Conv1d(in, out*2, k, stride) → GLU → output width = out
    Supports N conv layers with configurable strides.

    in_channels  : input feature dim (e.g. 80)
    conv_channels: pre-GLU width for intermediate layers (e.g. 1024)
    embed_dim    : encoder_embed_dim (final post-GLU output dim)
    kernel_sizes : tuple of kernel sizes for each conv layer
    conv_strides : tuple of strides for each conv layer (default: all stride=2)

    Example with 2 layers (4x compression):
        layer0: Conv1d(80,  1024, 5, stride=2) → GLU → 512
        layer1: Conv1d(512, 2560, 5, stride=2) → GLU → 1280

    Example with 4 layers (16x compression):
        layer0: Conv1d(80,  1024, 5, stride=2) → GLU → 512
        layer1: Conv1d(512, 1024, 5, stride=2) → GLU → 512
        layer2: Conv1d(512, 1024, 5, stride=2) → GLU → 512
        layer3: Conv1d(512, 2560, 5, stride=2) → GLU → 1280
    """

    def __init__(
        self,
        in_channels: int,
        conv_channels: int,   # pre-GLU channels (= double the actual width)
        embed_dim: int,       # encoder_embed_dim
        kernel_sizes: Tuple[int, ...] = (5, 5),
        conv_strides: Optional[Tuple[int, ...]] = None,
    ):
        super().__init__()
        assert len(kernel_sizes) >= 2, f"At least 2 conv layers expected, got {len(kernel_sizes)}"

        if conv_strides is None:
            conv_strides = tuple([2] * len(kernel_sizes))
        assert len(conv_strides) == len(kernel_sizes), \
            f"conv_strides length ({len(conv_strides)}) must match kernel_sizes ({len(kernel_sizes)})"

        # Build conv layers:
        # - Intermediate layers: output conv_channels (post-GLU = conv_channels // 2)
        # - Last layer: output embed_dim * 2 (post-GLU = embed_dim)
        self.convs = nn.ModuleList()
        in_ch = in_channels
        for i, (k, s) in enumerate(zip(kernel_sizes, conv_strides)):
            if i < len(kernel_sizes) - 1:
                out_ch = conv_channels  # intermediate: pre-GLU = conv_channels
            else:
                out_ch = embed_dim * 2  # final: pre-GLU = embed_dim * 2
            self.convs.append(
                nn.Conv1d(in_ch, out_ch, kernel_size=k, stride=s, padding=k // 2)
            )
            in_ch = out_ch // 2  # post-GLU halves channels

        self.embed_dim = embed_dim

    def get_output_lengths(self, in_lengths: torch.Tensor) -> torch.Tensor:
        out = in_lengths.float()
        for conv in self.convs:
            out = torch.floor(
                (out + 2 * conv.padding[0] - conv.dilation[0] * (conv.kernel_size[0] - 1) - 1)
                / conv.stride[0] + 1
            )
        return out.long()

    def forward(
        self, src_tokens: torch.Tensor, src_lengths: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        src_tokens  : [B, T, in_channels]
        src_lengths : [B]
        Returns:
            x              : [T', B, embed_dim]
            output_lengths : [B]
        """
        x = src_tokens.transpose(1, 2)          # [B, C_in, T]
        for conv in self.convs:
            x = conv(x)                          # [B, C_out, T']
            x = F.glu(x, dim=1)                  # [B, C_out//2, T']
        # [B, embed_dim, T'] → [T', B, embed_dim]
        x = x.transpose(1, 2).transpose(0, 1)
        output_lengths = self.get_output_lengths(src_lengths)
        return x, output_lengths


# ---------------------------------------------------------------------------
# Transformer Encoder Layer  (Pre-LN, matches fairseq encoder_normalize_before=True)
# ---------------------------------------------------------------------------

class TransformerEncoderLayer(nn.Module):
    """Pre-LayerNorm Transformer encoder layer.

    Matches fairseq's TransformerEncoderLayer with encoder_normalize_before=True.
    """

    def __init__(
        self,
        embed_dim: int = 512,
        ffn_dim: int = 2048,
        num_heads: int = 8,
        dropout: float = 0.1,
        attn_dropout: float = 0.1,
        act_dropout: float = 0.1,
    ):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=attn_dropout
        )
        self.self_attn_layer_norm = nn.LayerNorm(embed_dim)
        self.fc1 = nn.Linear(embed_dim, ffn_dim)
        self.fc2 = nn.Linear(ffn_dim, embed_dim)
        self.final_layer_norm = nn.LayerNorm(embed_dim)
        self.dropout = nn.Dropout(dropout)
        self.act_dropout = nn.Dropout(act_dropout)
        self.activation = nn.ReLU()

    def forward(
        self,
        x: torch.Tensor,                          # [T, B, C]
        encoder_padding_mask: torch.Tensor,        # [B, T]  True=padding
    ) -> torch.Tensor:
        # Self-attention with pre-LN
        residual = x
        x = self.self_attn_layer_norm(x)
        x, _ = self.self_attn(
            x, x, x,
            key_padding_mask=encoder_padding_mask,
        )
        x = self.dropout(x)
        x = residual + x

        # FFN with pre-LN
        residual = x
        x = self.final_layer_norm(x)
        x = self.activation(self.fc1(x))
        x = self.act_dropout(x)
        x = self.fc2(x)
        x = self.dropout(x)
        x = residual + x

        return x


# ---------------------------------------------------------------------------
# Full Speech Encoder
# ---------------------------------------------------------------------------

class SpeechEncoder(nn.Module):
    """Full encoder: SpeechConvSubsampler + positional encoding + Transformer stack.

    Default hyper-parameters match nat_s2t_transformer_m:
        input_dim       = 80   (fbank)
        conv_channels   = 1024
        embed_dim       = 512
        conv_kernels     = (5, 5)
        num_layers      = 12
        num_heads       = 8
        ffn_dim         = 2048
        dropout         = 0.15
        normalize_before = True  (Pre-LN)
        embed_scale      = sqrt(embed_dim)
    """

    def __init__(
        self,
        input_dim: int = 80,
        conv_channels: int = 1024,
        embed_dim: int = 512,
        conv_kernel_sizes: Tuple[int, ...] = (5, 5),
        conv_strides: Optional[Tuple[int, ...]] = None,
        num_layers: int = 12,
        num_heads: int = 8,
        ffn_dim: int = 2048,
        dropout: float = 0.15,
        attn_dropout: float = 0.15,
        act_dropout: float = 0.15,
        max_source_positions: int = 6000,
        no_scale_embedding: bool = False,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.embed_scale = 1.0 if no_scale_embedding else math.sqrt(embed_dim)

        # Conv front-end
        self.subsample = SpeechConvSubsampler(
            in_channels=input_dim,
            conv_channels=conv_channels,
            embed_dim=embed_dim,
            kernel_sizes=conv_kernel_sizes,
            conv_strides=conv_strides,
        )

        # Sinusoidal positional embedding (learned-free, matches fairseq default)
        self.embed_positions = nn.Embedding(max_source_positions + 2, embed_dim)
        nn.init.normal_(self.embed_positions.weight, mean=0, std=embed_dim ** -0.5)

        self.dropout = nn.Dropout(dropout)

        self.layers = nn.ModuleList([
            TransformerEncoderLayer(
                embed_dim=embed_dim,
                ffn_dim=ffn_dim,
                num_heads=num_heads,
                dropout=dropout,
                attn_dropout=attn_dropout,
                act_dropout=act_dropout,
            )
            for _ in range(num_layers)
        ])

        # Final layer norm (Pre-LN architecture requires this after last layer)
        self.layer_norm = nn.LayerNorm(embed_dim)

    def forward(
        self,
        src_tokens: torch.Tensor,    # [B, T, input_dim]  fbank features
        src_lengths: torch.Tensor,   # [B]  valid frame counts
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns:
            x              : [B, T', embed_dim]  encoder output (batch-first)
            output_lengths : [B]                  valid frame counts after subsampling
            padding_mask   : [B, T']              True = padding position
        """
        # 1. Conv subsampling: [B,T,C] → [T',B,C]
        x, output_lengths = self.subsample(src_tokens, src_lengths)   # [T', B, C]

        # 2. Scale embeddings
        x = self.embed_scale * x

        # 3. Positional encoding (clamp indices within embedding table)
        T, B, C = x.shape
        pos_ids = torch.arange(T, device=x.device).unsqueeze(0).expand(B, -1)   # [B, T']
        # fairseq adds padding_idx=1; we just offset by 2
        pos_ids = pos_ids + 2
        pos_emb = self.embed_positions(pos_ids).transpose(0, 1)                   # [T', B, C]
        x = x + pos_emb
        x = self.dropout(x)

        # 4. Padding mask
        padding_mask = lengths_to_padding_mask(output_lengths)   # [B, T']

        # 5. Transformer layers
        for layer in self.layers:
            x = layer(x, padding_mask)

        # 6. Final LayerNorm
        x = self.layer_norm(x)

        # 7. Return batch-first
        x = x.transpose(0, 1)   # [B, T', C]

        return x, output_lengths, padding_mask


# ---------------------------------------------------------------------------
# Quick sanity check
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    encoder = SpeechEncoder()
    B, T, C = 2, 400, 80
    fbank = torch.randn(B, T, C)
    lengths = torch.tensor([400, 320])
    out, out_lens, pad_mask = encoder(fbank, lengths)
    print(f"Input:  {fbank.shape}")
    print(f"Output: {out.shape}   (T' = {out.shape[1]}, expected ~{T//4})")
    print(f"Output lengths: {out_lens}")
    print(f"Padding mask:   {pad_mask.shape}  (True=pad count: {pad_mask.sum(-1).tolist()})")
