"""
Multi-scale Speech Encoder with interleaved Conv compression and CTC heads.

Architecture:
    fbank [B, T, 80]
      |
    Conv subsampling (4x, same as baseline)
      |
    Transformer Layer 1
      |
    Transformer Layer 2
      |
    ...
      |  <-- conv_1 (stride-2 compress) inserted after specified layer
      |
    Transformer Layer N
      |  <-- ctc_1 (intermediate CTC head) inserted after specified layer
      |
    ...
      |  <-- conv_2 / ctc_2 / ... inserted at later layers
      |
    Final LayerNorm
      |
    [B, T'', embed_dim]  -->  AlignmentAdapter (final CTC with LLaMA embeddings)

Config conventions:
    interleaved:
      conv_1:
        after_layer: 6        # insert after transformer layer 6 (1-indexed)
        kernel_size: 3
        stride: 2
      ctc_1:
        after_layer: 8
        weight: 0.3
        tokenizer: { type: "phoneme", ... }
      conv_2:
        after_layer: 12
        ...
      ctc_2:
        after_layer: 16
        ...

    Validation rules:
      - Suffixes (conv_N, ctc_N) must start at 1, be consecutive
      - conv_1.after_layer < conv_2.after_layer (if both exist)
      - ctc_1.after_layer < ctc_2.after_layer (if both exist)
      - No two modules (conv or ctc) on the same layer
      - after_layer must be in [1, num_layers]
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Dict, List, Optional
from collections import OrderedDict

from models.encoder import (
    SpeechConvSubsampler,
    TransformerEncoderLayer,
    lengths_to_padding_mask,
)


# -----------------------------------------------------------------------
# Config validation
# -----------------------------------------------------------------------

def validate_interleaved_config(interleaved_cfg: dict, num_layers: int):
    """Validate the interleaved config and return sorted module specs.

    Returns:
        all_modules: list of (after_layer, module_type, name, cfg_dict)
                     sorted by after_layer ascending
    """
    if not interleaved_cfg:
        return []

    conv_entries = {}
    ctc_entries = {}

    for key, val in interleaved_cfg.items():
        if key.startswith("conv_"):
            suffix = key[len("conv_"):]
            try:
                idx = int(suffix)
            except ValueError:
                raise ValueError(f"Invalid conv key '{key}': suffix must be integer")
            conv_entries[idx] = val
        elif key.startswith("ctc_"):
            suffix = key[len("ctc_"):]
            try:
                idx = int(suffix)
            except ValueError:
                raise ValueError(f"Invalid ctc key '{key}': suffix must be integer")
            ctc_entries[idx] = val
        else:
            raise ValueError(f"Unknown interleaved key '{key}'. Must be conv_N or ctc_N.")

    # Check consecutive suffixes starting from 1
    def _check_consecutive(entries: dict, prefix: str):
        if not entries:
            return
        indices = sorted(entries.keys())
        expected = list(range(1, len(indices) + 1))
        if indices != expected:
            raise ValueError(
                f"{prefix} suffixes must be consecutive starting from 1. "
                f"Got: {indices}, expected: {expected}"
            )

    _check_consecutive(conv_entries, "conv")
    _check_consecutive(ctc_entries, "ctc")

    # Check layer ordering within each type
    def _check_ordering(entries: dict, prefix: str):
        sorted_idx = sorted(entries.keys())
        for i in range(len(sorted_idx) - 1):
            curr_layer = entries[sorted_idx[i]]["after_layer"]
            next_layer = entries[sorted_idx[i + 1]]["after_layer"]
            if curr_layer >= next_layer:
                raise ValueError(
                    f"{prefix}_{sorted_idx[i]}.after_layer ({curr_layer}) must be < "
                    f"{prefix}_{sorted_idx[i+1]}.after_layer ({next_layer})"
                )

    _check_ordering(conv_entries, "conv")
    _check_ordering(ctc_entries, "ctc")

    # Collect all modules.
    # Rules:
    #   - conv and ctc may share the same layer (ctc fires on pre-conv features)
    #   - two convs on the same layer are forbidden
    #   - two ctcs on the same layer are forbidden
    all_modules = []
    conv_layers_used = set()
    ctc_layers_used = set()

    for idx in sorted(conv_entries.keys()):
        cfg = conv_entries[idx]
        layer = cfg["after_layer"]
        if layer < 1 or layer > num_layers:
            raise ValueError(
                f"conv_{idx}.after_layer={layer} out of range [1, {num_layers}]"
            )
        if layer in conv_layers_used:
            raise ValueError(
                f"Layer {layer} already has a conv assigned. "
                f"Each layer can have at most one conv."
            )
        conv_layers_used.add(layer)
        all_modules.append((layer, "conv", f"conv_{idx}", cfg))

    for idx in sorted(ctc_entries.keys()):
        cfg = ctc_entries[idx]
        layer = cfg["after_layer"]
        if layer < 1 or layer > num_layers:
            raise ValueError(
                f"ctc_{idx}.after_layer={layer} out of range [1, {num_layers}]"
            )
        if layer in ctc_layers_used:
            raise ValueError(
                f"Layer {layer} already has a ctc assigned. "
                f"Each layer can have at most one ctc."
            )
        ctc_layers_used.add(layer)
        all_modules.append((layer, "ctc", f"ctc_{idx}", cfg))

    # Sort all modules by after_layer
    all_modules.sort(key=lambda x: x[0])
    return all_modules


# -----------------------------------------------------------------------
# Interleaved stride-2 conv for temporal compression
# -----------------------------------------------------------------------

class InterleavedConv(nn.Module):
    """1D convolution with stride 2 for temporal compression within encoder.

    Input:  [T, B, C]  (time-first, same as transformer layers)
    Output: [T//2, B, C], updated lengths
    """

    def __init__(self, embed_dim: int, kernel_size: int = 3, stride: int = 2):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv1d(
            embed_dim, embed_dim,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
        )
        self.norm = nn.LayerNorm(embed_dim)
        self.stride = stride

    def get_output_lengths(self, in_lengths: torch.Tensor) -> torch.Tensor:
        p = self.conv.padding[0]
        k = self.conv.kernel_size[0]
        s = self.conv.stride[0]
        d = self.conv.dilation[0]
        out = torch.floor(
            (in_lengths.float() + 2 * p - d * (k - 1) - 1) / s + 1
        )
        return out.long()

    def forward(
        self,
        x: torch.Tensor,               # [T, B, C]
        lengths: torch.Tensor,          # [B]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # [T, B, C] -> [B, C, T]
        x = x.permute(1, 2, 0)
        x = self.conv(x)                # [B, C, T']
        # [B, C, T'] -> [T', B, C]
        x = x.permute(2, 0, 1)
        x = self.norm(x)
        out_lengths = self.get_output_lengths(lengths)
        return x, out_lengths


# -----------------------------------------------------------------------
# Intermediate CTC head
# -----------------------------------------------------------------------

class IntermediateCTCHead(nn.Module):
    """Lightweight CTC projection at intermediate encoder layer.

    Projects encoder hidden states to CTC logits for an auxiliary CTC loss.
    blank_id = vocab_size (last index).
    """

    def __init__(self, embed_dim: int, ctc_vocab_size: int):
        super().__init__()
        # ctc_vocab_size already includes blank (+1 done outside)
        self.proj = nn.Linear(embed_dim, ctc_vocab_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [T, B, C] or [B, T, C]
        Returns: logits of same shape with last dim = ctc_vocab_size
        """
        return self.proj(x)


# -----------------------------------------------------------------------
# Multi-scale Speech Encoder
# -----------------------------------------------------------------------

class MultiscaleEncoder(nn.Module):
    """Speech encoder with interleaved conv compression and CTC heads.

    Reuses the same conv subsampling front-end and transformer layer
    implementation as the baseline SpeechEncoder.
    """

    def __init__(
        self,
        input_dim: int = 80,
        conv_channels: int = 1024,
        embed_dim: int = 1280,
        conv_kernel_sizes: Tuple[int, ...] = (5, 5),
        num_layers: int = 24,
        num_heads: int = 20,
        ffn_dim: int = 5120,
        dropout: float = 0.1,
        attn_dropout: float = 0.1,
        act_dropout: float = 0.1,
        max_source_positions: int = 6000,
        no_scale_embedding: bool = False,
        interleaved_modules: Optional[List] = None,
        ctc_tokenizers: Optional[Dict] = None,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_layers = num_layers
        self.embed_scale = 1.0 if no_scale_embedding else math.sqrt(embed_dim)

        # Conv front-end: 4x compression (same as baseline)
        self.subsample = SpeechConvSubsampler(
            in_channels=input_dim,
            conv_channels=conv_channels,
            embed_dim=embed_dim,
            kernel_sizes=conv_kernel_sizes,
        )

        # Positional embedding
        self.embed_positions = nn.Embedding(max_source_positions + 2, embed_dim)
        nn.init.normal_(self.embed_positions.weight, mean=0, std=embed_dim ** -0.5)

        self.dropout_layer = nn.Dropout(dropout)

        # Transformer layers
        self.layers = nn.ModuleList([
            TransformerEncoderLayer(
                embed_dim=embed_dim,
                ffn_dim=ffn_dim,
                num_heads=num_heads,
                dropout=dropout,
                attn_dropout=attn_dropout,
                act_dropout=act_dropout,
            )
            for _ in range(num_layers)
        ])

        # Final layer norm
        self.layer_norm = nn.LayerNorm(embed_dim)

        # Build interleaved modules
        # after_layer -> module mapping (1-indexed)
        self.conv_modules = nn.ModuleDict()    # key: "conv_N"
        self.ctc_heads = nn.ModuleDict()       # key: "ctc_N"
        self.conv_at_layer = {}                # after_layer -> conv name
        self.ctc_at_layer = {}                 # after_layer -> ctc name
        self.ctc_weights = {}                  # ctc name -> loss weight
        self.ctc_vocab_sizes = {}              # ctc name -> vocab_size (including blank)

        if interleaved_modules:
            for after_layer, mod_type, name, cfg in interleaved_modules:
                if mod_type == "conv":
                    self.conv_modules[name] = InterleavedConv(
                        embed_dim=embed_dim,
                        kernel_size=cfg.get("kernel_size", 3),
                        stride=cfg.get("stride", 2),
                    )
                    self.conv_at_layer[after_layer] = name

                elif mod_type == "ctc":
                    assert ctc_tokenizers is not None and name in ctc_tokenizers, \
                        f"CTC head '{name}' requires a tokenizer in ctc_tokenizers dict"
                    tokenizer = ctc_tokenizers[name]
                    ctc_vs = tokenizer.vocab_size + 1  # +1 for blank
                    self.ctc_heads[name] = IntermediateCTCHead(embed_dim, ctc_vs)
                    self.ctc_at_layer[after_layer] = name
                    self.ctc_weights[name] = cfg.get("weight", 0.3)
                    self.ctc_vocab_sizes[name] = ctc_vs

    def _recompute_pos_emb(self, x: torch.Tensor) -> torch.Tensor:
        """Recompute positional embeddings after conv compression changes T."""
        T, B, C = x.shape
        pos_ids = torch.arange(T, device=x.device).unsqueeze(0).expand(B, -1) + 2
        return self.embed_positions(pos_ids).transpose(0, 1)  # [T, B, C]

    def forward(
        self,
        src_tokens: torch.Tensor,      # [B, T, input_dim]
        src_lengths: torch.Tensor,      # [B]
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Returns:
            x              : [B, T'', embed_dim]  final encoder output (batch-first)
            output_lengths : [B]
            padding_mask   : [B, T'']
            ctc_outputs    : dict { ctc_name: [B, T_at_that_layer, ctc_vocab_size] }
        """
        # 1. Conv subsampling: [B, T, C] -> [T', B, C]
        x, output_lengths = self.subsample(src_tokens, src_lengths)

        # 2. Scale + positional embedding
        x = self.embed_scale * x
        T, B, C = x.shape
        pos_ids = torch.arange(T, device=x.device).unsqueeze(0).expand(B, -1) + 2
        pos_emb = self.embed_positions(pos_ids).transpose(0, 1)
        x = x + pos_emb
        x = self.dropout_layer(x)

        # 3. Padding mask
        padding_mask = lengths_to_padding_mask(output_lengths)

        # 4. Transformer layers with interleaved conv/ctc
        ctc_outputs = {}

        for layer_idx in range(self.num_layers):
            x = self.layers[layer_idx](x, padding_mask)

            layer_num = layer_idx + 1  # 1-indexed

            # CTC fires BEFORE conv on the same layer:
            # features used for CTC loss are pre-compression (coarser granularity
            # supervision on the uncompressed sequence, which is the intended design).
            if layer_num in self.ctc_at_layer:
                ctc_name = self.ctc_at_layer[layer_num]
                # CTC logits: [T, B, V] -> [B, T, V]
                ctc_logits = self.ctc_heads[ctc_name](x).transpose(0, 1)
                ctc_outputs[ctc_name] = {
                    "logits": ctc_logits,
                    "lengths": output_lengths.clone(),
                }

            # Conv fires AFTER ctc on the same layer.
            if layer_num in self.conv_at_layer:
                conv_name = self.conv_at_layer[layer_num]
                x, output_lengths = self.conv_modules[conv_name](x, output_lengths)
                padding_mask = lengths_to_padding_mask(output_lengths)
                # Recompute positional embeddings for new sequence length
                x = x + self._recompute_pos_emb(x)

        # 5. Final LayerNorm
        x = self.layer_norm(x)

        # 6. Return batch-first
        x = x.transpose(0, 1)  # [B, T'', C]

        return x, output_lengths, padding_mask, ctc_outputs
