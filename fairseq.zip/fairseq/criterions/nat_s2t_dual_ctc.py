# Dual CTC criterion for NAT S2T: encoder CTC (src_word) + decoder CTC (tgt)
# with BLEU/WER evaluation during validation.

import math
import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import II

from fairseq import utils
from fairseq.logging import metrics
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.dataclass import FairseqDataclass
from fairseq.data.data_utils import post_process
from fairseq.logging.meters import safe_round

logger = logging.getLogger(__name__)


@dataclass
class NATS2TDualCTCCriterionConfig(FairseqDataclass):
    zero_infinity: bool = field(
        default=True,
        metadata={"help": "zero inf loss when source length <= target length"},
    )
    sentence_avg: bool = II("optimization.sentence_avg")
    encoder_ctc_weight: float = field(
        default=0.3,
        metadata={"help": "weight for encoder CTC loss (on src_word_text)"},
    )
    decoder_ctc_weight: float = field(
        default=0.3,
        metadata={"help": "weight for decoder CTC loss (on tgt_text)"},
    )
    label_smoothing: float = field(
        default=0.0,
        metadata={"help": "label smoothing for NAT word_ins loss"},
    )
    length_loss_factor: float = field(
        default=0.1,
        metadata={"help": "weight for length prediction loss"},
    )
    post_process: str = field(
        default="sentencepiece",
        metadata={"help": "how to post process predictions into words"},
    )
    task_type: str = field(
        default="st",
        metadata={"help": "st or asr; determines whether to compute BLEU or WER"},
    )


@register_criterion("nat_s2t_dual_ctc", dataclass=NATS2TDualCTCCriterionConfig)
class NATS2TDualCTCCriterion(FairseqCriterion):
    def __init__(self, cfg: NATS2TDualCTCCriterionConfig, task):
        super().__init__(task)
        self.blank_idx = 0  # CTC blank = 0 (fairseq dict pad=1)
        self.pad_idx = task.target_dictionary.pad()
        self.eos_idx = task.target_dictionary.eos()
        self.zero_infinity = cfg.zero_infinity
        self.sentence_avg = cfg.sentence_avg
        self.encoder_ctc_weight = cfg.encoder_ctc_weight
        self.decoder_ctc_weight = cfg.decoder_ctc_weight
        self.label_smoothing = cfg.label_smoothing
        self.length_loss_factor = cfg.length_loss_factor
        self.post_process = cfg.post_process
        self.task_type = cfg.task_type

    def _compute_ctc_loss(self, log_probs, targets, input_lengths, target_lengths):
        """Compute CTC loss. log_probs: T x B x V, targets: B x S"""
        pad_mask = (targets != self.pad_idx) & (targets != self.eos_idx)
        targets_flat = targets.masked_select(pad_mask)
        tgt_lens = pad_mask.sum(-1)

        with torch.backends.cudnn.flags(enabled=False):
            loss = F.ctc_loss(
                log_probs,
                targets_flat,
                input_lengths,
                tgt_lens,
                blank=self.blank_idx,
                reduction="sum",
                zero_infinity=self.zero_infinity,
            )
        return loss

    def _compute_nat_loss(self, model_output):
        """Compute NAT word insertion loss and length loss from model forward output."""
        losses = {}
        total_loss = torch.tensor(0.0).to(model_output["word_ins"]["out"])

        # Word insertion loss (cross-entropy)
        word_ins = model_output["word_ins"]
        word_ins_out = word_ins["out"]  # B x T x V
        word_ins_tgt = word_ins["tgt"]  # B x T
        word_ins_mask = word_ins["mask"]  # B x T

        # Cross entropy (cast to float32 to avoid fp16 overflow)
        word_ins_out_flat = word_ins_out.float().view(-1, word_ins_out.size(-1))
        word_ins_tgt_flat = word_ins_tgt.view(-1)
        nll_loss = F.cross_entropy(
            word_ins_out_flat,
            word_ins_tgt_flat,
            ignore_index=self.pad_idx,
            label_smoothing=self.label_smoothing,
            reduction="sum",
        )
        total_loss = total_loss + nll_loss
        losses["word_ins_loss"] = utils.item(nll_loss.data)

        # Length loss (cast to float32 to avoid fp16 overflow)
        length_info = model_output["length"]
        length_out = length_info["out"].float()  # B x 256
        length_tgt = length_info["tgt"]  # B
        length_factor = length_info["factor"]
        length_loss = F.cross_entropy(
            length_out, length_tgt, reduction="sum"
        )
        total_loss = total_loss + length_loss * length_factor
        losses["length_loss"] = utils.item(length_loss.data)

        return total_loss, losses

    def forward(self, model, sample, reduce=True):
        src_tokens = sample["net_input"]["src_tokens"]
        src_lengths = sample["net_input"]["src_lengths"]
        prev_output_tokens = sample["net_input"]["prev_output_tokens"]
        tgt_tokens = sample["target"]

        # Forward pass
        model_output = model(
            src_tokens, src_lengths, prev_output_tokens, tgt_tokens
        )
        encoder_out = model_output["encoder_out"]

        # 1. NAT word insertion + length loss
        nat_loss, nat_losses = self._compute_nat_loss(model_output)

        # 2. Encoder CTC loss (on src_word_text)
        enc_ctc_loss = torch.tensor(0.0).to(nat_loss)
        if self.encoder_ctc_weight > 0 and sample.get("src_word_target", None) is not None:
            enc_ctc_logits = model.encoder.get_ctc_logits(encoder_out)  # T x B x V
            enc_ctc_lprobs = utils.log_softmax(enc_ctc_logits.float(), dim=-1)
            enc_input_lengths = model.encoder.get_ctc_input_lengths(encoder_out)
            enc_ctc_loss = self._compute_ctc_loss(
                enc_ctc_lprobs,
                sample["src_word_target"],
                enc_input_lengths,
                sample["src_word_target_lengths"],
            )

        # 3. Decoder CTC loss (on tgt_text)
        dec_ctc_loss = torch.tensor(0.0).to(nat_loss)
        if self.decoder_ctc_weight > 0:
            dec_ctc_logits = model.decoder.get_ctc_logits(
                prev_output_tokens, encoder_out
            )  # T x B x V
            dec_ctc_lprobs = utils.log_softmax(dec_ctc_logits.float(), dim=-1)
            dec_input_lengths = model.decoder.get_ctc_input_lengths(prev_output_tokens)
            dec_ctc_loss = self._compute_ctc_loss(
                dec_ctc_lprobs,
                tgt_tokens,
                dec_input_lengths,
                sample["target_lengths"],
            )

        # Total loss
        loss = nat_loss + self.encoder_ctc_weight * enc_ctc_loss + self.decoder_ctc_weight * dec_ctc_loss

        ntokens = sample["ntokens"]
        nsentences = sample["nsentences"]
        sample_size = nsentences if self.sentence_avg else ntokens

        logging_output = {
            "loss": utils.item(loss.data),
            "nat_loss": utils.item(nat_loss.data),
            "enc_ctc_loss": utils.item(enc_ctc_loss.data),
            "dec_ctc_loss": utils.item(dec_ctc_loss.data),
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": sample_size,
        }
        logging_output.update(nat_losses)

        # Validation: compute BLEU (for ST) or WER (for ASR) using decoder CTC
        if not model.training:
            self._compute_val_metrics(
                model, sample, encoder_out, prev_output_tokens, logging_output
            )

        return loss, sample_size, logging_output

    def _compute_val_metrics(self, model, sample, encoder_out, prev_output_tokens, logging_output):
        """Compute BLEU or WER during validation using proper NAT inference flow.
        
        Follows fairseq NAT pattern:
        1. initialize_output_tokens(encoder_out, src_tokens) - predict length
        2. forward_decoder(decoder_out, encoder_out) - non-autoregressive decode
        """
        import editdistance
        from fairseq.iterative_refinement_generator import DecoderOut

        tgt_dict = self.task.target_dictionary
        src_tokens = sample["net_input"]["src_tokens"]
        
        with torch.no_grad():
            # Step 1: Initialize output tokens using length predictor (NAT style)
            decoder_out = model.initialize_output_tokens(encoder_out, src_tokens)
            
            # Step 2: Run forward_decoder for iterative refinement (single step for validation)
            decoder_out = decoder_out._replace(step=0, max_step=1)
            decoder_out = model.forward_decoder(decoder_out, encoder_out)
            
            # Get the predicted tokens from NAT decoder
            pred_tokens = decoder_out.output_tokens  # B x T_pred
            
            # --- Decoder CTC decode for target ---
            # Use NAT-predicted tokens as input to get CTC logits
            dec_ctc_logits = model.decoder.get_ctc_logits(pred_tokens, encoder_out)
            dec_ctc_lprobs = utils.log_softmax(dec_ctc_logits.float(), dim=-1)
            dec_lprobs_t = dec_ctc_lprobs.transpose(0, 1).float().contiguous().cpu()  # B x T x V
            dec_input_lengths = model.decoder.get_ctc_input_lengths(pred_tokens)

        hyps = []
        refs = []

        for lp, t, inp_l in zip(
            dec_lprobs_t,
            sample["target"],
            dec_input_lengths,
        ):
            lp = lp[:inp_l]
            # Greedy CTC decode
            toks = lp.argmax(dim=-1).unique_consecutive()
            pred_units_arr = toks[toks != self.blank_idx].tolist()
            pred_units = tgt_dict.string(pred_units_arr)
            pred_words = post_process(pred_units, self.post_process).strip()

            # Reference
            p = (t != self.pad_idx) & (t != self.eos_idx)
            targ = t[p]
            targ_units = tgt_dict.string(targ)
            targ_words = post_process(targ_units, self.post_process).strip()

            hyps.append(pred_words)
            refs.append(targ_words)

        # --- Encoder CTC decode for src_word_text ---
        enc_w_errs = 0
        enc_w_len = 0
        if sample.get("src_word_target", None) is not None:
            with torch.no_grad():
                enc_ctc_logits = model.encoder.get_ctc_logits(encoder_out)
                enc_ctc_lprobs = utils.log_softmax(enc_ctc_logits.float(), dim=-1)
                enc_lprobs_t = enc_ctc_lprobs.transpose(0, 1).float().contiguous().cpu()
                enc_input_lengths = model.encoder.get_ctc_input_lengths(encoder_out)

            for lp, t, inp_l in zip(
                enc_lprobs_t,
                sample["src_word_target"],
                enc_input_lengths,
            ):
                lp = lp[:inp_l]
                toks = lp.argmax(dim=-1).unique_consecutive()
                pred_arr = toks[toks != self.blank_idx].tolist()
                pred_str = post_process(tgt_dict.string(pred_arr), self.post_process).strip()

                p = (t != self.pad_idx) & (t != self.eos_idx)
                targ = t[p]
                targ_str = post_process(tgt_dict.string(targ), self.post_process).strip()

                pred_words_list = pred_str.split()
                targ_words_list = targ_str.split()
                enc_w_errs += editdistance.eval(pred_words_list, targ_words_list)
                enc_w_len += len(targ_words_list)

        logging_output["enc_w_errors"] = enc_w_errs
        logging_output["enc_w_total"] = enc_w_len

        task_type = getattr(self, "task_type", "st")

        if task_type == "asr":
            # WER
            w_errs = 0
            w_len = 0
            for hyp, ref in zip(hyps, refs):
                hyp_words = hyp.split()
                ref_words = ref.split()
                w_errs += editdistance.eval(hyp_words, ref_words)
                w_len += len(ref_words)
            logging_output["dec_w_errors"] = w_errs
            logging_output["dec_w_total"] = w_len
        else:
            # BLEU (for ST)
            import sacrebleu
            bleu = sacrebleu.corpus_bleu(hyps, [refs])
            logging_output["_bleu_sys_len"] = bleu.sys_len
            logging_output["_bleu_ref_len"] = bleu.ref_len
            for i in range(4):
                logging_output["_bleu_counts_" + str(i)] = bleu.counts[i]
                logging_output["_bleu_totals_" + str(i)] = bleu.totals[i]

    @staticmethod
    def reduce_metrics(logging_outputs) -> None:
        loss_sum = utils.item(sum(log.get("loss", 0) for log in logging_outputs))
        nat_loss_sum = utils.item(sum(log.get("nat_loss", 0) for log in logging_outputs))
        enc_ctc_loss_sum = utils.item(sum(log.get("enc_ctc_loss", 0) for log in logging_outputs))
        dec_ctc_loss_sum = utils.item(sum(log.get("dec_ctc_loss", 0) for log in logging_outputs))
        ntokens = utils.item(sum(log.get("ntokens", 0) for log in logging_outputs))
        nsentences = utils.item(sum(log.get("nsentences", 0) for log in logging_outputs))
        sample_size = utils.item(sum(log.get("sample_size", 0) for log in logging_outputs))

        metrics.log_scalar(
            "loss", loss_sum / sample_size / math.log(2), sample_size, round=3
        )
        metrics.log_scalar(
            "nat_loss", nat_loss_sum / sample_size / math.log(2), sample_size, round=3
        )
        metrics.log_scalar(
            "enc_ctc_loss", enc_ctc_loss_sum / sample_size / math.log(2), sample_size, round=3
        )
        metrics.log_scalar(
            "dec_ctc_loss", dec_ctc_loss_sum / sample_size / math.log(2), sample_size, round=3
        )
        metrics.log_scalar("ntokens", ntokens)
        metrics.log_scalar("nsentences", nsentences)

        # Encoder WER (src_word)
        enc_w_errors = sum(log.get("enc_w_errors", 0) for log in logging_outputs)
        enc_w_total = sum(log.get("enc_w_total", 0) for log in logging_outputs)
        if enc_w_total > 0:
            metrics.log_scalar("_enc_w_errors", enc_w_errors)
            metrics.log_scalar("_enc_w_total", enc_w_total)
            metrics.log_derived(
                "enc_wer",
                lambda meters: safe_round(
                    meters["_enc_w_errors"].sum * 100.0 / meters["_enc_w_total"].sum, 3
                )
                if meters["_enc_w_total"].sum > 0
                else float("nan"),
            )

        # Decoder WER (for ASR)
        dec_w_errors = sum(log.get("dec_w_errors", 0) for log in logging_outputs)
        dec_w_total = sum(log.get("dec_w_total", 0) for log in logging_outputs)
        if dec_w_total > 0:
            metrics.log_scalar("_dec_w_errors", dec_w_errors)
            metrics.log_scalar("_dec_w_total", dec_w_total)
            metrics.log_derived(
                "dec_wer",
                lambda meters: safe_round(
                    meters["_dec_w_errors"].sum * 100.0 / meters["_dec_w_total"].sum, 3
                )
                if meters["_dec_w_total"].sum > 0
                else float("nan"),
            )

        # BLEU (for ST)
        def sum_logs(key):
            result = sum(log.get(key, 0) for log in logging_outputs)
            if torch.is_tensor(result):
                result = result.cpu()
            return result

        counts, totals = [], []
        for i in range(4):
            counts.append(sum_logs("_bleu_counts_" + str(i)))
            totals.append(sum_logs("_bleu_totals_" + str(i)))

        if max(totals) > 0:
            metrics.log_scalar("_bleu_counts", np.array(counts))
            metrics.log_scalar("_bleu_totals", np.array(totals))
            metrics.log_scalar("_bleu_sys_len", sum_logs("_bleu_sys_len"))
            metrics.log_scalar("_bleu_ref_len", sum_logs("_bleu_ref_len"))

            def compute_bleu(meters):
                import inspect
                try:
                    from sacrebleu.metrics import BLEU
                    comp_bleu = BLEU.compute_bleu
                except ImportError:
                    import sacrebleu
                    comp_bleu = sacrebleu.compute_bleu

                fn_sig = inspect.getfullargspec(comp_bleu)[0]
                if "smooth_method" in fn_sig:
                    smooth = {"smooth_method": "exp"}
                else:
                    smooth = {"smooth": "exp"}
                bleu = comp_bleu(
                    correct=meters["_bleu_counts"].sum,
                    total=meters["_bleu_totals"].sum,
                    sys_len=int(meters["_bleu_sys_len"].sum),
                    ref_len=int(meters["_bleu_ref_len"].sum),
                    **smooth,
                )
                return round(bleu.score, 2)

            metrics.log_derived("bleu", compute_bleu)

    @staticmethod
    def logging_outputs_can_be_summed() -> bool:
        return True
