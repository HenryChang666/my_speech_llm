# Progressive S2T multi-level CTC criterion.
# Losses:
#   char_ctc   : char-level CTC on encoder layer 6 output  (src_char_target)
#   phone_ctc  : phone-level CTC on encoder layer 9 output (src_phone_target)
#   enc_ctc    : subword CTC on encoder layer 12 output    (src_word_target)
#   dec_ctc    : decoder CTC on decoder output             (tgt_text / target)
# Total loss = char_w * char_ctc + phone_w * phone_ctc + enc_w * enc_ctc + dec_w * dec_ctc

import math
import logging
from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import II

from fairseq import utils
from fairseq.logging import metrics
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.dataclass import FairseqDataclass
from fairseq.data.data_utils import post_process
from fairseq.logging.meters import safe_round

logger = logging.getLogger(__name__)


@dataclass
class ProgressiveCTCCriterionConfig(FairseqDataclass):
    zero_infinity: bool = field(
        default=True,
        metadata={"help": "zero inf loss when input shorter than target"},
    )
    sentence_avg: bool = II("optimization.sentence_avg")
    char_ctc_weight: float = field(
        default=0.2, metadata={"help": "weight for char CTC loss"}
    )
    phone_ctc_weight: float = field(
        default=0.3, metadata={"help": "weight for phone CTC loss"}
    )
    encoder_ctc_weight: float = field(
        default=0.3, metadata={"help": "weight for encoder (subword) CTC loss"}
    )
    decoder_ctc_weight: float = field(
        default=0.2, metadata={"help": "weight for decoder CTC loss"}
    )
    post_process: str = field(
        default="sentencepiece",
        metadata={"help": "how to post-process predictions into words"},
    )
    task_type: str = field(
        default="st", metadata={"help": "st or asr"}
    )


@register_criterion("progressive_ctc", dataclass=ProgressiveCTCCriterionConfig)
class ProgressiveCTCCriterion(FairseqCriterion):
    """Multi-level CTC criterion for progressive S2T model."""

    def __init__(self, cfg: ProgressiveCTCCriterionConfig, task):
        super().__init__(task)
        self.blank_idx = 0
        self.tgt_pad = task.target_dictionary.pad()
        self.tgt_eos = task.target_dictionary.eos()
        self.char_pad = task.char_dictionary.pad()
        self.char_eos = task.char_dictionary.eos()
        self.phone_pad = task.phone_dictionary.pad()
        self.phone_eos = task.phone_dictionary.eos()

        self.zero_infinity = cfg.zero_infinity
        self.sentence_avg = cfg.sentence_avg
        self.char_ctc_weight = cfg.char_ctc_weight
        self.phone_ctc_weight = cfg.phone_ctc_weight
        self.encoder_ctc_weight = cfg.encoder_ctc_weight
        self.decoder_ctc_weight = cfg.decoder_ctc_weight
        self.post_process = cfg.post_process
        self.task_type = cfg.task_type

    def _ctc_loss(self, log_probs, targets, input_lengths, pad_idx, eos_idx):
        """CTC loss. log_probs: T x B x V; targets: B x S."""
        pad_mask = (targets != pad_idx) & (targets != eos_idx)
        targets_flat = targets.masked_select(pad_mask)
        tgt_lens = pad_mask.sum(-1)
        with torch.backends.cudnn.flags(enabled=False):
            loss = F.ctc_loss(
                log_probs,
                targets_flat,
                input_lengths,
                tgt_lens,
                blank=self.blank_idx,
                reduction="sum",
                zero_infinity=self.zero_infinity,
            )
        return loss

    def forward(self, model, sample, reduce=True):
        src_tokens = sample["net_input"]["src_tokens"]
        src_lengths = sample["net_input"]["src_lengths"]
        tgt_tokens = sample["target"]

        # Check task type
        is_asr = self.task_type == "asr"

        model_output = model(src_tokens, src_lengths, tgt_tokens)
        encoder_out = model_output["encoder_out"]

        device = src_tokens.device
        zero = torch.tensor(0.0, device=device)

        # ---- 1. Char CTC ----
        char_ctc_loss = zero.clone()
        if self.char_ctc_weight > 0 and sample.get("src_char_target") is not None:
            char_logits = model.encoder.get_char_ctc_logits(encoder_out)   # T_c x B x V_c
            char_lprobs = utils.log_softmax(char_logits.float(), dim=-1)
            char_input_lens = model.encoder.get_char_ctc_input_lengths(encoder_out)
            char_ctc_loss = self._ctc_loss(
                char_lprobs,
                sample["src_char_target"],
                char_input_lens,
                self.char_pad,
                self.char_eos,
            )

        # ---- 2. Phone CTC ----
        phone_ctc_loss = zero.clone()
        if self.phone_ctc_weight > 0 and sample.get("src_phone_target") is not None:
            phone_logits = model.encoder.get_phone_ctc_logits(encoder_out)  # T_p x B x V_p
            phone_lprobs = utils.log_softmax(phone_logits.float(), dim=-1)
            phone_input_lens = model.encoder.get_phone_ctc_input_lengths(encoder_out)
            phone_ctc_loss = self._ctc_loss(
                phone_lprobs,
                sample["src_phone_target"],
                phone_input_lens,
                self.phone_pad,
                self.phone_eos,
            )

        # ---- 3. Encoder subword CTC ----
        enc_ctc_loss = zero.clone()
        if self.encoder_ctc_weight > 0 and sample.get("src_word_target") is not None:
            enc_logits = model.encoder.get_ctc_logits(encoder_out)          # T x B x V
            enc_lprobs = utils.log_softmax(enc_logits.float(), dim=-1)
            enc_input_lens = model.encoder.get_ctc_input_lengths(encoder_out)
            enc_ctc_loss = self._ctc_loss(
                enc_lprobs,
                sample["src_word_target"],
                enc_input_lens,
                self.tgt_pad,
                self.tgt_eos,
            )

        # ---- 4. Decoder CTC (only for ST, not ASR) ----
        dec_ctc_loss = zero.clone()
        if not is_asr and self.decoder_ctc_weight > 0:
            dec_logits = model.decoder.get_ctc_logits(encoder_out)          # T x B x V
            dec_lprobs = utils.log_softmax(dec_logits.float(), dim=-1)
            dec_input_lens = model.decoder.get_ctc_input_lengths(encoder_out)
            dec_ctc_loss = self._ctc_loss(
                dec_lprobs,
                tgt_tokens,
                dec_input_lens,
                self.tgt_pad,
                self.tgt_eos,
            )

        # Total loss: ASR only uses encoder CTC losses, ST uses all
        if is_asr:
            loss = (
                self.char_ctc_weight    * char_ctc_loss
                + self.phone_ctc_weight * phone_ctc_loss
                + self.encoder_ctc_weight * enc_ctc_loss
            )
        else:
            loss = (
                self.char_ctc_weight    * char_ctc_loss
                + self.phone_ctc_weight * phone_ctc_loss
                + self.encoder_ctc_weight * enc_ctc_loss
                + self.decoder_ctc_weight * dec_ctc_loss
            )

        ntokens = sample["ntokens"]
        nsentences = sample["nsentences"]
        sample_size = nsentences if self.sentence_avg else ntokens

        logging_output = {
            "loss": utils.item(loss.data),
            "char_ctc_loss": utils.item(char_ctc_loss.data),
            "phone_ctc_loss": utils.item(phone_ctc_loss.data),
            "enc_ctc_loss": utils.item(enc_ctc_loss.data),
            "dec_ctc_loss": utils.item(dec_ctc_loss.data),
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": sample_size,
        }

        if not model.training:
            self._compute_val_metrics(model, sample, encoder_out, logging_output)

        return loss, sample_size, logging_output

    # ------------------------------------------------------------------
    # Validation metrics
    # ------------------------------------------------------------------

    @staticmethod
    def _greedy_ctc_decode(lprobs_bxTxV, input_lengths, blank_idx):
        """Greedy CTC decode. Returns list of token-id lists."""
        results = []
        for lp, inp_l in zip(lprobs_bxTxV, input_lengths):
            lp = lp[:inp_l]
            toks = lp.argmax(dim=-1).unique_consecutive()
            pred = toks[toks != blank_idx].tolist()
            results.append(pred)
        return results

    def _decode_hyps(self, lprobs_TxBxV, input_lengths, dictionary,
                     pad_idx, eos_idx, blank_idx, use_post_process=True):
        """Decode a batch of CTC log-probs into word strings."""
        lprobs_bxTxV = lprobs_TxBxV.transpose(0, 1).float().contiguous().cpu()
        token_lists = self._greedy_ctc_decode(lprobs_bxTxV, input_lengths.cpu(), blank_idx)
        strings = []
        for toks in token_lists:
            units = dictionary.string(toks)
            if use_post_process:
                words = post_process(units, self.post_process).strip()
            else:
                words = units.strip()
            strings.append(words)
        return strings

    def _compute_val_metrics(self, model, sample, encoder_out, logging_output):
        import editdistance

        tgt_dict = self.task.target_dictionary
        char_dict = self.task.char_dictionary
        phone_dict = self.task.phone_dictionary

        # Check task type
        is_asr = self.task_type == "asr"

        with torch.no_grad():
            # Encoder subword CTC
            enc_logits = model.encoder.get_ctc_logits(encoder_out)
            enc_lprobs = utils.log_softmax(enc_logits.float(), dim=-1)
            enc_lens = model.encoder.get_ctc_input_lengths(encoder_out)

            # Decoder CTC decode (only for ST, not ASR)
            if not is_asr:
                dec_logits = model.decoder.get_ctc_logits(encoder_out)
                dec_lprobs = utils.log_softmax(dec_logits.float(), dim=-1)
                dec_lens = model.decoder.get_ctc_input_lengths(encoder_out)
            else:
                dec_lprobs = None
                dec_lens = None

            # Char CTC
            if sample.get("src_char_target") is not None:
                char_logits = model.encoder.get_char_ctc_logits(encoder_out)
                char_lprobs = utils.log_softmax(char_logits.float(), dim=-1)
                char_lens = model.encoder.get_char_ctc_input_lengths(encoder_out)
            else:
                char_lprobs = None

            # Phone CTC
            if sample.get("src_phone_target") is not None:
                phone_logits = model.encoder.get_phone_ctc_logits(encoder_out)
                phone_lprobs = utils.log_softmax(phone_logits.float(), dim=-1)
                phone_lens = model.encoder.get_phone_ctc_input_lengths(encoder_out)
            else:
                phone_lprobs = None

        # Decode encoder hyps
        enc_hyps = self._decode_hyps(enc_lprobs, enc_lens, tgt_dict,
                                     self.tgt_pad, self.tgt_eos, self.blank_idx)

        # Decode decoder hyps (only for ST)
        if not is_asr:
            dec_hyps = self._decode_hyps(dec_lprobs, dec_lens, tgt_dict,
                                         self.tgt_pad, self.tgt_eos, self.blank_idx)
        else:
            dec_hyps = None

        # For ST: decoder refs from target; for ASR: no decoder refs
        if not is_asr:
            dec_refs = []
            for t in sample["target"]:
                p = (t != self.tgt_pad) & (t != self.tgt_eos)
                dec_refs.append(post_process(tgt_dict.string(t[p]), self.post_process).strip())
        else:
            dec_refs = None

        # Encoder refs from src_word_target
        enc_refs = []
        if sample.get("src_word_target") is not None:
            for t in sample["src_word_target"]:
                p = (t != self.tgt_pad) & (t != self.tgt_eos)
                enc_refs.append(post_process(tgt_dict.string(t[p]), self.post_process).strip())

        # Log first sample
        if not is_asr and dec_hyps:
            logger.info(f"DEC | REF: {dec_refs[0] if dec_refs else '?'}")
            logger.info(f"DEC | HYP: {dec_hyps[0]}")
        if enc_hyps:
            logger.info(f"ENC(subword) | REF: {enc_refs[0] if enc_refs else '?'}")
            logger.info(f"ENC(subword) | HYP: {enc_hyps[0]}")

        # Char decode + CER (no post_process for char)
        char_w_errs = 0
        char_w_len = 0
        if char_lprobs is not None and sample.get("src_char_target") is not None:
            char_hyps_raw = self._decode_hyps(
                char_lprobs, char_lens, char_dict,
                self.char_pad, self.char_eos, self.blank_idx, use_post_process=False
            )
            for i, (hyp, t) in enumerate(
                zip(char_hyps_raw, sample["src_char_target"])
            ):
                p = (t != self.char_pad) & (t != self.char_eos)
                ref = char_dict.string(t[p].tolist())
                # CER: character error rate, compare character sequences
                char_w_errs += editdistance.eval(hyp.split(), ref.split())
                char_w_len += len(ref.split())
                if i == 0:
                    logger.info(f"ENC(char) | REF: {ref}")
                    logger.info(f"ENC(char) | HYP: {hyp}")

        # Phone decode + PER (no post_process for phone)
        phone_w_errs = 0
        phone_w_len = 0
        if phone_lprobs is not None and sample.get("src_phone_target") is not None:
            phone_hyps_raw = self._decode_hyps(
                phone_lprobs, phone_lens, phone_dict,
                self.phone_pad, self.phone_eos, self.blank_idx, use_post_process=False
            )
            for i, (hyp, t) in enumerate(
                zip(phone_hyps_raw, sample["src_phone_target"])
            ):
                p = (t != self.phone_pad) & (t != self.phone_eos)
                ref = phone_dict.string(t[p].tolist())
                # PER: phone error rate, compare phone sequences
                phone_w_errs += editdistance.eval(hyp.split(), ref.split())
                phone_w_len += len(ref.split())
                if i == 0:
                    logger.info(f"ENC(phone) | REF: {ref}")
                    logger.info(f"ENC(phone) | HYP: {hyp}")

        logging_output["char_w_errors"] = char_w_errs
        logging_output["char_w_total"] = char_w_len
        logging_output["phone_w_errors"] = phone_w_errs
        logging_output["phone_w_total"] = phone_w_len

        # Encoder subword WER
        enc_w_errs = 0
        enc_w_len = 0
        for hyp, ref in zip(enc_hyps, enc_refs):
            enc_w_errs += editdistance.eval(hyp.split(), ref.split())
            enc_w_len += len(ref.split())
        logging_output["enc_w_errors"] = enc_w_errs
        logging_output["enc_w_total"] = enc_w_len

        if not is_asr:
            # Decoder BLEU (for ST)
            import sacrebleu
            bleu = sacrebleu.corpus_bleu(dec_hyps, [dec_refs])
            logging_output["_bleu_sys_len"] = bleu.sys_len
            logging_output["_bleu_ref_len"] = bleu.ref_len
            for i in range(4):
                logging_output[f"_bleu_counts_{i}"] = bleu.counts[i]
                logging_output[f"_bleu_totals_{i}"] = bleu.totals[i]
        # For ASR: no decoder metrics (encoder-only)

    # ------------------------------------------------------------------
    # Metric aggregation
    # ------------------------------------------------------------------

    @staticmethod
    def reduce_metrics(logging_outputs) -> None:
        loss_sum = utils.item(sum(log.get("loss", 0) for log in logging_outputs))
        char_ctc = utils.item(sum(log.get("char_ctc_loss", 0) for log in logging_outputs))
        phone_ctc = utils.item(sum(log.get("phone_ctc_loss", 0) for log in logging_outputs))
        enc_ctc = utils.item(sum(log.get("enc_ctc_loss", 0) for log in logging_outputs))
        dec_ctc = utils.item(sum(log.get("dec_ctc_loss", 0) for log in logging_outputs))
        ntokens = utils.item(sum(log.get("ntokens", 0) for log in logging_outputs))
        nsentences = utils.item(sum(log.get("nsentences", 0) for log in logging_outputs))
        sample_size = utils.item(sum(log.get("sample_size", 0) for log in logging_outputs))

        metrics.log_scalar("loss", loss_sum / sample_size / math.log(2), sample_size, round=3)
        metrics.log_scalar("char_ctc", char_ctc / sample_size / math.log(2), sample_size, round=3)
        metrics.log_scalar("phone_ctc", phone_ctc / sample_size / math.log(2), sample_size, round=3)
        metrics.log_scalar("enc_ctc", enc_ctc / sample_size / math.log(2), sample_size, round=3)
        metrics.log_scalar("dec_ctc", dec_ctc / sample_size / math.log(2), sample_size, round=3)
        metrics.log_scalar("ntokens", ntokens)
        metrics.log_scalar("nsentences", nsentences)

        def _wer_metric(prefix):
            errs = sum(log.get(f"{prefix}_w_errors", 0) for log in logging_outputs)
            total = sum(log.get(f"{prefix}_w_total", 0) for log in logging_outputs)
            if total > 0:
                metrics.log_scalar(f"_{prefix}_w_errors", errs)
                metrics.log_scalar(f"_{prefix}_w_total", total)
                metrics.log_derived(
                    f"{prefix}_wer",
                    lambda m, p=prefix: safe_round(
                        m[f"_{p}_w_errors"].sum * 100.0 / m[f"_{p}_w_total"].sum, 3
                    )
                    if m[f"_{p}_w_total"].sum > 0 else float("nan"),
                )

        _wer_metric("char")
        _wer_metric("phone")
        _wer_metric("enc")

        # Decoder WER (ASR)
        dec_w_errs = sum(log.get("dec_w_errors", 0) for log in logging_outputs)
        dec_w_total = sum(log.get("dec_w_total", 0) for log in logging_outputs)
        if dec_w_total > 0:
            _wer_metric("dec")

        # Decoder BLEU (ST)
        def sum_logs(key):
            result = sum(log.get(key, 0) for log in logging_outputs)
            if torch.is_tensor(result):
                result = result.cpu()
            return result

        counts = [sum_logs(f"_bleu_counts_{i}") for i in range(4)]
        totals = [sum_logs(f"_bleu_totals_{i}") for i in range(4)]

        if max(totals) > 0:
            metrics.log_scalar("_bleu_counts", np.array(counts))
            metrics.log_scalar("_bleu_totals", np.array(totals))
            metrics.log_scalar("_bleu_sys_len", sum_logs("_bleu_sys_len"))
            metrics.log_scalar("_bleu_ref_len", sum_logs("_bleu_ref_len"))

            def compute_bleu(meters):
                import inspect
                try:
                    from sacrebleu.metrics import BLEU
                    comp_bleu = BLEU.compute_bleu
                except ImportError:
                    import sacrebleu
                    comp_bleu = sacrebleu.compute_bleu
                fn_sig = inspect.getfullargspec(comp_bleu)[0]
                smooth = {"smooth_method": "exp"} if "smooth_method" in fn_sig else {"smooth": "exp"}
                bleu = comp_bleu(
                    correct=meters["_bleu_counts"].sum,
                    total=meters["_bleu_totals"].sum,
                    sys_len=int(meters["_bleu_sys_len"].sum),
                    ref_len=int(meters["_bleu_ref_len"].sum),
                    **smooth,
                )
                return round(bleu.score, 2)

            metrics.log_derived("bleu", compute_bleu)

    @staticmethod
    def logging_outputs_can_be_summed() -> bool:
        return True
