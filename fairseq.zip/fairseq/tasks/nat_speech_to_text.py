# Non-autoregressive Speech-to-Text Task with dual CTC.
# Supports both ST (speech translation) and ASR (speech recognition).

import logging
import json
import math
import os
from argparse import Namespace
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch

from fairseq import utils
from fairseq.data import Dictionary, encoders
from fairseq.data.audio.speech_to_text_dataset import (
    SpeechToTextDataset,
    SpeechToTextDatasetCreator,
    SpeechToTextDatasetItem,
    _collate_frames,
)
from fairseq.data.audio.data_cfg import S2TDataConfig
from fairseq.data import data_utils as fairseq_data_utils
from fairseq.data import FairseqDataset
from fairseq.logging import metrics
from fairseq.tasks import register_task, LegacyFairseqTask

logger = logging.getLogger(__name__)


class NATS2TDataset(SpeechToTextDataset):
    """Extended dataset that also tokenizes and returns src_word_text."""

    def __init__(
        self,
        split,
        is_train_split,
        cfg,
        audio_paths,
        n_frames,
        src_texts=None,
        tgt_texts=None,
        speakers=None,
        src_langs=None,
        tgt_langs=None,
        ids=None,
        tgt_dict=None,
        pre_tokenizer=None,
        bpe_tokenizer=None,
        n_frames_per_step=1,
        speaker_to_id=None,
        append_eos=True,
        src_word_texts=None,
        src_word_bpe_tokenizer=None,
    ):
        super().__init__(
            split=split,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            append_eos=append_eos,
        )
        self.src_word_texts = src_word_texts
        self.src_word_bpe_tokenizer = src_word_bpe_tokenizer

    def get_tokenized_src_word_text(self, index):
        text = self.src_word_texts[index]
        text = self.tokenize(self.pre_tokenizer, text)
        text = self.tokenize(self.src_word_bpe_tokenizer, text)
        return text

    def __getitem__(self, index):
        s2t_item = super().__getitem__(index)

        src_word_target = None
        if self.src_word_texts is not None:
            tokenized = self.get_tokenized_src_word_text(index)
            src_word_target = self.tgt_dict.encode_line(
                tokenized, add_if_not_exist=False, append_eos=True
            ).long()

        return s2t_item, src_word_target

    def collater(self, samples, return_order=False):
        if len(samples) == 0:
            return {}

        s2t_samples = [s for s, _ in samples]
        src_word_targets = [sw for _, sw in samples]

        # Use parent collater
        indices = torch.tensor([x.index for x in s2t_samples], dtype=torch.long)
        sources = [x.source for x in s2t_samples]
        frames = _collate_frames(sources, self.cfg.use_audio_input)
        n_frames = torch.tensor([x.size(0) for x in sources], dtype=torch.long)
        n_frames, order = n_frames.sort(descending=True)
        indices = indices.index_select(0, order)
        frames = frames.index_select(0, order)

        target, target_lengths = None, None
        prev_output_tokens = None
        ntokens = None
        if self.tgt_texts is not None:
            target = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                self.tgt_dict.eos(),
                left_pad=False,
                move_eos_to_beginning=False,
            ).index_select(0, order)
            target_lengths = torch.tensor(
                [x.target.size(0) for x in s2t_samples], dtype=torch.long
            ).index_select(0, order)
            prev_output_tokens = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                eos_idx=None,
                left_pad=False,
                move_eos_to_beginning=True,
            ).index_select(0, order)
            ntokens = sum(x.target.size(0) for x in s2t_samples)

        # Collate src_word_text targets
        src_word_target_collated = None
        src_word_target_lengths = None
        if src_word_targets[0] is not None:
            src_word_target_collated = fairseq_data_utils.collate_tokens(
                src_word_targets,
                self.tgt_dict.pad(),
                self.tgt_dict.eos(),
                left_pad=False,
                move_eos_to_beginning=False,
            ).index_select(0, order)
            src_word_target_lengths = torch.tensor(
                [t.size(0) for t in src_word_targets], dtype=torch.long
            ).index_select(0, order)

        net_input = {
            "src_tokens": frames,
            "src_lengths": n_frames,
            "prev_output_tokens": prev_output_tokens,
        }
        out = {
            "id": indices,
            "net_input": net_input,
            "target": target,
            "target_lengths": target_lengths,
            "ntokens": ntokens,
            "nsentences": len(samples),
            "src_word_target": src_word_target_collated,
            "src_word_target_lengths": src_word_target_lengths,
        }
        if return_order:
            out["order"] = order
        return out


class NATS2TDatasetCreator(SpeechToTextDatasetCreator):
    """Creator that reads src_word_text column and builds NATS2TDataset."""

    KEY_SRC_WORD_TEXT = "src_word_text"

    @classmethod
    def _from_list(
        cls,
        split_name,
        is_train_split,
        samples,
        cfg,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        src_word_bpe_tokenizer=None,
    ):
        audio_root = Path(cfg.audio_root)
        ids = [s[cls.KEY_ID] for s in samples]
        audio_paths = [(audio_root / s[cls.KEY_AUDIO]).as_posix() for s in samples]
        n_frames = [int(s[cls.KEY_N_FRAMES]) for s in samples]
        tgt_texts = [s[cls.KEY_TGT_TEXT] for s in samples]
        src_texts = [s.get(cls.KEY_SRC_TEXT, cls.DEFAULT_SRC_TEXT) for s in samples]
        speakers = [s.get(cls.KEY_SPEAKER, cls.DEFAULT_SPEAKER) for s in samples]
        src_langs = [s.get(cls.KEY_SRC_LANG, cls.DEFAULT_LANG) for s in samples]
        tgt_langs = [s.get(cls.KEY_TGT_LANG, cls.DEFAULT_LANG) for s in samples]

        src_word_texts = [s.get(cls.KEY_SRC_WORD_TEXT, "") for s in samples]

        ds = NATS2TDataset(
            split=split_name,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            src_word_texts=src_word_texts,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )
        return ds

    @classmethod
    def _from_tsv(
        cls,
        root,
        cfg,
        split,
        tgt_dict,
        is_train_split,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        src_word_bpe_tokenizer=None,
    ):
        samples = cls._load_samples_from_tsv(root, split)
        return cls._from_list(
            split,
            is_train_split,
            samples,
            cfg,
            tgt_dict,
            pre_tokenizer,
            bpe_tokenizer,
            n_frames_per_step,
            speaker_to_id,
            multitask,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )

    @classmethod
    def from_tsv(
        cls,
        root,
        cfg,
        splits,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        is_train_split,
        epoch,
        seed,
        n_frames_per_step=1,
        speaker_to_id=None,
        multitask=None,
        src_word_bpe_tokenizer=None,
    ):
        from fairseq.data import ConcatDataset

        datasets = [
            cls._from_tsv(
                root=root,
                cfg=cfg,
                split=split,
                tgt_dict=tgt_dict,
                is_train_split=is_train_split,
                pre_tokenizer=pre_tokenizer,
                bpe_tokenizer=bpe_tokenizer,
                n_frames_per_step=n_frames_per_step,
                speaker_to_id=speaker_to_id,
                multitask=multitask,
                src_word_bpe_tokenizer=src_word_bpe_tokenizer,
            )
            for split in splits.split(",")
        ]
        return ConcatDataset(datasets) if len(datasets) > 1 else datasets[0]


@register_task("nat_speech_to_text")
class NATSpeechToTextTask(LegacyFairseqTask):
    """Task for non-autoregressive speech-to-text with dual CTC."""

    @staticmethod
    def add_args(parser):
        parser.add_argument("data", help="manifest root path")
        parser.add_argument(
            "--config-yaml", type=str, default="config.yaml",
            help="Configuration YAML filename",
        )
        parser.add_argument(
            "--max-source-positions", type=int, default=6000,
            help="max number of tokens in the source sequence",
        )
        parser.add_argument(
            "--max-target-positions", type=int, default=1024,
            help="max number of tokens in the target sequence",
        )
        parser.add_argument(
            "--task-type", type=str, default="st",
            choices=["st", "asr"],
            help="st for speech translation, asr for speech recognition",
        )

    def __init__(self, args, tgt_dict):
        super().__init__(args)
        self.tgt_dict = tgt_dict
        self.data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        self.task_type = getattr(args, "task_type", "st")

    @classmethod
    def setup_task(cls, args, **kwargs):
        data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        dict_path = Path(args.data) / data_cfg.vocab_filename
        if not dict_path.is_file():
            raise FileNotFoundError(f"Dict not found: {dict_path}")
        tgt_dict = Dictionary.load(dict_path.as_posix())
        logger.info(
            f"dictionary size ({data_cfg.vocab_filename}): " f"{len(tgt_dict):,}"
        )
        return cls(args, tgt_dict)

    def build_criterion(self, args):
        from fairseq import criterions
        return criterions.build_criterion(args, self)

    def load_dataset(self, split, epoch=1, combine=False, **kwargs):
        is_train_split = split.startswith("train")
        pre_tokenizer = self.build_tokenizer(self.args)
        bpe_tokenizer = self.build_bpe(self.args)
        src_word_bpe_tokenizer = self.build_src_word_bpe(self.args)
        self.datasets[split] = NATS2TDatasetCreator.from_tsv(
            root=self.args.data,
            cfg=self.data_cfg,
            splits=split,
            tgt_dict=self.tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            is_train_split=is_train_split,
            epoch=epoch,
            seed=self.args.seed,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )

    @property
    def target_dictionary(self):
        return self.tgt_dict

    @property
    def source_dictionary(self):
        return None

    def max_positions(self):
        return self.args.max_source_positions, self.args.max_target_positions

    def build_model(self, args, from_checkpoint=False):
        args.input_feat_per_channel = self.data_cfg.input_feat_per_channel
        args.input_channels = self.data_cfg.input_channels
        return super().build_model(args, from_checkpoint)

    def build_tokenizer(self, args):
        logger.info(f"pre-tokenizer: None")
        return None

    def build_bpe(self, args):
        logger.info(f"tokenizer: {self.data_cfg.bpe_tokenizer}")
        return encoders.build_bpe(Namespace(**self.data_cfg.bpe_tokenizer))

    def build_src_word_bpe(self, args):
        src_word_bpe_cfg = self.data_cfg.config.get("src_word_bpe_tokenizer", None)
        if src_word_bpe_cfg is not None:
            # Resolve relative paths using data_cfg root
            src_word_bpe_cfg = self.data_cfg._auto_convert_to_abs_path(src_word_bpe_cfg)
            logger.info(f"src_word tokenizer: {src_word_bpe_cfg}")
            return encoders.build_bpe(Namespace(**src_word_bpe_cfg))
        # fallback to the same bpe as tgt
        return self.build_bpe(args)

    def build_generator(self, models, args, **kwargs):
        from fairseq.iterative_refinement_generator import IterativeRefinementGenerator
        return IterativeRefinementGenerator(
            self.target_dictionary,
            eos_penalty=getattr(args, "iter_decode_eos_penalty", 0.0),
            max_iter=getattr(args, "iter_decode_max_iter", 0),
            beam_size=getattr(args, "iter_decode_with_beam", 1),
            reranking=getattr(args, "iter_decode_with_external_reranker", False),
            decoding_format=getattr(args, "decoding_format", None),
            adaptive=not getattr(args, "iter_decode_force_max_iter", False),
            retain_history=getattr(args, "retain_iter_history", False),
        )

    def valid_step(self, sample, model, criterion):
        model.eval()
        with torch.no_grad():
            loss, sample_size, logging_output = criterion(model, sample)
        return loss, sample_size, logging_output

    def reduce_metrics(self, logging_outputs, criterion):
        super().reduce_metrics(logging_outputs, criterion)
