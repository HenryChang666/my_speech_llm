# Multi-Scale Speech-to-Text Task (Phase 3).
# Extends nat_speech_to_text with multi-scale subword supervision.
# TSV columns used:
#   tgt_text      -> decoder CTC target (German for ST, English for ASR)
#   src_word_text -> large vocab encoder CTC (10000 vocab, SPM)
#   src_text      -> medium vocab encoder CTC (1000 vocab, SPM)
#   src_char_text -> small vocab encoder CTC (250 vocab, SPM)

import logging
import os
from argparse import Namespace
from pathlib import Path

import torch

from fairseq import utils
from fairseq.data import Dictionary, encoders
from fairseq.data.audio.speech_to_text_dataset import (
    SpeechToTextDataset,
    SpeechToTextDatasetCreator,
    SpeechToTextDatasetItem,
    _collate_frames,
)
from fairseq.data.audio.data_cfg import S2TDataConfig
from fairseq.data import data_utils as fairseq_data_utils
from fairseq.tasks import register_task, LegacyFairseqTask

logger = logging.getLogger(__name__)


class MultiScaleS2TDataset(SpeechToTextDataset):
    """Dataset that additionally returns small/medium vocab subword supervision.

    Extra __getitem__ fields compared to the base dataset:
        src_small_target  : small vocab token ids  (250 vocab, from src_char_text column)
        src_medium_target : medium vocab token ids (1000 vocab, from src_text column)
        src_large_target  : large vocab token ids  (10000 vocab, from src_word_text column)
    """

    def __init__(
        self,
        split,
        is_train_split,
        cfg,
        audio_paths,
        n_frames,
        src_texts=None,
        tgt_texts=None,
        speakers=None,
        src_langs=None,
        tgt_langs=None,
        ids=None,
        tgt_dict=None,
        pre_tokenizer=None,
        bpe_tokenizer=None,
        n_frames_per_step=1,
        speaker_to_id=None,
        append_eos=True,
        # Multi-scale extra columns
        src_small_texts=None,
        src_medium_texts=None,
        src_large_texts=None,
        small_dict=None,
        medium_dict=None,
        small_bpe_tokenizer=None,
        medium_bpe_tokenizer=None,
        large_bpe_tokenizer=None,
    ):
        super().__init__(
            split=split,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            append_eos=append_eos,
        )
        self.src_small_texts = src_small_texts
        self.src_medium_texts = src_medium_texts
        self.src_large_texts = src_large_texts
        self.small_dict = small_dict
        self.medium_dict = medium_dict
        self.small_bpe_tokenizer = small_bpe_tokenizer
        self.medium_bpe_tokenizer = medium_bpe_tokenizer
        self.large_bpe_tokenizer = large_bpe_tokenizer
        logger.info(f"MultiScaleS2TDataset.__init__: small_dict size={len(small_dict) if small_dict else 'None'}")

    def _preprocess_char_text(self, text):
        """Convert character-level text (e.g., 'c h a p t e r | o n e') to raw text.
        
        TSV files store character-level text with spaces between chars and '|' between words.
        This converts it back to raw text for proper BPE tokenization.
        
        For phone text (e.g., '▁HH IY1 ▁HH OW1 P T'), just remove spaces within each phone.
        """
        if not text:
            return text
        # If text contains '|', it's character-level format: "c h a r | o n e"
        if '|' in text:
            words = text.split('|')
            raw_words = [''.join(w.split()) for w in words if w.strip()]
            return ' '.join(raw_words)
        else:
            # Phone-level format: "▁HH IY1 ▁HH OW1 P T" - just remove spaces
            # But keep the ▁ as word boundaries
            return ''.join(text.split())

    def _encode_with_bpe(self, text, dictionary, bpe_tokenizer, is_char_text=False):
        """Tokenize with BPE and encode into dictionary integer IDs.
        
        Args:
            text: Input text
            dictionary: Target dictionary
            bpe_tokenizer: BPE tokenizer
            is_char_text: If True, preprocess text as character-level format (spaces between chars, '|' between words)
        """
        if bpe_tokenizer is not None:
            if is_char_text:
                text = self._preprocess_char_text(text)
            text = self.tokenize(self.pre_tokenizer, text)
            text = self.tokenize(bpe_tokenizer, text)
        # Debug: check what dictionary.encode_line receives
        result = dictionary.encode_line(
            text, add_if_not_exist=False, append_eos=True
        ).long()
        if len(result) > 0:
            first_ids = result.tolist()[:5]
            # logger.info(f"  encode input: {repr(text[:50])}, first IDs: {first_ids}")
        return result

    def __getitem__(self, index):
        s2t_item = super().__getitem__(index)

        src_small_target = None
        if self.src_small_texts is not None and self.small_dict is not None:
            # Small vocab (250): tokenize with BPE, encode into small_dict
            # src_char_text is in format "c h a r | o n e", need to preprocess
            raw_text = self.src_small_texts[index]
            # if index < 3:
            #     logger.info(f"small text[{index}]: raw={repr(raw_text[:50])}, dict_size={len(self.small_dict)}, bpe={self.small_bpe_tokenizer is not None}")
            src_small_target = self._encode_with_bpe(
                raw_text, self.small_dict, self.small_bpe_tokenizer, is_char_text=False
            )
            # if index < 3:
            #     logger.info(f"small encoded[{index}]: {src_small_target.tolist()}")

        src_medium_target = None
        if self.src_medium_texts is not None and self.medium_dict is not None:
            # Medium vocab (1000): tokenize with BPE, encode into medium_dict
            # src_text (phone) may also be in character format, preprocess it
            raw_text = self.src_medium_texts[index]
            # if index < 3:
            #     logger.info(f"medium text[{index}]: raw={repr(raw_text[:50])}, bpe={self.medium_bpe_tokenizer is not None}")
            src_medium_target = self._encode_with_bpe(
                raw_text, self.medium_dict, self.medium_bpe_tokenizer, is_char_text=False
            )
            # if index < 3:
            #     logger.info(f"medium encoded[{index}]: {src_medium_target.tolist()}")

        src_large_target = None
        if self.src_large_texts is not None and self.large_bpe_tokenizer is not None:
            # Large vocab (10000): tokenize with BPE, encode into tgt_dict
            src_large_target = self._encode_with_bpe(
                self.src_large_texts[index], self.tgt_dict, self.large_bpe_tokenizer
            )

        return s2t_item, src_small_target, src_medium_target, src_large_target

    def collater(self, samples, return_order=False):
        if len(samples) == 0:
            return {}

        s2t_samples = [s for s, _, _, _ in samples]
        src_small_targets = [c for _, c, _, _ in samples]
        src_medium_targets = [p for _, _, p, _ in samples]
        src_large_targets = [w for _, _, _, w in samples]

        # Sort by source length (descending) - same as base class
        indices = torch.tensor([x.index for x in s2t_samples], dtype=torch.long)
        sources = [x.source for x in s2t_samples]
        frames = _collate_frames(sources, self.cfg.use_audio_input)
        n_frames = torch.tensor([x.size(0) for x in sources], dtype=torch.long)
        n_frames, order = n_frames.sort(descending=True)
        indices = indices.index_select(0, order)
        frames = frames.index_select(0, order)

        target = None
        target_lengths = None
        prev_output_tokens = None
        ntokens = None
        if self.tgt_texts is not None:
            target = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                self.tgt_dict.eos(),
                left_pad=False,
                move_eos_to_beginning=False,
            ).index_select(0, order)
            target_lengths = torch.tensor(
                [x.target.size(0) for x in s2t_samples], dtype=torch.long
            ).index_select(0, order)
            prev_output_tokens = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                eos_idx=None,
                left_pad=False,
                move_eos_to_beginning=True,
            ).index_select(0, order)
            ntokens = sum(x.target.size(0) for x in s2t_samples)

        def _collate_optional(items, pad_idx, eos_idx):
            if items[0] is None:
                return None, None
            collated = fairseq_data_utils.collate_tokens(
                items, pad_idx, eos_idx,
                left_pad=False, move_eos_to_beginning=False,
            ).index_select(0, order)
            lengths = torch.tensor(
                [t.size(0) for t in items], dtype=torch.long
            ).index_select(0, order)
            return collated, lengths

        src_small_collated, src_small_lengths = _collate_optional(
            src_small_targets,
            self.small_dict.pad() if self.small_dict is not None else 1,
            self.small_dict.eos() if self.small_dict is not None else 2,
        )
        src_medium_collated, src_medium_lengths = _collate_optional(
            src_medium_targets,
            self.medium_dict.pad() if self.medium_dict is not None else 1,
            self.medium_dict.eos() if self.medium_dict is not None else 2,
        )
        src_large_collated, src_large_lengths = _collate_optional(
            src_large_targets,
            self.tgt_dict.pad(),
            self.tgt_dict.eos(),
        )

        out = {
            "id": indices,
            "net_input": {
                "src_tokens": frames,
                "src_lengths": n_frames,
                "prev_output_tokens": prev_output_tokens,
            },
            "target": target,
            "target_lengths": target_lengths,
            "ntokens": ntokens,
            "nsentences": len(samples),
            # Multi-scale targets
            "src_small_target": src_small_collated,
            "src_small_target_lengths": src_small_lengths,
            "src_medium_target": src_medium_collated,
            "src_medium_target_lengths": src_medium_lengths,
            "src_large_target": src_large_collated,
            "src_large_target_lengths": src_large_lengths,
        }
        if return_order:
            out["order"] = order
        return out


class MultiScaleS2TDatasetCreator(SpeechToTextDatasetCreator):
    """Creator for MultiScaleS2TDataset."""

    KEY_SRC_SMALL_TEXT = "src_word_text"    # small vocab (250) - use same source as large
    KEY_SRC_MEDIUM_TEXT = "src_word_text"   # medium vocab (1000) - use same source as large
    KEY_SRC_LARGE_TEXT = "src_word_text"    # large vocab (10000)

    @classmethod
    def _from_list(
        cls,
        split_name,
        is_train_split,
        samples,
        cfg,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        small_dict=None,
        medium_dict=None,
        small_bpe_tokenizer=None,
        medium_bpe_tokenizer=None,
        large_bpe_tokenizer=None,
    ):
        audio_root = Path(cfg.audio_root)
        ids = [s[cls.KEY_ID] for s in samples]
        audio_paths = [(audio_root / s[cls.KEY_AUDIO]).as_posix() for s in samples]
        n_frames = [int(s[cls.KEY_N_FRAMES]) for s in samples]
        tgt_texts = [s[cls.KEY_TGT_TEXT] for s in samples]
        src_texts = [s.get(cls.KEY_SRC_TEXT, cls.DEFAULT_SRC_TEXT) for s in samples]
        speakers = [s.get(cls.KEY_SPEAKER, cls.DEFAULT_SPEAKER) for s in samples]
        src_langs = [s.get(cls.KEY_SRC_LANG, cls.DEFAULT_LANG) for s in samples]
        tgt_langs = [s.get(cls.KEY_TGT_LANG, cls.DEFAULT_LANG) for s in samples]

        src_small_texts = [s.get(cls.KEY_SRC_SMALL_TEXT, "") for s in samples]
        src_medium_texts = [s.get(cls.KEY_SRC_MEDIUM_TEXT, "") for s in samples]
        src_large_texts = [s.get(cls.KEY_SRC_LARGE_TEXT, "") for s in samples]

        return MultiScaleS2TDataset(
            split=split_name,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            src_small_texts=src_small_texts,
            src_medium_texts=src_medium_texts,
            src_large_texts=src_large_texts,
            small_dict=small_dict,
            medium_dict=medium_dict,
            small_bpe_tokenizer=small_bpe_tokenizer,
            medium_bpe_tokenizer=medium_bpe_tokenizer,
            large_bpe_tokenizer=large_bpe_tokenizer,
        )

    @classmethod
    def _from_tsv(
        cls,
        root,
        cfg,
        split,
        tgt_dict,
        is_train_split,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        small_dict=None,
        medium_dict=None,
        small_bpe_tokenizer=None,
        medium_bpe_tokenizer=None,
        large_bpe_tokenizer=None,
    ):
        samples = cls._load_samples_from_tsv(root, split)
        return cls._from_list(
            split,
            is_train_split,
            samples,
            cfg,
            tgt_dict,
            pre_tokenizer,
            bpe_tokenizer,
            n_frames_per_step,
            speaker_to_id,
            multitask,
            small_dict=small_dict,
            medium_dict=medium_dict,
            small_bpe_tokenizer=small_bpe_tokenizer,
            medium_bpe_tokenizer=medium_bpe_tokenizer,
            large_bpe_tokenizer=large_bpe_tokenizer,
        )

    @classmethod
    def from_tsv(
        cls,
        root,
        cfg,
        splits,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        is_train_split,
        epoch,
        seed,
        n_frames_per_step=1,
        speaker_to_id=None,
        multitask=None,
        small_dict=None,
        medium_dict=None,
        small_bpe_tokenizer=None,
        medium_bpe_tokenizer=None,
        large_bpe_tokenizer=None,
    ):
        from fairseq.data import ConcatDataset

        datasets = [
            cls._from_tsv(
                root=root,
                cfg=cfg,
                split=split,
                tgt_dict=tgt_dict,
                is_train_split=is_train_split,
                pre_tokenizer=pre_tokenizer,
                bpe_tokenizer=bpe_tokenizer,
                n_frames_per_step=n_frames_per_step,
                speaker_to_id=speaker_to_id,
                multitask=multitask,
                small_dict=small_dict,
                medium_dict=medium_dict,
                small_bpe_tokenizer=small_bpe_tokenizer,
                medium_bpe_tokenizer=medium_bpe_tokenizer,
                large_bpe_tokenizer=large_bpe_tokenizer,
            )
            for split in splits.split(",")
        ]
        return ConcatDataset(datasets) if len(datasets) > 1 else datasets[0]


@register_task("multiscale_speech_to_text")
class MultiScaleSpeechToTextTask(LegacyFairseqTask):
    """Task for multi-scale speech-to-text with multi-level subword CTC supervision.

    config.yaml extensions beyond standard S2T:
        small_vocab_filename : filename of small vocab dictionary (default: dict_small.txt)
        medium_vocab_filename: filename of medium vocab dictionary (default: dict_medium.txt)
        small_bpe_tokenizer  : BPE config for small vocab
        medium_bpe_tokenizer : BPE config for medium vocab
    """

    @staticmethod
    def add_args(parser):
        parser.add_argument("data", help="manifest root path")
        parser.add_argument(
            "--config-yaml", type=str, default="config.yaml",
            help="Configuration YAML filename",
        )
        parser.add_argument(
            "--max-source-positions", type=int, default=6000,
        )
        parser.add_argument(
            "--max-target-positions", type=int, default=1024,
        )
        parser.add_argument(
            "--task-type", type=str, default="st", choices=["st", "asr"],
        )
        parser.add_argument(
            "--small-vocab-filename", type=str, default="dict_small.txt",
            help="filename of small vocab dictionary (250 vocab)",
        )
        parser.add_argument(
            "--medium-vocab-filename", type=str, default="dict_medium.txt",
            help="filename of medium vocab dictionary (1000 vocab)",
        )

    def __init__(self, args, tgt_dict, small_dict, medium_dict):
        super().__init__(args)
        self.tgt_dict = tgt_dict
        self.small_dict = small_dict
        self.medium_dict = medium_dict
        self.data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        self.task_type = getattr(args, "task_type", "st")

    @classmethod
    def setup_task(cls, args, **kwargs):
        data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        data_root = Path(args.data)

        # Main target vocabulary (large vocab 10000, shared encoder+decoder)
        dict_path = data_root / data_cfg.vocab_filename
        if not dict_path.is_file():
            raise FileNotFoundError(f"Dict not found: {dict_path}")
        tgt_dict = Dictionary.load(dict_path.as_posix())
        logger.info(f"target dict ({data_cfg.vocab_filename}): {len(tgt_dict):,}")

        # Small vocabulary (250)
        small_vocab = getattr(args, "small_vocab_filename", "dict_small.txt")
        small_dict_path = data_root / small_vocab
        if not small_dict_path.is_file():
            raise FileNotFoundError(f"Small dict not found: {small_dict_path}")
        small_dict = Dictionary.load(small_dict_path.as_posix())
        logger.info(f"small dict ({small_vocab}): {len(small_dict):,}")

        # Medium vocabulary (1000)
        medium_vocab = getattr(args, "medium_vocab_filename", "dict_medium.txt")
        medium_dict_path = data_root / medium_vocab
        if not medium_dict_path.is_file():
            raise FileNotFoundError(f"Medium dict not found: {medium_dict_path}")
        medium_dict = Dictionary.load(medium_dict_path.as_posix())
        logger.info(f"medium dict ({medium_vocab}): {len(medium_dict):,}")

        return cls(args, tgt_dict, small_dict, medium_dict)

    def build_criterion(self, args):
        from fairseq import criterions
        return criterions.build_criterion(args, self)

    def load_dataset(self, split, epoch=1, combine=False, **kwargs):
        is_train_split = split.startswith("train")
        pre_tokenizer = self.build_tokenizer(self.args)
        bpe_tokenizer = self.build_bpe(self.args)
        small_bpe_tokenizer = self.build_small_bpe(self.args)
        medium_bpe_tokenizer = self.build_medium_bpe(self.args)
        large_bpe_tokenizer = self.build_large_bpe(self.args)

        self.datasets[split] = MultiScaleS2TDatasetCreator.from_tsv(
            root=self.args.data,
            cfg=self.data_cfg,
            splits=split,
            tgt_dict=self.tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            is_train_split=is_train_split,
            epoch=epoch,
            seed=self.args.seed,
            small_dict=self.small_dict,
            medium_dict=self.medium_dict,
            small_bpe_tokenizer=small_bpe_tokenizer,
            medium_bpe_tokenizer=medium_bpe_tokenizer,
            large_bpe_tokenizer=large_bpe_tokenizer,
        )

    @property
    def target_dictionary(self):
        return self.tgt_dict

    @property
    def small_dictionary(self):
        return self.small_dict

    @property
    def medium_dictionary(self):
        return self.medium_dict

    @property
    def source_dictionary(self):
        return None

    def max_positions(self):
        return self.args.max_source_positions, self.args.max_target_positions

    def build_model(self, args, from_checkpoint=False):
        args.input_feat_per_channel = self.data_cfg.input_feat_per_channel
        args.input_channels = self.data_cfg.input_channels
        return super().build_model(args, from_checkpoint)

    def build_tokenizer(self, args):
        return None

    def build_bpe(self, args):
        logger.info(f"tokenizer: {self.data_cfg.bpe_tokenizer}")
        return encoders.build_bpe(Namespace(**self.data_cfg.bpe_tokenizer))

    def build_small_bpe(self, args):
        """Build BPE tokenizer for small vocab (250)."""
        small_bpe_cfg = self.data_cfg.config.get("small_bpe_tokenizer", None)
        logger.info(f"build_small_bpe: config={small_bpe_cfg}")
        if small_bpe_cfg is not None:
            small_bpe_cfg = self.data_cfg._auto_convert_to_abs_path(small_bpe_cfg)
            logger.info(f"build_small_bpe: building with {small_bpe_cfg}")
            return encoders.build_bpe(Namespace(**small_bpe_cfg))
        logger.warning("build_small_bpe: no config found, returning None")
        return None

    def build_medium_bpe(self, args):
        """Build BPE tokenizer for medium vocab (1000)."""
        medium_bpe_cfg = self.data_cfg.config.get("medium_bpe_tokenizer", None)
        logger.info(f"build_medium_bpe: config={medium_bpe_cfg}")
        if medium_bpe_cfg is not None:
            medium_bpe_cfg = self.data_cfg._auto_convert_to_abs_path(medium_bpe_cfg)
            logger.info(f"build_medium_bpe: building with {medium_bpe_cfg}")
            return encoders.build_bpe(Namespace(**medium_bpe_cfg))
        logger.warning("build_medium_bpe: no config found, returning None")
        return None

    def build_large_bpe(self, args):
        """Build BPE tokenizer for large vocab (10000)."""
        large_bpe_cfg = self.data_cfg.config.get("large_bpe_tokenizer", None)
        if large_bpe_cfg is not None:
            large_bpe_cfg = self.data_cfg._auto_convert_to_abs_path(large_bpe_cfg)
            return encoders.build_bpe(Namespace(**large_bpe_cfg))
        return self.build_bpe(args)

    def build_generator(self, models, args, **kwargs):
        # Not used in CTC-only inference, but keep compatible
        from fairseq.iterative_refinement_generator import IterativeRefinementGenerator
        return IterativeRefinementGenerator(
            self.target_dictionary,
            eos_penalty=getattr(args, "iter_decode_eos_penalty", 0.0),
            max_iter=getattr(args, "iter_decode_max_iter", 0),
            beam_size=getattr(args, "iter_decode_with_beam", 1),
            reranking=getattr(args, "iter_decode_with_external_reranker", False),
            decoding_format=getattr(args, "decoding_format", None),
            adaptive=not getattr(args, "iter_decode_force_max_iter", False),
            retain_history=getattr(args, "retain_iter_history", False),
        )

    def valid_step(self, sample, model, criterion):
        model.eval()
        with torch.no_grad():
            loss, sample_size, logging_output = criterion(model, sample)
        return loss, sample_size, logging_output

    def reduce_metrics(self, logging_outputs, criterion):
        super().reduce_metrics(logging_outputs, criterion)
