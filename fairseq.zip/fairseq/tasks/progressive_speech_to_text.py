# Progressive Speech-to-Text Task.
# Extends nat_speech_to_text with char-level and phone-level supervision.
# TSV columns used:
#   tgt_text      -> decoder CTC target (German for ST, English for ASR)
#   src_word_text -> subword encoder CTC (shared tgt vocab / SPM)
#   src_text      -> phone-level encoder CTC (dict.txt / phone_vocab_filename)
#   src_char_text -> char-level encoder CTC (dict_c.en.txt / char_vocab_filename)

import logging
import os
from argparse import Namespace
from pathlib import Path

import torch

from fairseq import utils
from fairseq.data import Dictionary, encoders
from fairseq.data.audio.speech_to_text_dataset import (
    SpeechToTextDataset,
    SpeechToTextDatasetCreator,
    SpeechToTextDatasetItem,
    _collate_frames,
)
from fairseq.data.audio.data_cfg import S2TDataConfig
from fairseq.data import data_utils as fairseq_data_utils
from fairseq.tasks import register_task, LegacyFairseqTask

logger = logging.getLogger(__name__)


class ProgressiveS2TDataset(SpeechToTextDataset):
    """Dataset that additionally returns char-level and phone-level supervision.

    Extra __getitem__ fields compared to the base dataset:
        src_char_target  : char-level token ids  (from src_char_text column)
        src_phone_target : phone-level token ids (from src_text      column)
        src_word_target  : subword token ids     (from src_word_text  column)
    """

    def __init__(
        self,
        split,
        is_train_split,
        cfg,
        audio_paths,
        n_frames,
        src_texts=None,
        tgt_texts=None,
        speakers=None,
        src_langs=None,
        tgt_langs=None,
        ids=None,
        tgt_dict=None,
        pre_tokenizer=None,
        bpe_tokenizer=None,
        n_frames_per_step=1,
        speaker_to_id=None,
        append_eos=True,
        # Progressive extra columns
        src_char_texts=None,
        src_phone_texts=None,
        src_word_texts=None,
        char_dict=None,
        phone_dict=None,
        src_word_bpe_tokenizer=None,
    ):
        super().__init__(
            split=split,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            append_eos=append_eos,
        )
        self.src_char_texts = src_char_texts
        self.src_phone_texts = src_phone_texts
        self.src_word_texts = src_word_texts
        self.char_dict = char_dict
        self.phone_dict = phone_dict
        self.src_word_bpe_tokenizer = src_word_bpe_tokenizer

    def _encode_with_dict(self, text, dictionary, bpe_tokenizer=None):
        """Tokenize raw text and encode into dictionary integer IDs."""
        if bpe_tokenizer is not None:
            text = self.tokenize(self.pre_tokenizer, text)
            text = self.tokenize(bpe_tokenizer, text)
        return dictionary.encode_line(
            text, add_if_not_exist=False, append_eos=True
        ).long()

    def __getitem__(self, index):
        s2t_item = super().__getitem__(index)

        src_char_target = None
        if self.src_char_texts is not None and self.char_dict is not None:
            # char text is already space-separated characters, no BPE needed
            src_char_target = self.char_dict.encode_line(
                self.src_char_texts[index],
                add_if_not_exist=False,
                append_eos=True,
            ).long()

        src_phone_target = None
        if self.src_phone_texts is not None and self.phone_dict is not None:
            # phone text is already space-separated tokens, no BPE needed
            src_phone_target = self.phone_dict.encode_line(
                self.src_phone_texts[index],
                add_if_not_exist=False,
                append_eos=True,
            ).long()

        src_word_target = None
        if self.src_word_texts is not None and self.src_word_bpe_tokenizer is not None:
            # subword: tokenize with BPE, encode into tgt_dict
            text = self.tokenize(self.pre_tokenizer, self.src_word_texts[index])
            text = self.tokenize(self.src_word_bpe_tokenizer, text)
            src_word_target = self.tgt_dict.encode_line(
                text, add_if_not_exist=False, append_eos=True
            ).long()

        return s2t_item, src_char_target, src_phone_target, src_word_target

    def collater(self, samples, return_order=False):
        if len(samples) == 0:
            return {}

        s2t_samples = [s for s, _, _, _ in samples]
        src_char_targets = [c for _, c, _, _ in samples]
        src_phone_targets = [p for _, _, p, _ in samples]
        src_word_targets = [w for _, _, _, w in samples]

        # Sort by source length (descending) - same as base class
        indices = torch.tensor([x.index for x in s2t_samples], dtype=torch.long)
        sources = [x.source for x in s2t_samples]
        frames = _collate_frames(sources, self.cfg.use_audio_input)
        n_frames = torch.tensor([x.size(0) for x in sources], dtype=torch.long)
        n_frames, order = n_frames.sort(descending=True)
        indices = indices.index_select(0, order)
        frames = frames.index_select(0, order)

        target = None
        target_lengths = None
        prev_output_tokens = None
        ntokens = None
        if self.tgt_texts is not None:
            target = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                self.tgt_dict.eos(),
                left_pad=False,
                move_eos_to_beginning=False,
            ).index_select(0, order)
            target_lengths = torch.tensor(
                [x.target.size(0) for x in s2t_samples], dtype=torch.long
            ).index_select(0, order)
            prev_output_tokens = fairseq_data_utils.collate_tokens(
                [x.target for x in s2t_samples],
                self.tgt_dict.pad(),
                eos_idx=None,
                left_pad=False,
                move_eos_to_beginning=True,
            ).index_select(0, order)
            ntokens = sum(x.target.size(0) for x in s2t_samples)

        def _collate_optional(items, pad_idx, eos_idx):
            if items[0] is None:
                return None, None
            collated = fairseq_data_utils.collate_tokens(
                items, pad_idx, eos_idx,
                left_pad=False, move_eos_to_beginning=False,
            ).index_select(0, order)
            lengths = torch.tensor(
                [t.size(0) for t in items], dtype=torch.long
            ).index_select(0, order)
            return collated, lengths

        src_char_collated, src_char_lengths = _collate_optional(
            src_char_targets,
            self.char_dict.pad() if self.char_dict is not None else 1,
            self.char_dict.eos() if self.char_dict is not None else 2,
        )
        src_phone_collated, src_phone_lengths = _collate_optional(
            src_phone_targets,
            self.phone_dict.pad() if self.phone_dict is not None else 1,
            self.phone_dict.eos() if self.phone_dict is not None else 2,
        )
        src_word_collated, src_word_lengths = _collate_optional(
            src_word_targets,
            self.tgt_dict.pad(),
            self.tgt_dict.eos(),
        )

        out = {
            "id": indices,
            "net_input": {
                "src_tokens": frames,
                "src_lengths": n_frames,
                "prev_output_tokens": prev_output_tokens,
            },
            "target": target,
            "target_lengths": target_lengths,
            "ntokens": ntokens,
            "nsentences": len(samples),
            # Progressive multi-level targets
            "src_char_target": src_char_collated,
            "src_char_target_lengths": src_char_lengths,
            "src_phone_target": src_phone_collated,
            "src_phone_target_lengths": src_phone_lengths,
            "src_word_target": src_word_collated,
            "src_word_target_lengths": src_word_lengths,
        }
        if return_order:
            out["order"] = order
        return out


class ProgressiveS2TDatasetCreator(SpeechToTextDatasetCreator):
    """Creator for ProgressiveS2TDataset."""

    KEY_SRC_CHAR_TEXT = "src_char_text"
    KEY_SRC_PHONE_TEXT = "src_text"          # phone-level
    KEY_SRC_WORD_TEXT = "src_word_text"      # subword-level

    @classmethod
    def _from_list(
        cls,
        split_name,
        is_train_split,
        samples,
        cfg,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        char_dict=None,
        phone_dict=None,
        src_word_bpe_tokenizer=None,
    ):
        audio_root = Path(cfg.audio_root)
        ids = [s[cls.KEY_ID] for s in samples]
        audio_paths = [(audio_root / s[cls.KEY_AUDIO]).as_posix() for s in samples]
        n_frames = [int(s[cls.KEY_N_FRAMES]) for s in samples]
        tgt_texts = [s[cls.KEY_TGT_TEXT] for s in samples]
        src_texts = [s.get(cls.KEY_SRC_TEXT, cls.DEFAULT_SRC_TEXT) for s in samples]
        speakers = [s.get(cls.KEY_SPEAKER, cls.DEFAULT_SPEAKER) for s in samples]
        src_langs = [s.get(cls.KEY_SRC_LANG, cls.DEFAULT_LANG) for s in samples]
        tgt_langs = [s.get(cls.KEY_TGT_LANG, cls.DEFAULT_LANG) for s in samples]

        src_char_texts = [s.get(cls.KEY_SRC_CHAR_TEXT, "") for s in samples]
        src_phone_texts = [s.get(cls.KEY_SRC_PHONE_TEXT, "") for s in samples]
        src_word_texts = [s.get(cls.KEY_SRC_WORD_TEXT, "") for s in samples]

        return ProgressiveS2TDataset(
            split=split_name,
            is_train_split=is_train_split,
            cfg=cfg,
            audio_paths=audio_paths,
            n_frames=n_frames,
            src_texts=src_texts,
            tgt_texts=tgt_texts,
            speakers=speakers,
            src_langs=src_langs,
            tgt_langs=tgt_langs,
            ids=ids,
            tgt_dict=tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            n_frames_per_step=n_frames_per_step,
            speaker_to_id=speaker_to_id,
            src_char_texts=src_char_texts,
            src_phone_texts=src_phone_texts,
            src_word_texts=src_word_texts,
            char_dict=char_dict,
            phone_dict=phone_dict,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )

    @classmethod
    def _from_tsv(
        cls,
        root,
        cfg,
        split,
        tgt_dict,
        is_train_split,
        pre_tokenizer,
        bpe_tokenizer,
        n_frames_per_step,
        speaker_to_id,
        multitask=None,
        char_dict=None,
        phone_dict=None,
        src_word_bpe_tokenizer=None,
    ):
        samples = cls._load_samples_from_tsv(root, split)
        return cls._from_list(
            split,
            is_train_split,
            samples,
            cfg,
            tgt_dict,
            pre_tokenizer,
            bpe_tokenizer,
            n_frames_per_step,
            speaker_to_id,
            multitask,
            char_dict=char_dict,
            phone_dict=phone_dict,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )

    @classmethod
    def from_tsv(
        cls,
        root,
        cfg,
        splits,
        tgt_dict,
        pre_tokenizer,
        bpe_tokenizer,
        is_train_split,
        epoch,
        seed,
        n_frames_per_step=1,
        speaker_to_id=None,
        multitask=None,
        char_dict=None,
        phone_dict=None,
        src_word_bpe_tokenizer=None,
    ):
        from fairseq.data import ConcatDataset

        datasets = [
            cls._from_tsv(
                root=root,
                cfg=cfg,
                split=split,
                tgt_dict=tgt_dict,
                is_train_split=is_train_split,
                pre_tokenizer=pre_tokenizer,
                bpe_tokenizer=bpe_tokenizer,
                n_frames_per_step=n_frames_per_step,
                speaker_to_id=speaker_to_id,
                multitask=multitask,
                char_dict=char_dict,
                phone_dict=phone_dict,
                src_word_bpe_tokenizer=src_word_bpe_tokenizer,
            )
            for split in splits.split(",")
        ]
        return ConcatDataset(datasets) if len(datasets) > 1 else datasets[0]


@register_task("progressive_speech_to_text")
class ProgressiveSpeechToTextTask(LegacyFairseqTask):
    """Task for progressive speech-to-text with multi-level CTC supervision.

    config.yaml extensions beyond standard S2T:
        char_vocab_filename : filename of char dictionary (default: dict_c.en.txt)
        phone_vocab_filename: filename of phone dictionary (default: dict.txt)
    """

    @staticmethod
    def add_args(parser):
        parser.add_argument("data", help="manifest root path")
        parser.add_argument(
            "--config-yaml", type=str, default="config.yaml",
            help="Configuration YAML filename",
        )
        parser.add_argument(
            "--max-source-positions", type=int, default=6000,
        )
        parser.add_argument(
            "--max-target-positions", type=int, default=1024,
        )
        parser.add_argument(
            "--task-type", type=str, default="st", choices=["st", "asr"],
        )
        parser.add_argument(
            "--char-vocab-filename", type=str, default="dict_c.en.txt",
            help="filename of char-level dictionary",
        )
        parser.add_argument(
            "--phone-vocab-filename", type=str, default="dict.txt",
            help="filename of phone-level dictionary",
        )

    def __init__(self, args, tgt_dict, char_dict, phone_dict):
        super().__init__(args)
        self.tgt_dict = tgt_dict
        self.char_dict = char_dict
        self.phone_dict = phone_dict
        self.data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        self.task_type = getattr(args, "task_type", "st")

    @classmethod
    def setup_task(cls, args, **kwargs):
        data_cfg = S2TDataConfig(Path(args.data) / args.config_yaml)
        data_root = Path(args.data)

        # Main target vocabulary (subword, shared encoder+decoder)
        dict_path = data_root / data_cfg.vocab_filename
        if not dict_path.is_file():
            raise FileNotFoundError(f"Dict not found: {dict_path}")
        tgt_dict = Dictionary.load(dict_path.as_posix())
        logger.info(f"target dict ({data_cfg.vocab_filename}): {len(tgt_dict):,}")

        # Char-level vocabulary
        char_vocab = getattr(args, "char_vocab_filename", "dict_c.en.txt")
        char_dict_path = data_root / char_vocab
        if not char_dict_path.is_file():
            raise FileNotFoundError(f"Char dict not found: {char_dict_path}")
        char_dict = Dictionary.load(char_dict_path.as_posix())
        logger.info(f"char dict ({char_vocab}): {len(char_dict):,}")

        # Phone-level vocabulary
        phone_vocab = getattr(args, "phone_vocab_filename", "dict.txt")
        phone_dict_path = data_root / phone_vocab
        if not phone_dict_path.is_file():
            raise FileNotFoundError(f"Phone dict not found: {phone_dict_path}")
        phone_dict = Dictionary.load(phone_dict_path.as_posix())
        logger.info(f"phone dict ({phone_vocab}): {len(phone_dict):,}")

        return cls(args, tgt_dict, char_dict, phone_dict)

    def build_criterion(self, args):
        from fairseq import criterions
        return criterions.build_criterion(args, self)

    def load_dataset(self, split, epoch=1, combine=False, **kwargs):
        is_train_split = split.startswith("train")
        pre_tokenizer = self.build_tokenizer(self.args)
        bpe_tokenizer = self.build_bpe(self.args)
        src_word_bpe_tokenizer = self.build_src_word_bpe(self.args)

        self.datasets[split] = ProgressiveS2TDatasetCreator.from_tsv(
            root=self.args.data,
            cfg=self.data_cfg,
            splits=split,
            tgt_dict=self.tgt_dict,
            pre_tokenizer=pre_tokenizer,
            bpe_tokenizer=bpe_tokenizer,
            is_train_split=is_train_split,
            epoch=epoch,
            seed=self.args.seed,
            char_dict=self.char_dict,
            phone_dict=self.phone_dict,
            src_word_bpe_tokenizer=src_word_bpe_tokenizer,
        )

    @property
    def target_dictionary(self):
        return self.tgt_dict

    @property
    def char_dictionary(self):
        return self.char_dict

    @property
    def phone_dictionary(self):
        return self.phone_dict

    @property
    def source_dictionary(self):
        return None

    def max_positions(self):
        return self.args.max_source_positions, self.args.max_target_positions

    def build_model(self, args, from_checkpoint=False):
        args.input_feat_per_channel = self.data_cfg.input_feat_per_channel
        args.input_channels = self.data_cfg.input_channels
        return super().build_model(args, from_checkpoint)

    def build_tokenizer(self, args):
        return None

    def build_bpe(self, args):
        logger.info(f"tokenizer: {self.data_cfg.bpe_tokenizer}")
        return encoders.build_bpe(Namespace(**self.data_cfg.bpe_tokenizer))

    def build_src_word_bpe(self, args):
        src_word_bpe_cfg = self.data_cfg.config.get("src_word_bpe_tokenizer", None)
        if src_word_bpe_cfg is not None:
            src_word_bpe_cfg = self.data_cfg._auto_convert_to_abs_path(src_word_bpe_cfg)
            return encoders.build_bpe(Namespace(**src_word_bpe_cfg))
        return self.build_bpe(args)

    def build_generator(self, models, args, **kwargs):
        # Not used in CTC-only inference, but keep compatible
        from fairseq.iterative_refinement_generator import IterativeRefinementGenerator
        return IterativeRefinementGenerator(
            self.target_dictionary,
            eos_penalty=getattr(args, "iter_decode_eos_penalty", 0.0),
            max_iter=getattr(args, "iter_decode_max_iter", 0),
            beam_size=getattr(args, "iter_decode_with_beam", 1),
            reranking=getattr(args, "iter_decode_with_external_reranker", False),
            decoding_format=getattr(args, "decoding_format", None),
            adaptive=not getattr(args, "iter_decode_force_max_iter", False),
            retain_history=getattr(args, "retain_iter_history", False),
        )

    def valid_step(self, sample, model, criterion):
        model.eval()
        with torch.no_grad():
            loss, sample_size, logging_output = criterion(model, sample)
        return loss, sample_size, logging_output

    def reduce_metrics(self, logging_outputs, criterion):
        super().reduce_metrics(logging_outputs, criterion)
