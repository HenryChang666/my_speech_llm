# Copyright (c) Facebook, Inc. and its affiliates.
# Progressive Speech Encoding NAT S2T model.
#
# Architecture:
#   - Encoder: 1-layer conv (2x) + 12 Transformer layers
#     - Before layer 7: Conv1d stride=2 (2x), total 4x
#     - Before layer 10: Conv1d stride=1 (no compress)
#     - Layer 6 output -> char-level CTC (dict_c.en.txt)
#     - Layer 9 output -> phone-level CTC (dict.txt / phone_vocab_filename)
#     - Layer 12 output -> subword CTC (spm vocab, shared with decoder)
#   - Decoder: Self-attention only (no cross-attn), decoder CTC (tgt vocab)

import logging
import math
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from fairseq import utils, checkpoint_utils
from fairseq.data.data_utils import lengths_to_padding_mask
from fairseq.models import (
    FairseqEncoder,
    BaseFairseqModel,
    register_model,
    register_model_architecture,
)
from fairseq.models.speech_to_text.modules.convolution import Conv1dSubsampler
from fairseq.models.transformer import Embedding
from fairseq.modules import (
    FairseqDropout,
    LayerNorm,
    PositionalEmbedding,
    TransformerEncoderLayer,
    TransformerDecoderLayer,
)

logger = logging.getLogger(__name__)


@register_model("progressive_s2t_transformer")
class ProgressiveS2TTransformerModel(BaseFairseqModel):
    """Progressive NAT S2T with multi-level CTC supervision.

    Encoder subsampling plan (total 4x):
      - subsample: 1-layer Conv1d, stride=2, input -> after layer 6
      - mid_conv:  1-layer Conv1d, stride=2, before layer 7 (mid_conv_layer)
      - top_conv:  1-layer Conv1d, stride=1, before layer 10 (top_conv_layer)

    CTC taps:
      - char_ctc_proj  : after layer char_ctc_layer  (default 6, before mid_conv)
      - phone_ctc_proj : after layer phone_ctc_layer (default 9, before top_conv)
      - ctc_proj       : after layer 12 (final encoder output = subword)

    Decoder:
      - Self-attention only (no cross-attention)
      - Takes encoder final output as input
      - decoder CTC -> tgt_text
    """

    def __init__(self, args, encoder, decoder, tgt_dict):
        super().__init__()
        self.args = args
        self.encoder = encoder
        self.decoder = decoder
        self.tgt_dict = tgt_dict
        self.bos = tgt_dict.bos()
        self.eos = tgt_dict.eos()
        self.unk = tgt_dict.unk()
        self.pad = tgt_dict.pad()
        # Check if ASR mode (encoder-only)
        self.encoder_only = getattr(args, "encoder_only", False)

    @staticmethod
    def add_args(parser):
        # Initial conv (1 layer, stride=2)
        parser.add_argument(
            "--conv-kernel-sizes", type=str, default="5",
            help="kernel sizes of initial Conv1d subsampling (single layer, e.g. '5')",
        )
        parser.add_argument(
            "--conv-channels", type=int, default=1024,
            help="# of channels in initial Conv1d subsampling",
        )
        # Mid conv (before mid_conv_layer, stride=2)
        parser.add_argument(
            "--mid-conv-kernel-size", type=int, default=5,
            help="kernel size for mid-encoder conv (stride=2)",
        )
        # Top conv (before top_conv_layer, stride=1)
        parser.add_argument(
            "--top-conv-kernel-size", type=int, default=5,
            help="kernel size for top-encoder conv (stride=1)",
        )
        # Transformer
        parser.add_argument("--activation-fn", type=str, default="relu")
        parser.add_argument("--dropout", type=float, default=0.1)
        parser.add_argument("--attention-dropout", type=float, default=0.1)
        parser.add_argument("--activation-dropout", type=float, default=0.1)
        parser.add_argument("--encoder-embed-dim", type=int, default=512)
        parser.add_argument("--encoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--encoder-layers", type=int, default=12)
        parser.add_argument("--encoder-attention-heads", type=int, default=8)
        parser.add_argument("--encoder-normalize-before", action="store_true")
        parser.add_argument("--decoder-embed-dim", type=int, default=512)
        parser.add_argument("--decoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--decoder-layers", type=int, default=6)
        parser.add_argument("--decoder-attention-heads", type=int, default=8)
        parser.add_argument("--decoder-normalize-before", action="store_true")
        parser.add_argument("--share-decoder-input-output-embed", action="store_true")
        parser.add_argument("--no-scale-embedding", action="store_true")
        parser.add_argument("--layernorm-embedding", action="store_true")
        parser.add_argument("--encoder-freezing-updates", type=int, default=0)
        # Progressive encoder layer positions
        parser.add_argument(
            "--char-ctc-layer", type=int, default=6,
            help="Encoder layer (1-based) after which to tap char CTC features",
        )
        parser.add_argument(
            "--phone-ctc-layer", type=int, default=9,
            help="Encoder layer (1-based) after which to tap phone CTC features",
        )
        parser.add_argument(
            "--mid-conv-layer", type=int, default=7,
            help="Before which encoder layer to insert mid conv (stride=2)",
        )
        parser.add_argument(
            "--top-conv-layer", type=int, default=10,
            help="Before which encoder layer to insert top conv (stride=1)",
        )
        # CTC loss weights
        parser.add_argument("--char-ctc-weight", type=float, default=0.2)
        parser.add_argument("--phone-ctc-weight", type=float, default=0.3)
        parser.add_argument("--encoder-ctc-weight", type=float, default=0.3)
        parser.add_argument("--decoder-ctc-weight", type=float, default=0.2)
        parser.add_argument(
            "--encoder-only", action="store_true",
            help="encoder-only mode (for ASR), skip decoder computation",
        )
        parser.add_argument(
            "--load-pretrained-encoder-from",
            type=str,
            metavar="STR",
            help="model to take encoder weights from (for initialization)",
        )

    @classmethod
    def build_encoder(cls, args):
        encoder = ProgressiveS2TEncoder(args)
        pretraining_path = getattr(args, "load_pretrained_encoder_from", None)
        if pretraining_path is not None:
            if not Path(pretraining_path).exists():
                logger.warning(
                    f"skipped pretraining because {pretraining_path} does not exist"
                )
            else:
                encoder = checkpoint_utils.load_pretrained_component_from_model(
                    component=encoder, checkpoint=pretraining_path
                )
                logger.info(f"loaded pretrained encoder from: {pretraining_path}")
        return encoder

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        return ProgressiveS2TDecoder(args, tgt_dict, embed_tokens)

    @classmethod
    def build_model(cls, args, task):
        progressive_s2t_base_architecture(args)

        tgt_dict = task.target_dictionary
        args.tgt_dict_size = len(tgt_dict)
        args.char_dict_size = len(task.char_dictionary)
        args.phone_dict_size = len(task.phone_dictionary)

        def build_embedding(dictionary, embed_dim):
            num_embeddings = len(dictionary)
            padding_idx = dictionary.pad()
            return Embedding(num_embeddings, embed_dim, padding_idx)

        decoder_embed_tokens = build_embedding(tgt_dict, args.decoder_embed_dim)

        encoder = cls.build_encoder(args)
        decoder = cls.build_decoder(args, tgt_dict, decoder_embed_tokens)
        return cls(args, encoder, decoder, tgt_dict)

    def _generate_placeholder_tokens(self, encoder_out):
        """Generate placeholder token sequence [BOS, UNK, ..., EOS, PAD, ...].
        
        Each sample's length matches its encoder output length (excluding padding).
        Shorter sequences are padded with PAD token.
        Returns:
            prev_output_tokens: B x T (token ids)
        """
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T or None
        T, B, _ = encoder_out_tensor.shape
        
        # Compute actual lengths per sample
        if encoder_padding_mask is not None:
            lengths = T - encoder_padding_mask.sum(dim=-1).long()  # B
        else:
            lengths = encoder_out_tensor.new_full((B,), T).long()
        
        # Start with all PAD
        placeholder = torch.full((B, T), self.pad, dtype=torch.long, device=encoder_out_tensor.device)
        
        for i in range(B):
            L = lengths[i].item()
            if L >= 2:
                placeholder[i, 0] = self.bos           # first = BOS
                placeholder[i, 1:L-1] = self.unk       # middle = UNK
                placeholder[i, L-1] = self.eos          # last valid = EOS
            elif L == 1:
                placeholder[i, 0] = self.eos            # only one position
        
        return placeholder

    def forward(self, src_tokens, src_lengths, tgt_tokens, **kwargs):
        encoder_out = self.encoder(src_tokens, src_lengths)
        
        # For ASR (encoder-only mode), skip decoder computation
        if self.encoder_only:
            return {
                "encoder_out": encoder_out,
                "decoder_out": None,
            }
        
        # Generate placeholder tokens for decoder input
        prev_output_tokens = self._generate_placeholder_tokens(encoder_out)
        
        decoder_out = self.decoder(
            normalize=False, 
            prev_output_tokens=prev_output_tokens, 
            encoder_out=encoder_out
        )
        return {
            "encoder_out": encoder_out,
            "decoder_out": decoder_out,
        }

    def forward_decoder(self, encoder_out, **kwargs):
        # For ASR (encoder-only mode), skip decoder
        if self.encoder_only:
            return None
        prev_output_tokens = self._generate_placeholder_tokens(encoder_out)
        return self.decoder(
            normalize=True, 
            prev_output_tokens=prev_output_tokens, 
            encoder_out=encoder_out
        )


class ProgressiveConv(nn.Module):
    """Single-layer Conv1d with optional stride, using GLU activation.

    Input / output shape: T x B x C  (time-first)
    """

    def __init__(self, in_channels, out_channels, kernel_size=5, stride=2):
        super().__init__()
        self.stride = stride
        # *2 output channels for GLU
        self.conv = nn.Conv1d(
            in_channels,
            out_channels * 2,
            kernel_size=kernel_size,
            stride=stride,
            padding=kernel_size // 2,
        )

    def get_out_seq_lens(self, in_lens):
        """Compute output sequence lengths given input lengths."""
        if self.stride == 1:
            return in_lens.clone()
        return ((in_lens.float() - 1) / self.stride + 1).floor().long()

    def forward(self, x, src_lengths):
        """
        x          : T x B x C
        src_lengths: B (valid lengths in x)
        returns    : x' (T' x B x C), new_lengths (B)
        """
        # T x B x C  ->  B x C x T
        x = x.permute(1, 2, 0).contiguous()
        x = self.conv(x)          # B x (2C) x T'
        x = F.glu(x, dim=1)      # B x C  x T'
        x = x.permute(2, 0, 1).contiguous()  # T' x B x C
        new_lengths = self.get_out_seq_lens(src_lengths)
        return x, new_lengths


class ProgressiveS2TEncoder(FairseqEncoder):
    """Progressive S2T Encoder with multi-level CTC supervision.

    Subsampling layout (4x total compression):
        Input (80-dim fbank)
          -> subsample (Conv1dSubsampler, 1 layer, stride=2)  [2x]
        Transformer layers 1 .. (mid_conv_layer-1)
          -- char CTC tap at layer char_ctc_layer --
          -> mid_conv (stride=2)                             [2x, total 4x]
        Transformer layers mid_conv_layer .. (top_conv_layer-1)
          -- phone CTC tap at layer phone_ctc_layer --
          -> top_conv (stride=1)                             [no compress]
        Transformer layers top_conv_layer .. encoder_layers
          -- subword CTC at final layer --
    """

    def __init__(self, args):
        super().__init__(None)

        self.encoder_freezing_updates = args.encoder_freezing_updates
        self.num_updates = 0

        self.dropout_module = FairseqDropout(
            p=args.dropout, module_name=self.__class__.__name__
        )
        self.embed_scale = math.sqrt(args.encoder_embed_dim)
        if args.no_scale_embedding:
            self.embed_scale = 1.0
        self.padding_idx = 1  # fairseq convention

        self.char_ctc_layer = args.char_ctc_layer   # default 6
        self.phone_ctc_layer = args.phone_ctc_layer  # default 9
        self.mid_conv_layer = args.mid_conv_layer    # default 7
        self.top_conv_layer = args.top_conv_layer    # default 10

        assert self.char_ctc_layer < self.mid_conv_layer, (
            f"char_ctc_layer ({self.char_ctc_layer}) must be < "
            f"mid_conv_layer ({self.mid_conv_layer})"
        )
        assert self.phone_ctc_layer < self.top_conv_layer, (
            f"phone_ctc_layer ({self.phone_ctc_layer}) must be < "
            f"top_conv_layer ({self.top_conv_layer})"
        )
        assert self.mid_conv_layer <= self.phone_ctc_layer, (
            f"mid_conv_layer ({self.mid_conv_layer}) must be <= "
            f"phone_ctc_layer ({self.phone_ctc_layer})"
        )

        # ---- Initial subsampler: 1 conv layer, stride=2 ----
        self.subsample = Conv1dSubsampler(
            args.input_feat_per_channel * args.input_channels,
            args.conv_channels,
            args.encoder_embed_dim,
            [int(k) for k in args.conv_kernel_sizes.split(",")],
        )

        # ---- Mid conv: stride=2, before layer mid_conv_layer ----
        self.mid_conv = ProgressiveConv(
            in_channels=args.encoder_embed_dim,
            out_channels=args.encoder_embed_dim,
            kernel_size=args.mid_conv_kernel_size,
            stride=2,
        )

        # ---- Top conv: stride=2, before layer top_conv_layer ----
        self.top_conv = ProgressiveConv(
            in_channels=args.encoder_embed_dim,
            out_channels=args.encoder_embed_dim,
            kernel_size=args.top_conv_kernel_size,
            stride=2,
        )

        # Positional embedding (shared, reused after each conv)
        self.embed_positions = PositionalEmbedding(
            args.max_source_positions, args.encoder_embed_dim, self.padding_idx
        )

        # Transformer layers
        self.transformer_layers = nn.ModuleList(
            [TransformerEncoderLayer(args) for _ in range(args.encoder_layers)]
        )

        # Final layer norm (pre-norm style)
        if args.encoder_normalize_before:
            self.layer_norm = LayerNorm(args.encoder_embed_dim)
        else:
            self.layer_norm = None

        # Layer norms before CTC taps
        self.layer_norm_char = LayerNorm(args.encoder_embed_dim)
        self.layer_norm_phone = LayerNorm(args.encoder_embed_dim)

        # CTC projection heads
        self.char_ctc_proj = nn.Linear(args.encoder_embed_dim, args.char_dict_size)
        self.phone_ctc_proj = nn.Linear(args.encoder_embed_dim, args.phone_dict_size)
        self.ctc_proj = nn.Linear(args.encoder_embed_dim, args.tgt_dict_size)

    def _add_positions(self, x, padding_mask):
        """Add positional embeddings to x (T x B x C)."""
        pos = self.embed_positions(padding_mask).transpose(0, 1)  # T x B x C
        return x + pos

    def _forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        # ---- Initial subsampling (stride=2) ----
        x, input_lengths = self.subsample(src_tokens, src_lengths)  # T/2 x B x C
        x = self.embed_scale * x

        encoder_padding_mask = lengths_to_padding_mask(input_lengths)
        x = self._add_positions(x, encoder_padding_mask)
        x = self.dropout_module(x)

        encoder_states = []
        char_state = None
        char_padding_mask = None
        phone_state = None
        phone_padding_mask = None

        for idx, layer in enumerate(self.transformer_layers):
            layer_num = idx + 1  # 1-based layer index

            # ---- Insert mid_conv BEFORE layer mid_conv_layer ----
            if layer_num == self.mid_conv_layer:
                x, input_lengths = self.mid_conv(x, input_lengths)
                encoder_padding_mask = lengths_to_padding_mask(input_lengths)
                x = self._add_positions(x, encoder_padding_mask)

            # ---- Insert top_conv BEFORE layer top_conv_layer ----
            if layer_num == self.top_conv_layer:
                x, input_lengths = self.top_conv(x, input_lengths)
                encoder_padding_mask = lengths_to_padding_mask(input_lengths)
                x = self._add_positions(x, encoder_padding_mask)

            # ---- Transformer layer ----
            x = layer(x, encoder_padding_mask)

            if return_all_hiddens:
                encoder_states.append(x)

            # ---- Tap char CTC AFTER layer char_ctc_layer ----
            if layer_num == self.char_ctc_layer:
                char_state = self.layer_norm_char(x)
                char_padding_mask = encoder_padding_mask

            # ---- Tap phone CTC AFTER layer phone_ctc_layer ----
            if layer_num == self.phone_ctc_layer:
                phone_state = self.layer_norm_phone(x)
                phone_padding_mask = encoder_padding_mask

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        return {
            "encoder_out": x,                         # T x B x C (final)
            "encoder_padding_mask": encoder_padding_mask,   # B x T
            "char_state": char_state,                 # T_c x B x C
            "char_padding_mask": char_padding_mask,   # B x T_c
            "phone_state": phone_state,               # T_p x B x C
            "phone_padding_mask": phone_padding_mask, # B x T_p
            "encoder_embedding": None,
            "encoder_states": encoder_states,
            "src_tokens": [],
            "src_lengths": input_lengths,
        }

    def forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        if self.num_updates < self.encoder_freezing_updates:
            with torch.no_grad():
                return self._forward(src_tokens, src_lengths, return_all_hiddens)
        return self._forward(src_tokens, src_lengths, return_all_hiddens)

    # ---- Helpers for CTC loss computation ----

    def _state_lengths(self, state, padding_mask):
        T, B, _ = state.shape
        lens = state.new_full((B,), T).long()
        if padding_mask is not None:
            lens = lens - padding_mask.sum(dim=-1).long()
        return lens

    def get_ctc_logits(self, encoder_out):
        """Subword CTC logits from final encoder output. T x B x V"""
        return self.ctc_proj(encoder_out["encoder_out"])

    def get_ctc_input_lengths(self, encoder_out):
        return self._state_lengths(
            encoder_out["encoder_out"], encoder_out["encoder_padding_mask"]
        )

    def get_char_ctc_logits(self, encoder_out):
        """Char CTC logits. T_c x B x V_c"""
        return self.char_ctc_proj(encoder_out["char_state"])

    def get_char_ctc_input_lengths(self, encoder_out):
        return self._state_lengths(
            encoder_out["char_state"], encoder_out["char_padding_mask"]
        )

    def get_phone_ctc_logits(self, encoder_out):
        """Phone CTC logits. T_p x B x V_p"""
        return self.phone_ctc_proj(encoder_out["phone_state"])

    def get_phone_ctc_input_lengths(self, encoder_out):
        return self._state_lengths(
            encoder_out["phone_state"], encoder_out["phone_padding_mask"]
        )

    def reorder_encoder_out(self, encoder_out, new_order):
        def _sel(t, dim=1):
            return t.index_select(dim, new_order) if t is not None else None

        return {
            "encoder_out": _sel(encoder_out["encoder_out"], 1),
            "encoder_padding_mask": _sel(encoder_out["encoder_padding_mask"], 0),
            "char_state": _sel(encoder_out["char_state"], 1),
            "char_padding_mask": _sel(encoder_out["char_padding_mask"], 0),
            "phone_state": _sel(encoder_out["phone_state"], 1),
            "phone_padding_mask": _sel(encoder_out["phone_padding_mask"], 0),
            "encoder_embedding": None,
            "encoder_states": [],
            "src_tokens": [],
            "src_lengths": _sel(encoder_out["src_lengths"], 0),
        }

    def set_num_updates(self, num_updates):
        super().set_num_updates(num_updates)
        self.num_updates = num_updates


class ProgressiveS2TDecoder(nn.Module):
    """NAT Decoder with self-attention and cross-attention.
    
    Input: placeholder sequence [BOS, UNK, UNK, ..., EOS] with same length as encoder output.
    Cross-attention attends to encoder output.
    Decoder CTC targets: tgt_text (German for ST, English for ASR).
    """

    def __init__(self, args, dictionary, embed_tokens):
        super().__init__()
        self.dictionary = dictionary
        self.pad = dictionary.pad()
        self.bos = dictionary.bos()
        self.eos = dictionary.eos()
        self.unk = dictionary.unk()
        self.embed_dim = args.decoder_embed_dim

        self.dropout_module = FairseqDropout(
            p=args.dropout, module_name=self.__class__.__name__
        )

        # Token embeddings for placeholder tokens
        self.embed_tokens = embed_tokens
        self.embed_scale = math.sqrt(self.embed_dim) if not getattr(args, "no_scale_embedding", False) else 1.0

        # Positional embeddings
        self.embed_positions = PositionalEmbedding(
            args.max_target_positions, self.embed_dim, self.pad
        )

        # Decoder layers with cross-attention (no_encoder_attn=False)
        self.layers = nn.ModuleList([
            TransformerDecoderLayer(args, no_encoder_attn=False)
            for _ in range(args.decoder_layers)
        ])

        if args.decoder_normalize_before:
            self.layer_norm = LayerNorm(self.embed_dim)
        else:
            self.layer_norm = None

        self.output_projection = nn.Linear(self.embed_dim, len(dictionary), bias=False)

    def forward_embedding(self, prev_output_tokens):
        """Embed placeholder tokens and add positional embeddings.
        
        Args:
            prev_output_tokens: B x T (token ids)
            
        Returns:
            x: T x B x C (embedded tokens)
            decoder_padding_mask: B x T
        """
        # Token embeddings
        x = self.embed_scale * self.embed_tokens(prev_output_tokens)

        # Positional embeddings
        positions = self.embed_positions(prev_output_tokens)
        x = x + positions
        x = self.dropout_module(x)

        # Padding mask
        decoder_padding_mask = prev_output_tokens.eq(self.pad)

        # T x B x C
        x = x.transpose(0, 1)

        return x, decoder_padding_mask

    def forward(self, normalize, prev_output_tokens, encoder_out, **unused):
        """
        Args:
            normalize: if True, return log-softmax; else raw logits
            prev_output_tokens: B x T (placeholder tokens [BOS, UNK, ..., EOS])
            encoder_out: dict with "encoder_out" (T x B x C)
                         and "encoder_padding_mask" (B x T)
        Returns:
            T x B x V
        """
        # Embed placeholder tokens
        x, decoder_padding_mask = self.forward_embedding(prev_output_tokens)

        # Encoder output for cross-attention
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T

        # Decoder layers with self-attention + cross-attention
        for layer in self.layers:
            x, _, _ = layer(
                x,
                encoder_out=encoder_out_tensor,
                encoder_padding_mask=encoder_padding_mask,
                self_attn_mask=None,
                self_attn_padding_mask=decoder_padding_mask,
            )

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        x = self.output_projection(x)  # T x B x V
        return F.log_softmax(x, dim=-1) if normalize else x

    def get_ctc_logits(self, encoder_out):
        """Decoder CTC logits (raw). T x B x V
        
        Generates placeholder tokens internally.
        """
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T or None
        T, B, _ = encoder_out_tensor.shape

        # Compute actual lengths per sample
        if encoder_padding_mask is not None:
            lengths = T - encoder_padding_mask.sum(dim=-1).long()  # B
        else:
            lengths = encoder_out_tensor.new_full((B,), T).long()

        # Generate placeholder tokens with proper padding
        placeholder = torch.full((B, T), self.pad, dtype=torch.long, device=encoder_out_tensor.device)
        for i in range(B):
            L = lengths[i].item()
            if L >= 2:
                placeholder[i, 0] = self.bos
                placeholder[i, 1:L-1] = self.unk
                placeholder[i, L-1] = self.eos
            elif L == 1:
                placeholder[i, 0] = self.eos

        return self.forward(
            normalize=False, 
            prev_output_tokens=placeholder, 
            encoder_out=encoder_out
        )

    def get_ctc_input_lengths(self, encoder_out):
        enc_out = encoder_out["encoder_out"]  # T x B x C
        lens = enc_out.new_full((enc_out.shape[1],), enc_out.shape[0]).long()
        if encoder_out["encoder_padding_mask"] is not None:
            lens = lens - encoder_out["encoder_padding_mask"].sum(dim=-1).long()
        return lens


# ---------------------------------------------------------------------------
# Architectures
# ---------------------------------------------------------------------------

@register_model_architecture("progressive_s2t_transformer", "progressive_s2t_transformer")
def progressive_s2t_base_architecture(args):
    args.encoder_freezing_updates = getattr(args, "encoder_freezing_updates", 0)
    # Input
    args.input_channels = getattr(args, "input_channels", 1)
    args.input_feat_per_channel = getattr(args, "input_feat_per_channel", 80)
    # Conv
    args.conv_kernel_sizes = getattr(args, "conv_kernel_sizes", "5")
    args.conv_channels = getattr(args, "conv_channels", 1024)
    args.mid_conv_kernel_size = getattr(args, "mid_conv_kernel_size", 5)
    args.top_conv_kernel_size = getattr(args, "top_conv_kernel_size", 5)
    # Progressive layer positions
    args.char_ctc_layer = getattr(args, "char_ctc_layer", 6)
    args.phone_ctc_layer = getattr(args, "phone_ctc_layer", 9)
    args.mid_conv_layer = getattr(args, "mid_conv_layer", 7)
    args.top_conv_layer = getattr(args, "top_conv_layer", 10)
    # Encoder Transformer
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 12)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", True)
    # Decoder Transformer
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", True)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    # Common
    args.dropout = getattr(args, "dropout", 0.1)
    args.attention_dropout = getattr(args, "attention_dropout", args.dropout)
    args.activation_dropout = getattr(args, "activation_dropout", args.dropout)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0.0)
    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)
    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.max_source_positions = getattr(args, "max_source_positions", 6000)
    args.max_target_positions = getattr(args, "max_target_positions", 1024)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    # CTC weights
    args.char_ctc_weight = getattr(args, "char_ctc_weight", 0.2)
    args.phone_ctc_weight = getattr(args, "phone_ctc_weight", 0.3)
    args.encoder_ctc_weight = getattr(args, "encoder_ctc_weight", 0.3)
    args.decoder_ctc_weight = getattr(args, "decoder_ctc_weight", 0.2)


@register_model_architecture("progressive_s2t_transformer", "progressive_s2t_transformer_m")
def progressive_s2t_transformer_m(args):
    """Medium config (512-dim, 4x FFN)."""
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", 512)
    args.decoder_ffn_embed_dim = getattr(args, "decoder_ffn_embed_dim", 2048)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.dropout = getattr(args, "dropout", 0.15)
    progressive_s2t_base_architecture(args)
