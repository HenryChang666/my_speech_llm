# Copyright (c) Facebook, Inc. and its affiliates.
# Pure CTC-based Non-autoregressive Speech-to-Text model.
# No length prediction, no CE loss. Only CTC loss on encoder and decoder.

import logging
import math
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from fairseq import utils, checkpoint_utils
from fairseq.data.data_utils import lengths_to_padding_mask
from fairseq.models import (
    FairseqEncoder,
    BaseFairseqModel,
    register_model,
    register_model_architecture,
)
from fairseq.models.speech_to_text.modules.convolution import Conv1dSubsampler
from fairseq.models.transformer import Embedding
from fairseq.modules import (
    FairseqDropout,
    LayerNorm,
    PositionalEmbedding,
    TransformerEncoderLayer,
    TransformerDecoderLayer,
)
from fairseq.iterative_refinement_generator import DecoderOut

logger = logging.getLogger(__name__)


@register_model("nat_s2t_ctc_transformer")
class NATS2TCTCTransformerModel(BaseFairseqModel):
    """Pure CTC-based NAT S2T: S2T Encoder + Decoder (with cross-attn) + Dual CTC.
    
    Architecture:
    - Encoder: Conv subsampler + Transformer + Upsampler (upsample_ratio=1)
    - Decoder: Self-attention + Cross-attention, takes placeholder [BOS,UNK,...,EOS] as input
    - Cross-attention attends to encoder output
    - Loss: CTC on encoder output + CTC on decoder output
    """

    def __init__(self, args, encoder, decoder, tgt_dict):
        super().__init__()
        self.args = args
        self.encoder = encoder
        self.decoder = decoder
        self.tgt_dict = tgt_dict
        self.bos = tgt_dict.bos()
        self.eos = tgt_dict.eos()
        self.unk = tgt_dict.unk()
        self.pad = tgt_dict.pad()
        self.blank_idx = 0  # CTC blank
        # Check if ASR mode (encoder-only)
        self.encoder_only = getattr(args, "encoder_only", False)

    @staticmethod
    def add_args(parser):
        # Convolutional subsampler
        parser.add_argument(
            "--conv-kernel-sizes", type=str, default="5,5",
            help="kernel sizes of Conv1d subsampling layers",
        )
        parser.add_argument(
            "--conv-channels", type=int, default=1024,
            help="# of channels in Conv1d subsampling layers",
        )
        # Transformer
        parser.add_argument("--activation-fn", type=str, default="relu")
        parser.add_argument("--dropout", type=float, default=0.1)
        parser.add_argument("--attention-dropout", type=float, default=0.1)
        parser.add_argument("--activation-dropout", type=float, default=0.1)
        parser.add_argument("--encoder-embed-dim", type=int, default=512)
        parser.add_argument("--encoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--encoder-layers", type=int, default=12)
        parser.add_argument("--encoder-attention-heads", type=int, default=8)
        parser.add_argument("--encoder-normalize-before", action="store_true")
        parser.add_argument("--decoder-embed-dim", type=int, default=512)
        parser.add_argument("--decoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--decoder-layers", type=int, default=6)
        parser.add_argument("--decoder-attention-heads", type=int, default=8)
        parser.add_argument("--decoder-normalize-before", action="store_true")
        parser.add_argument("--share-decoder-input-output-embed", action="store_true")
        parser.add_argument("--no-scale-embedding", action="store_true")
        parser.add_argument("--layernorm-embedding", action="store_true")
        parser.add_argument("--encoder-freezing-updates", type=int, default=0)
        # Upsampler
        parser.add_argument(
            "--upsample-ratio", type=int, default=1,
            help="upsampling ratio for encoder output (1 means no upsampling)",
        )
        # CTC
        parser.add_argument(
            "--encoder-ctc-weight", type=float, default=0.5,
            help="weight for encoder CTC loss",
        )
        parser.add_argument(
            "--decoder-ctc-weight", type=float, default=0.5,
            help="weight for decoder CTC loss",
        )
        parser.add_argument(
            "--encoder-only", action="store_true",
            help="encoder-only mode (for ASR), skip decoder computation",
        )
        parser.add_argument(
            "--load-pretrained-encoder-from",
            type=str,
            metavar="STR",
            help="model to take encoder weights from (for initialization)",
        )

    @classmethod
    def build_encoder(cls, args):
        encoder = NATS2TCTCEncoder(args)
        pretraining_path = getattr(args, "load_pretrained_encoder_from", None)
        if pretraining_path is not None:
            if not Path(pretraining_path).exists():
                logger.warning(
                    f"skipped pretraining because {pretraining_path} does not exist"
                )
            else:
                encoder = checkpoint_utils.load_pretrained_component_from_model(
                    component=encoder, checkpoint=pretraining_path
                )
                logger.info(f"loaded pretrained encoder from: {pretraining_path}")
        return encoder

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        return NATS2TCTCDecoder(args, tgt_dict, embed_tokens)

    @classmethod
    def build_model(cls, args, task):
        nat_s2t_ctc_base_architecture(args)

        def build_embedding(dictionary, embed_dim):
            num_embeddings = len(dictionary)
            padding_idx = dictionary.pad()
            return Embedding(num_embeddings, embed_dim, padding_idx)

        tgt_dict = task.target_dictionary
        decoder_embed_tokens = build_embedding(tgt_dict, args.decoder_embed_dim)
        args.tgt_dict_size = len(tgt_dict)
        encoder = cls.build_encoder(args)
        decoder = cls.build_decoder(args, tgt_dict, decoder_embed_tokens)
        return cls(args, encoder, decoder, tgt_dict)

    def _generate_placeholder_tokens(self, encoder_out):
        """Generate placeholder token sequence [BOS, UNK, ..., EOS, PAD, ...].
        
        Each sample's length matches its encoder output length (excluding padding).
        Shorter sequences are padded with PAD token.
        Returns:
            prev_output_tokens: B x T (token ids)
        """
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T or None
        T, B, _ = encoder_out_tensor.shape
        
        # Compute actual lengths per sample
        if encoder_padding_mask is not None:
            lengths = T - encoder_padding_mask.sum(dim=-1).long()  # B
        else:
            lengths = encoder_out_tensor.new_full((B,), T).long()
        
        # Start with all PAD
        placeholder = torch.full((B, T), self.pad, dtype=torch.long, device=encoder_out_tensor.device)
        
        for i in range(B):
            L = lengths[i].item()
            if L >= 2:
                placeholder[i, 0] = self.bos           # first = BOS
                placeholder[i, 1:L-1] = self.unk       # middle = UNK
                placeholder[i, L-1] = self.eos          # last valid = EOS
            elif L == 1:
                placeholder[i, 0] = self.eos            # only one position
        
        return placeholder

    def forward(self, src_tokens, src_lengths, tgt_tokens, **kwargs):
        """Forward pass for training.
        
        Returns dict with encoder_out and decoder_out for CTC loss computation.
        """
        # Encoding
        encoder_out = self.encoder(src_tokens, src_lengths)
        
        # For ASR (encoder-only mode), skip decoder computation
        if self.encoder_only:
            return {
                "encoder_out": encoder_out,
                "decoder_out": None,
            }
        
        # Generate placeholder tokens for decoder input
        prev_output_tokens = self._generate_placeholder_tokens(encoder_out)
        
        # Decoding with cross-attention
        decoder_out = self.decoder(
            normalize=False,
            prev_output_tokens=prev_output_tokens,
            encoder_out=encoder_out,
        )
        
        return {
            "encoder_out": encoder_out,
            "decoder_out": decoder_out,
        }

    def forward_decoder(self, encoder_out, **kwargs):
        """Forward decoder for inference."""
        # For ASR (encoder-only mode), skip decoder
        if self.encoder_only:
            return None
        prev_output_tokens = self._generate_placeholder_tokens(encoder_out)
        decoder_out = self.decoder(
            normalize=True,
            prev_output_tokens=prev_output_tokens,
            encoder_out=encoder_out,
        )
        return decoder_out


class NATS2TCTCEncoder(FairseqEncoder):
    """S2T Transformer Encoder with Conv subsampling + Upsampler + CTC projection."""

    def __init__(self, args):
        super().__init__(None)

        self.encoder_freezing_updates = args.encoder_freezing_updates
        self.num_updates = 0

        self.dropout_module = FairseqDropout(
            p=args.dropout, module_name=self.__class__.__name__
        )
        self.embed_scale = math.sqrt(args.encoder_embed_dim)
        if args.no_scale_embedding:
            self.embed_scale = 1.0
        self.padding_idx = 1

        # 2 layers of 1D conv with stride=2 each => 4x compression
        self.subsample = Conv1dSubsampler(
            args.input_feat_per_channel * args.input_channels,
            args.conv_channels,
            args.encoder_embed_dim,
            [int(k) for k in args.conv_kernel_sizes.split(",")],
        )

        self.embed_positions = PositionalEmbedding(
            args.max_source_positions, args.encoder_embed_dim, self.padding_idx
        )

        self.transformer_layers = nn.ModuleList(
            [TransformerEncoderLayer(args) for _ in range(args.encoder_layers)]
        )
        if args.encoder_normalize_before:
            self.layer_norm = LayerNorm(args.encoder_embed_dim)
        else:
            self.layer_norm = None

        # Upsampler (upsample_ratio=1 means just a projection)
        self.upsample_ratio = args.upsample_ratio
        if args.upsample_ratio > 1:
            self.upsampler = nn.Linear(
                args.encoder_embed_dim, 
                args.encoder_embed_dim * args.upsample_ratio
            )
        else:
            self.upsampler = None

        # Encoder CTC projection head
        self.ctc_proj = nn.Linear(args.encoder_embed_dim, args.tgt_dict_size)

    def _forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        x, input_lengths = self.subsample(src_tokens, src_lengths)
        x = self.embed_scale * x

        encoder_padding_mask = lengths_to_padding_mask(input_lengths)
        positions = self.embed_positions(encoder_padding_mask).transpose(0, 1)
        x += positions
        x = self.dropout_module(x)

        encoder_states = []
        for layer in self.transformer_layers:
            x = layer(x, encoder_padding_mask)
            if return_all_hiddens:
                encoder_states.append(x)

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        # Upsample if needed
        if self.upsampler is not None:
            # x: T x B x C
            x = x.transpose(0, 1)  # B x T x C
            x = self.upsampler(x)  # B x T x (C * ratio)
            x = x.reshape(x.size(0), -1, x.size(-1) // self.upsample_ratio)  # B x (T*ratio) x C
            x = x.transpose(0, 1)  # (T*ratio) x B x C
            
            # Expand padding mask
            encoder_padding_mask = encoder_padding_mask.unsqueeze(-1).expand(-1, -1, self.upsample_ratio)
            encoder_padding_mask = encoder_padding_mask.reshape(encoder_padding_mask.size(0), -1)

        return {
            "encoder_out": x,  # T x B x C
            "encoder_padding_mask": encoder_padding_mask,  # B x T
            "encoder_embedding": None,
            "encoder_states": encoder_states,
            "src_tokens": [],
            "src_lengths": input_lengths,
        }

    def forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        if self.num_updates < self.encoder_freezing_updates:
            with torch.no_grad():
                x = self._forward(src_tokens, src_lengths, return_all_hiddens)
        else:
            x = self._forward(src_tokens, src_lengths, return_all_hiddens)
        return x

    def get_ctc_logits(self, encoder_out):
        """Get CTC logits from encoder output. Returns T x B x V."""
        enc_out = encoder_out["encoder_out"]  # T x B x C
        return self.ctc_proj(enc_out)

    def get_ctc_input_lengths(self, encoder_out):
        """Get encoder output lengths for CTC."""
        enc_out = encoder_out["encoder_out"]  # T x B x C
        lens = enc_out.new_full((enc_out.shape[1],), enc_out.shape[0]).long()
        if encoder_out["encoder_padding_mask"] is not None:
            lens -= encoder_out["encoder_padding_mask"].sum(dim=-1)
        return lens

    def reorder_encoder_out(self, encoder_out, new_order):
        new_encoder_out = encoder_out["encoder_out"].index_select(1, new_order)
        new_encoder_padding_mask = encoder_out["encoder_padding_mask"].index_select(0, new_order)
        new_src_lengths = encoder_out["src_lengths"].index_select(0, new_order)

        return {
            "encoder_out": new_encoder_out,
            "encoder_padding_mask": new_encoder_padding_mask,
            "encoder_embedding": None,
            "encoder_states": [],
            "src_tokens": [],
            "src_lengths": new_src_lengths,
        }

    def set_num_updates(self, num_updates):
        super().set_num_updates(num_updates)
        self.num_updates = num_updates


class NATS2TCTCDecoder(nn.Module):
    """NAT Decoder with self-attention and cross-attention.
    
    Input: placeholder sequence [BOS, UNK, UNK, ..., EOS] with same length as encoder output.
    Cross-attention attends to encoder output.
    Decoder CTC targets: tgt_text.
    """

    def __init__(self, args, dictionary, embed_tokens):
        super().__init__()
        self.dictionary = dictionary
        self.bos = dictionary.bos()
        self.unk = dictionary.unk()
        self.eos = dictionary.eos()
        self.pad = dictionary.pad()
        
        self.dropout_module = FairseqDropout(
            p=args.dropout, module_name=self.__class__.__name__
        )
        
        self.embed_dim = args.decoder_embed_dim
        self.embed_scale = math.sqrt(self.embed_dim) if not getattr(args, "no_scale_embedding", False) else 1.0
        
        # Token embeddings for placeholder tokens
        self.embed_tokens = embed_tokens
        
        # Positional embeddings
        self.embed_positions = PositionalEmbedding(
            args.max_target_positions, self.embed_dim, self.pad
        )
        
        # Decoder layers with cross-attention (no_encoder_attn=False)
        self.layers = nn.ModuleList([
            TransformerDecoderLayer(args, no_encoder_attn=False)
            for _ in range(args.decoder_layers)
        ])
        
        if args.decoder_normalize_before:
            self.layer_norm = LayerNorm(self.embed_dim)
        else:
            self.layer_norm = None
        
        # Output projection to vocabulary
        self.output_projection = nn.Linear(
            self.embed_dim, len(dictionary), bias=False
        )
        
        # Decoder CTC projection (same as output_projection for CTC)
        self.ctc_proj = self.output_projection

    def forward_embedding(self, prev_output_tokens):
        """Embed placeholder tokens and add positional embeddings.
        
        Args:
            prev_output_tokens: B x T (token ids)
            
        Returns:
            x: T x B x C (embedded tokens)
            decoder_padding_mask: B x T
        """
        # Token embeddings
        x = self.embed_scale * self.embed_tokens(prev_output_tokens)
        
        # Positional embeddings
        positions = self.embed_positions(prev_output_tokens)
        x = x + positions
        x = self.dropout_module(x)
        
        # Padding mask
        decoder_padding_mask = prev_output_tokens.eq(self.pad)
        
        # T x B x C
        x = x.transpose(0, 1)
        
        return x, decoder_padding_mask

    def forward(self, normalize, prev_output_tokens, encoder_out, **unused):
        """Forward decoder.
        
        Args:
            prev_output_tokens: B x T (placeholder tokens [BOS, UNK, ..., EOS])
            encoder_out: dict with "encoder_out" (T x B x C) and "encoder_padding_mask" (B x T)
            
        Returns:
            decoder output logits (T x B x V)
        """
        # Embed placeholder tokens
        x, decoder_padding_mask = self.forward_embedding(prev_output_tokens)
        
        # Encoder output for cross-attention
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T
        
        # Apply decoder layers with self-attention + cross-attention
        for layer in self.layers:
            x, _, _ = layer(
                x,
                encoder_out=encoder_out_tensor,
                encoder_padding_mask=encoder_padding_mask,
                self_attn_mask=None,
                self_attn_padding_mask=decoder_padding_mask,
            )
        
        if self.layer_norm is not None:
            x = self.layer_norm(x)
        
        # Project to vocabulary
        x = self.output_projection(x)  # T x B x V
        
        return F.log_softmax(x, -1) if normalize else x

    def get_ctc_logits(self, encoder_out):
        """Get decoder CTC logits. Returns T x B x V.
        
        Generates placeholder tokens internally.
        """
        encoder_out_tensor = encoder_out["encoder_out"]  # T x B x C
        encoder_padding_mask = encoder_out["encoder_padding_mask"]  # B x T or None
        T, B, _ = encoder_out_tensor.shape
        
        # Compute actual lengths per sample
        if encoder_padding_mask is not None:
            lengths = T - encoder_padding_mask.sum(dim=-1).long()  # B
        else:
            lengths = encoder_out_tensor.new_full((B,), T).long()
        
        # Generate placeholder tokens with proper padding
        placeholder = torch.full((B, T), self.pad, dtype=torch.long, device=encoder_out_tensor.device)
        for i in range(B):
            L = lengths[i].item()
            if L >= 2:
                placeholder[i, 0] = self.bos
                placeholder[i, 1:L-1] = self.unk
                placeholder[i, L-1] = self.eos
            elif L == 1:
                placeholder[i, 0] = self.eos
        
        dec_out = self.forward(
            normalize=False, 
            prev_output_tokens=placeholder, 
            encoder_out=encoder_out
        )
        return dec_out

    def get_ctc_input_lengths(self, encoder_out):
        """Get decoder output lengths for CTC."""
        enc_out = encoder_out["encoder_out"]  # T x B x C
        lens = enc_out.new_full((enc_out.shape[1],), enc_out.shape[0]).long()
        if encoder_out["encoder_padding_mask"] is not None:
            lens -= encoder_out["encoder_padding_mask"].sum(dim=-1)
        return lens


@register_model_architecture("nat_s2t_ctc_transformer", "nat_s2t_ctc_transformer")
def nat_s2t_ctc_base_architecture(args):
    args.encoder_freezing_updates = getattr(args, "encoder_freezing_updates", 0)
    # Convolutional subsampler
    args.input_channels = getattr(args, "input_channels", 1)
    args.input_feat_per_channel = getattr(args, "input_feat_per_channel", 80)
    args.conv_kernel_sizes = getattr(args, "conv_kernel_sizes", "5,5")
    args.conv_channels = getattr(args, "conv_channels", 1024)
    # Transformer
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 12)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", True)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", True)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.dropout = getattr(args, "dropout", 0.1)
    args.attention_dropout = getattr(args, "attention_dropout", args.dropout)
    args.activation_dropout = getattr(args, "activation_dropout", args.dropout)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0.0)
    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)
    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.max_source_positions = getattr(args, "max_source_positions", 6000)
    args.max_target_positions = getattr(args, "max_target_positions", 1024)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    # Upsampler
    args.upsample_ratio = getattr(args, "upsample_ratio", 1)
    # CTC
    args.encoder_ctc_weight = getattr(args, "encoder_ctc_weight", 0.5)
    args.decoder_ctc_weight = getattr(args, "decoder_ctc_weight", 0.5)


@register_model_architecture("nat_s2t_ctc_transformer", "nat_s2t_ctc_transformer_m")
def nat_s2t_ctc_transformer_m(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 512 * 4)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.dropout = getattr(args, "dropout", 0.15)
    nat_s2t_ctc_base_architecture(args)


@register_model_architecture("nat_s2t_ctc_transformer", "nat_s2t_ctc_transformer_s")
def nat_s2t_ctc_transformer_s(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 256)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 256 * 8)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 4)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 4)
    args.dropout = getattr(args, "dropout", 0.1)
    nat_s2t_ctc_base_architecture(args)


@register_model_architecture("nat_s2t_ctc_transformer", "nat_s2t_ctc_transformer_l")
def nat_s2t_ctc_transformer_l(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 1024)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 1024 * 4)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 16)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 16)
    args.dropout = getattr(args, "dropout", 0.2)
    nat_s2t_ctc_base_architecture(args)
