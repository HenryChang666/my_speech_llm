# Copyright (c) Facebook, Inc. and its affiliates.
# Non-autoregressive Speech-to-Text model with dual CTC.

import logging
import math
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from fairseq import utils
from fairseq.data.data_utils import lengths_to_padding_mask
from fairseq.models import (
    FairseqEncoder,
    FairseqEncoderDecoderModel,
    register_model,
    register_model_architecture,
)
from fairseq.models.speech_to_text.modules.convolution import Conv1dSubsampler
from fairseq.models.transformer import Embedding, TransformerDecoder
from fairseq.modules import (
    FairseqDropout,
    LayerNorm,
    PositionalEmbedding,
    TransformerEncoderLayer,
)
from fairseq.iterative_refinement_generator import DecoderOut

logger = logging.getLogger(__name__)


def _uniform_assignment(src_lens, trg_lens):
    max_trg_len = trg_lens.max()
    steps = (src_lens.float() - 1) / (trg_lens.float() - 1 + 1e-6)
    index_t = utils.new_arange(trg_lens, max_trg_len).float()
    index_t = steps[:, None] * index_t[None, :]
    index_t = torch.round(index_t).long().detach()
    return index_t


def _mean_pooling(enc_feats, src_masks):
    # enc_feats: T x B x C, src_masks: B x T or None
    if src_masks is None:
        enc_feats = enc_feats.mean(0)
    else:
        src_masks = (~src_masks).transpose(0, 1).type_as(enc_feats)
        enc_feats = (
            (enc_feats / src_masks.sum(0)[None, :, None]) * src_masks[:, :, None]
        ).sum(0)
    return enc_feats


@register_model("nat_s2t_transformer")
class NATS2TTransformerModel(FairseqEncoderDecoderModel):
    """S2T Encoder + NAT Decoder with dual CTC (encoder CTC + decoder CTC)."""

    def __init__(self, encoder, decoder):
        super().__init__(encoder, decoder)
        self.tgt_dict = decoder.dictionary
        self.bos = decoder.dictionary.bos()
        self.eos = decoder.dictionary.eos()
        self.pad = decoder.dictionary.pad()
        self.unk = decoder.dictionary.unk()

    @staticmethod
    def add_args(parser):
        # Convolutional subsampler
        parser.add_argument(
            "--conv-kernel-sizes", type=str, default="5,5",
            help="kernel sizes of Conv1d subsampling layers",
        )
        parser.add_argument(
            "--conv-channels", type=int, default=1024,
            help="# of channels in Conv1d subsampling layers",
        )
        # Transformer
        parser.add_argument("--activation-fn", type=str, default="relu")
        parser.add_argument("--dropout", type=float, default=0.1)
        parser.add_argument("--attention-dropout", type=float, default=0.1)
        parser.add_argument("--activation-dropout", type=float, default=0.1)
        parser.add_argument("--encoder-embed-dim", type=int, default=512)
        parser.add_argument("--encoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--encoder-layers", type=int, default=12)
        parser.add_argument("--encoder-attention-heads", type=int, default=8)
        parser.add_argument("--encoder-normalize-before", action="store_true")
        parser.add_argument("--decoder-embed-dim", type=int, default=512)
        parser.add_argument("--decoder-ffn-embed-dim", type=int, default=2048)
        parser.add_argument("--decoder-layers", type=int, default=6)
        parser.add_argument("--decoder-attention-heads", type=int, default=8)
        parser.add_argument("--decoder-normalize-before", action="store_true")
        parser.add_argument("--share-decoder-input-output-embed", action="store_true")
        parser.add_argument("--no-scale-embedding", action="store_true")
        parser.add_argument("--layernorm-embedding", action="store_true")
        parser.add_argument("--encoder-freezing-updates", type=int, default=0)
        # NAT specific
        parser.add_argument(
            "--sg-length-pred", action="store_true",
            help="stop gradients from length predictor",
        )
        parser.add_argument(
            "--pred-length-offset", action="store_true",
            help="predict length difference between target and source",
        )
        parser.add_argument(
            "--length-loss-factor", type=float, default=0.1,
            help="weight for length prediction loss",
        )
        # CTC
        parser.add_argument(
            "--encoder-ctc-weight", type=float, default=0.3,
            help="weight for encoder CTC loss",
        )
        parser.add_argument(
            "--decoder-ctc-weight", type=float, default=0.3,
            help="weight for decoder CTC loss",
        )

    @classmethod
    def build_encoder(cls, args):
        return NATS2TEncoder(args)

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        return NATS2TDecoder(args, tgt_dict, embed_tokens)

    @classmethod
    def build_model(cls, args, task):
        nat_s2t_base_architecture(args)

        def build_embedding(dictionary, embed_dim):
            num_embeddings = len(dictionary)
            padding_idx = dictionary.pad()
            return Embedding(num_embeddings, embed_dim, padding_idx)

        tgt_dict = task.target_dictionary
        decoder_embed_tokens = build_embedding(tgt_dict, args.decoder_embed_dim)
        args.tgt_dict_size = len(tgt_dict)
        encoder = cls.build_encoder(args)
        decoder = cls.build_decoder(args, tgt_dict, decoder_embed_tokens)
        return cls(encoder, decoder)

    def get_normalized_probs(self, net_output, log_probs, sample=None):
        lprobs = self.get_normalized_probs_scriptable(net_output, log_probs, sample)
        lprobs.batch_first = True
        return lprobs

    def forward(self, src_tokens, src_lengths, prev_output_tokens, tgt_tokens, **kwargs):
        # Encoding
        encoder_out = self.encoder(src_tokens=src_tokens, src_lengths=src_lengths)

        # Length prediction
        length_out = self.decoder.forward_length(
            normalize=False, encoder_out=encoder_out
        )
        length_tgt = self.decoder.forward_length_prediction(
            length_out, encoder_out, tgt_tokens
        )

        # NAT decoding
        word_ins_out = self.decoder(
            normalize=False,
            prev_output_tokens=prev_output_tokens,
            encoder_out=encoder_out,
        )

        ret = {
            "word_ins": {
                "out": word_ins_out,
                "tgt": tgt_tokens,
                "mask": tgt_tokens.ne(self.pad),
                "nll_loss": True,
            },
            "length": {
                "out": length_out,
                "tgt": length_tgt,
                "factor": self.decoder.length_loss_factor,
            },
            "encoder_out": encoder_out,
        }

        return ret

    def forward_decoder(self, decoder_out, encoder_out, decoding_format=None, **kwargs):
        step = decoder_out.step
        output_tokens = decoder_out.output_tokens
        output_scores = decoder_out.output_scores
        history = decoder_out.history

        output_masks = output_tokens.ne(self.pad)
        _scores, _tokens = self.decoder(
            normalize=True,
            prev_output_tokens=output_tokens,
            encoder_out=encoder_out,
            step=step,
        ).max(-1)

        # Ensure _tokens is LongTensor and _scores is float for masked_scatter_ (fp16 compatibility)
        _tokens = _tokens.long()
        _scores = _scores.float()
        output_tokens.masked_scatter_(output_masks, _tokens[output_masks])
        output_scores.masked_scatter_(output_masks, _scores[output_masks])
        if history is not None:
            history.append(output_tokens.clone())

        return decoder_out._replace(
            output_tokens=output_tokens,
            output_scores=output_scores,
            attn=None,
            history=history,
        )

    def initialize_output_tokens(self, encoder_out, src_tokens):
        length_tgt = self.decoder.forward_length_prediction(
            self.decoder.forward_length(normalize=True, encoder_out=encoder_out),
            encoder_out=encoder_out,
        )

        max_length = length_tgt.clamp_(min=2).max()
        idx_length = utils.new_arange(src_tokens, max_length)

        # Use torch.long dtype explicitly (src_tokens is float, so new_zeros would be float)
        initial_output_tokens = torch.zeros(
            src_tokens.size(0), max_length, dtype=torch.long, device=src_tokens.device
        ).fill_(self.pad)
        initial_output_tokens.masked_fill_(
            idx_length[None, :] < length_tgt[:, None], self.unk
        )
        initial_output_tokens[:, 0] = self.bos
        initial_output_tokens.scatter_(1, length_tgt[:, None] - 1, self.eos)

        # Ensure scores are float (not half) to avoid fp16 issues
        initial_output_scores = torch.zeros(
            *initial_output_tokens.size(), dtype=torch.float, device=src_tokens.device
        )

        return DecoderOut(
            output_tokens=initial_output_tokens,
            output_scores=initial_output_scores,
            attn=None,
            step=0,
            max_step=0,
            history=None,
        )

    def regenerate_length_beam(self, decoder_out, beam_size):
        output_tokens = decoder_out.output_tokens
        length_tgt = output_tokens.ne(self.pad).sum(1)
        length_tgt = (
            length_tgt[:, None]
            + utils.new_arange(length_tgt, 1, beam_size)
            - beam_size // 2
        )
        length_tgt = length_tgt.view(-1).clamp_(min=2)
        max_length = length_tgt.max()
        idx_length = utils.new_arange(length_tgt, max_length)

        initial_output_tokens = output_tokens.new_zeros(
            length_tgt.size(0), max_length
        ).fill_(self.pad)
        initial_output_tokens.masked_fill_(
            idx_length[None, :] < length_tgt[:, None], self.unk
        )
        initial_output_tokens[:, 0] = self.bos
        initial_output_tokens.scatter_(1, length_tgt[:, None] - 1, self.eos)

        initial_output_scores = initial_output_tokens.new_zeros(
            *initial_output_tokens.size()
        ).type_as(decoder_out.output_scores)

        return decoder_out._replace(
            output_tokens=initial_output_tokens, output_scores=initial_output_scores
        )


class NATS2TEncoder(FairseqEncoder):
    """S2T Transformer Encoder with 2-layer 1D conv for 4x compression + CTC projection."""

    def __init__(self, args):
        super().__init__(None)

        self.encoder_freezing_updates = args.encoder_freezing_updates
        self.num_updates = 0

        self.dropout_module = FairseqDropout(
            p=args.dropout, module_name=self.__class__.__name__
        )
        self.embed_scale = math.sqrt(args.encoder_embed_dim)
        if args.no_scale_embedding:
            self.embed_scale = 1.0
        self.padding_idx = 1

        # 2 layers of 1D conv with stride=2 each => 4x compression
        self.subsample = Conv1dSubsampler(
            args.input_feat_per_channel * args.input_channels,
            args.conv_channels,
            args.encoder_embed_dim,
            [int(k) for k in args.conv_kernel_sizes.split(",")],
        )

        self.embed_positions = PositionalEmbedding(
            args.max_source_positions, args.encoder_embed_dim, self.padding_idx
        )

        self.transformer_layers = nn.ModuleList(
            [TransformerEncoderLayer(args) for _ in range(args.encoder_layers)]
        )
        if args.encoder_normalize_before:
            self.layer_norm = LayerNorm(args.encoder_embed_dim)
        else:
            self.layer_norm = None

        # Encoder CTC projection head
        self.encoder_ctc_weight = getattr(args, "encoder_ctc_weight", 0.3)
        self.ctc_proj = nn.Linear(args.encoder_embed_dim, args.tgt_dict_size)

    def _forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        x, input_lengths = self.subsample(src_tokens, src_lengths)
        x = self.embed_scale * x

        encoder_padding_mask = lengths_to_padding_mask(input_lengths)
        positions = self.embed_positions(encoder_padding_mask).transpose(0, 1)
        x += positions
        x = self.dropout_module(x)

        encoder_states = []
        for layer in self.transformer_layers:
            x = layer(x, encoder_padding_mask)
            if return_all_hiddens:
                encoder_states.append(x)

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        return {
            "encoder_out": [x],  # T x B x C
            "encoder_padding_mask": [encoder_padding_mask]
            if encoder_padding_mask.any()
            else [],  # B x T
            "encoder_embedding": [],
            "encoder_states": encoder_states,
            "src_tokens": [],
            "src_lengths": [input_lengths],
        }

    def forward(self, src_tokens, src_lengths, return_all_hiddens=False):
        if self.num_updates < self.encoder_freezing_updates:
            with torch.no_grad():
                x = self._forward(src_tokens, src_lengths, return_all_hiddens)
        else:
            x = self._forward(src_tokens, src_lengths, return_all_hiddens)
        return x

    def get_ctc_logits(self, encoder_out):
        """Get CTC logits from encoder output. Returns T x B x V."""
        enc_out = encoder_out["encoder_out"][0]  # T x B x C
        return self.ctc_proj(enc_out)

    def get_ctc_input_lengths(self, encoder_out):
        enc_out = encoder_out["encoder_out"][0]  # T x B x C
        lens = enc_out.new_full((enc_out.shape[1],), enc_out.shape[0]).long()
        if len(encoder_out["encoder_padding_mask"]) > 0:
            lens -= encoder_out["encoder_padding_mask"][0].sum(dim=-1)
        return lens

    def reorder_encoder_out(self, encoder_out, new_order):
        new_encoder_out = (
            []
            if len(encoder_out["encoder_out"]) == 0
            else [x.index_select(1, new_order) for x in encoder_out["encoder_out"]]
        )
        new_encoder_padding_mask = (
            []
            if len(encoder_out["encoder_padding_mask"]) == 0
            else [
                x.index_select(0, new_order)
                for x in encoder_out["encoder_padding_mask"]
            ]
        )
        new_src_lengths = (
            []
            if len(encoder_out["src_lengths"]) == 0
            else [x.index_select(0, new_order) for x in encoder_out["src_lengths"]]
        )

        return {
            "encoder_out": new_encoder_out,
            "encoder_padding_mask": new_encoder_padding_mask,
            "encoder_embedding": [],
            "encoder_states": [],
            "src_tokens": [],
            "src_lengths": new_src_lengths,
        }

    def set_num_updates(self, num_updates):
        super().set_num_updates(num_updates)
        self.num_updates = num_updates


class NATS2TDecoder(TransformerDecoder):
    """NAT Decoder with CTC projection and length prediction."""

    def __init__(self, args, dictionary, embed_tokens, no_encoder_attn=False):
        super().__init__(args, dictionary, embed_tokens, no_encoder_attn)
        self.dictionary = dictionary
        self.bos = dictionary.bos()
        self.unk = dictionary.unk()
        self.eos = dictionary.eos()

        self.encoder_embed_dim = args.encoder_embed_dim
        self.sg_length_pred = getattr(args, "sg_length_pred", False)
        self.pred_length_offset = getattr(args, "pred_length_offset", False)
        self.length_loss_factor = getattr(args, "length_loss_factor", 0.1)

        # Length prediction
        self.embed_length = Embedding(256, self.encoder_embed_dim, None)

        # Decoder CTC projection
        self.decoder_ctc_weight = getattr(args, "decoder_ctc_weight", 0.3)
        self.dec_ctc_proj = nn.Linear(args.decoder_embed_dim, len(dictionary))

        self.ensemble_models = None

    def forward(self, normalize, encoder_out, prev_output_tokens, step=0, **unused):
        features, _ = self.extract_features(
            prev_output_tokens, encoder_out=encoder_out,
        )
        decoder_out = self.output_layer(features)
        return F.log_softmax(decoder_out, -1) if normalize else decoder_out

    def extract_features(
        self,
        prev_output_tokens,
        encoder_out=None,
        early_exit=None,
        **unused
    ):
        # embed positions
        positions = (
            self.embed_positions(prev_output_tokens)
            if self.embed_positions is not None
            else None
        )

        # embed tokens
        x = self.embed_scale * self.embed_tokens(prev_output_tokens)
        if self.project_in_dim is not None:
            x = self.project_in_dim(x)
        if positions is not None:
            x += positions
        x = self.dropout_module(x)

        decoder_padding_mask = prev_output_tokens.eq(self.padding_idx)

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)
        attn = None
        inner_states = [x]

        for i, layer in enumerate(self.layers):
            if early_exit is not None and i >= early_exit:
                break
            x, attn, _ = layer(
                x,
                encoder_out["encoder_out"][0]
                if (encoder_out is not None and len(encoder_out["encoder_out"]) > 0)
                else None,
                encoder_out["encoder_padding_mask"][0]
                if (
                    encoder_out is not None
                    and len(encoder_out["encoder_padding_mask"]) > 0
                )
                else None,
                self_attn_mask=None,
                self_attn_padding_mask=decoder_padding_mask,
            )
            inner_states.append(x)

        if self.layer_norm:
            x = self.layer_norm(x)

        # T x B x C -> B x T x C
        x = x.transpose(0, 1)

        if self.project_out_dim is not None:
            x = self.project_out_dim(x)

        return x, {"attn": attn, "inner_states": inner_states}

    def get_ctc_logits(self, prev_output_tokens, encoder_out):
        """Get decoder CTC logits. Returns T x B x V."""
        features, _ = self.extract_features(
            prev_output_tokens, encoder_out=encoder_out,
        )
        # features: B x T x C -> T x B x C
        logits = self.dec_ctc_proj(features).transpose(0, 1)
        return logits

    def get_ctc_input_lengths(self, prev_output_tokens):
        """Get decoder output lengths for CTC."""
        mask = prev_output_tokens.ne(self.padding_idx)
        return mask.sum(-1)

    def forward_length(self, normalize, encoder_out):
        enc_feats = encoder_out["encoder_out"][0]  # T x B x C
        if len(encoder_out["encoder_padding_mask"]) > 0:
            src_masks = encoder_out["encoder_padding_mask"][0]
        else:
            src_masks = None
        enc_feats = _mean_pooling(enc_feats, src_masks)
        if self.sg_length_pred:
            enc_feats = enc_feats.detach()
        length_out = F.linear(enc_feats, self.embed_length.weight)
        return F.log_softmax(length_out, -1) if normalize else length_out

    def forward_length_prediction(self, length_out, encoder_out, tgt_tokens=None):
        enc_feats = encoder_out["encoder_out"][0]
        if len(encoder_out["encoder_padding_mask"]) > 0:
            src_masks = encoder_out["encoder_padding_mask"][0]
        else:
            src_masks = None

        # Compute src_lengs first (always needed for pred_length_offset)
        if src_masks is None:
            src_lengs = enc_feats.new_ones(enc_feats.size(1)).fill_(
                enc_feats.size(0)
            ).long()  # Ensure long type
        else:
            src_lengs = (~src_masks).transpose(0, 1).sum(0).long()  # Ensure long type

        if tgt_tokens is not None:
            tgt_lengs = tgt_tokens.ne(self.padding_idx).sum(1).long()
            if self.pred_length_offset:
                length_tgt = tgt_lengs - src_lengs + 128
            else:
                length_tgt = tgt_lengs
            length_tgt = length_tgt.clamp(min=0, max=255)
        else:
            pred_lengs = length_out.max(-1)[1].long()  # Ensure long type for indexing
            if self.pred_length_offset:
                length_tgt = pred_lengs - 128 + src_lengs
            else:
                length_tgt = pred_lengs
            length_tgt = length_tgt.clamp(min=0, max=255)

        return length_tgt


@register_model_architecture("nat_s2t_transformer", "nat_s2t_transformer")
def nat_s2t_base_architecture(args):
    args.encoder_freezing_updates = getattr(args, "encoder_freezing_updates", 0)
    # Convolutional subsampler
    args.input_channels = getattr(args, "input_channels", 1)
    args.input_feat_per_channel = getattr(args, "input_feat_per_channel", 80)
    args.conv_kernel_sizes = getattr(args, "conv_kernel_sizes", "5,5")
    args.conv_channels = getattr(args, "conv_channels", 1024)
    # Transformer
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 12)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", True)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", True)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.dropout = getattr(args, "dropout", 0.1)
    args.attention_dropout = getattr(args, "attention_dropout", args.dropout)
    args.activation_dropout = getattr(args, "activation_dropout", args.dropout)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0.0)
    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)
    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.max_source_positions = getattr(args, "max_source_positions", 6000)
    args.max_target_positions = getattr(args, "max_target_positions", 1024)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    # NAT specific
    args.sg_length_pred = getattr(args, "sg_length_pred", False)
    args.pred_length_offset = getattr(args, "pred_length_offset", False)
    args.length_loss_factor = getattr(args, "length_loss_factor", 0.1)
    # CTC
    args.encoder_ctc_weight = getattr(args, "encoder_ctc_weight", 0.3)
    args.decoder_ctc_weight = getattr(args, "decoder_ctc_weight", 0.3)


@register_model_architecture("nat_s2t_transformer", "nat_s2t_transformer_m")
def nat_s2t_transformer_m(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 512 * 4)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.dropout = getattr(args, "dropout", 0.15)
    nat_s2t_base_architecture(args)


@register_model_architecture("nat_s2t_transformer", "nat_s2t_transformer_s")
def nat_s2t_transformer_s(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 256)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 256 * 8)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 4)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 4)
    args.dropout = getattr(args, "dropout", 0.1)
    nat_s2t_base_architecture(args)


@register_model_architecture("nat_s2t_transformer", "nat_s2t_transformer_l")
def nat_s2t_transformer_l(args):
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 1024)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 1024 * 4)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 16)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 16)
    args.dropout = getattr(args, "dropout", 0.2)
    nat_s2t_base_architecture(args)
