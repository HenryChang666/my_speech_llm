#!/usr/bin/env bash
# Train Pure CTC NAT S2T Transformer on LibriSpeech (Speech Recognition)
# Uses dev-clean as validation set
# 4-GPU distributed training via torchrun
set -euo pipefail
export NCCL_DEBUG=ERROR
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

DATA_ROOT=/root/data/librispeech
CONFIG_YAML=config_nat.yaml
SAVE_DIR=/root/experiments/ckpts/nat_s2t_ctc_asr_librispeech
TASK_TYPE=asr

source /root/envs/fairseq/bin/activate

mkdir -p ${SAVE_DIR}

torchrun --nproc_per_node=8 --master_port=29512 \
    $(which fairseq-train) ${DATA_ROOT} \
    --config-yaml ${CONFIG_YAML} \
    --task nat_speech_to_text \
    --task-type ${TASK_TYPE} \
    --encoder-layers 12 \
    --train-subset train-clean-100,train-clean-360,train-other-500 \
    --valid-subset test-clean,test-other \
    --arch nat_s2t_ctc_transformer_m \
    --criterion nat_s2t_pure_ctc \
    --encoder-only \
    --encoder-ctc-weight 1.0 \
    --decoder-ctc-weight 0.0 \
    --upsample-ratio 1 \
    --encoder-normalize-before \
    --decoder-normalize-before \
    --post-process sentencepiece \
    --optimizer adam \
    --adam-betas '(0.9, 0.98)' \
    --lr 5e-4 \
    --lr-scheduler inverse_sqrt \
    --warmup-updates 10000 \
    --clip-norm 10.0 \
    --max-tokens 80000 \
    --update-freq 1 \
    --seed 1 \
    --fp16 \
    --max-epoch 200 \
    --num-workers 4 \
    --save-dir ${SAVE_DIR} \
    --save-interval 1 \
    --keep-last-epochs 50 \
    --best-checkpoint-metric enc_wer \
    --patience 10 \
    --log-format json \
    --log-interval 100 \
    --ddp-backend legacy_ddp \
