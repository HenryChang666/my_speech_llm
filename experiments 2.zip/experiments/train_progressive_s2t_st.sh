#!/usr/bin/env bash
# Train Progressive S2T on MuST-C En-De (Speech Translation)
# Multi-level CTC: char(layer6) + phone(layer9) + subword(layer12) + decoder
# Uses tst-COMMON as validation set; GPUs 0-3
set -euo pipefail
export NCCL_DEBUG=ERROR
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

DATA_ROOT=/root/data/en-de
CONFIG_YAML=config_nat.yaml
SAVE_DIR=/root/experiments/progressive_s2t_st_ende
TASK_TYPE=st

source /root/envs/fairseq/bin/activate
mkdir -p ${SAVE_DIR}

torchrun --nproc_per_node=8 --master_port=29502 \
    $(which fairseq-train) ${DATA_ROOT} \
    --config-yaml ${CONFIG_YAML} \
    --task progressive_speech_to_text \
    --task-type ${TASK_TYPE} \
    --char-vocab-filename dict_c.en.txt \
    --phone-vocab-filename src_dict.txt \
    --train-subset train \
    --valid-subset tst-COMMON_st \
    --arch progressive_s2t_transformer_m \
    --criterion progressive_ctc \
    --char-ctc-weight 0.5 \
    --phone-ctc-weight 0.5 \
    --encoder-ctc-weight 1 \
    --decoder-ctc-weight 1 \
    --char-ctc-layer 6 \
    --phone-ctc-layer 9 \
    --mid-conv-layer 7 \
    --top-conv-layer 10 \
    --conv-kernel-sizes "5" \
    --encoder-normalize-before \
    --decoder-normalize-before \
    --post-process sentencepiece \
    --optimizer adam \
    --adam-betas '(0.9, 0.98)' \
    --lr 5e-4 \
    --lr-scheduler inverse_sqrt \
    --warmup-updates 10000 \
    --clip-norm 10.0 \
    --max-tokens 50000 \
    --update-freq 1 \
    --seed 1 \
    --fp16 \
    --max-epoch 200 \
    --num-workers 4 \
    --save-dir ${SAVE_DIR} \
    --save-interval 1 \
    --keep-last-epochs 50 \
    --best-checkpoint-metric bleu \
    --maximize-best-checkpoint-metric \
    --patience 10 \
    --log-format json \
    --log-interval 100 \
    --ddp-backend legacy_ddp \
