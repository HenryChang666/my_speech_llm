#!/usr/bin/env bash
# Train Multi-Scale S2T on LibriSpeech (ASR)
# Multi-level CTC: small(250,vocab6) + medium(1000,vocab9) + large(10000,vocab12) + decoder
# Uses test-clean as validation set; GPUs 0-7

set -euo pipefail
export NCCL_DEBUG=ERROR
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

DATA_ROOT=/root/data/librispeech
CONFIG_YAML=config_nat.yaml
SAVE_DIR=/root/experiments/ckpts/multiscale_s2t_asr_librispeech_conv8
TASK_TYPE=asr

source /root/envs/fairseq/bin/activate
mkdir -p ${SAVE_DIR}

torchrun --nproc_per_node=8 --master_port=29555 \
    $(which fairseq-train) ${DATA_ROOT} \
    --config-yaml ${CONFIG_YAML} \
    --task multiscale_speech_to_text \
    --task-type ${TASK_TYPE} \
    --encoder-layers 12 \
    --small-vocab-filename spm_unigram250_ende.txt \
    --medium-vocab-filename spm_unigram1000_ende.txt \
    --train-subset train-clean-100,train-clean-360,train-other-500 \
    --valid-subset test-clean,test-other \
    --arch multiscale_s2t_transformer_m \
    --criterion multiscale_ctc \
    --small-ctc-weight 1 \
    --medium-ctc-weight 1 \
    --encoder-ctc-weight 1 \
    --encoder-only \
    --decoder-ctc-weight 0.0 \
    --small-ctc-layer 6 \
    --medium-ctc-layer 9 \
    --mid-conv-layer 7 \
    --top-conv-layer 10 \
    --conv-kernel-sizes "5" \
    --encoder-normalize-before \
    --decoder-normalize-before \
    --post-process sentencepiece \
    --optimizer adam \
    --adam-betas '(0.9, 0.98)' \
    --lr 5e-4 \
    --lr-scheduler inverse_sqrt \
    --warmup-updates 10000 \
    --clip-norm 10.0 \
    --max-tokens 80000 \
    --update-freq 1 \
    --seed 1 \
    --fp16 \
    --max-epoch 200 \
    --num-workers 4 \
    --save-dir ${SAVE_DIR} \
    --save-interval 1 \
    --keep-last-epochs 50 \
    --best-checkpoint-metric enc_wer \
    --patience 10 \
    --log-format json \
    --log-interval 100 \
    --ddp-backend legacy_ddp \
