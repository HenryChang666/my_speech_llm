#!/usr/bin/env bash
# Train Pure CTC NAT S2T Transformer on MuST-C En-De (Speech Translation)
# Uses test set (tst-COMMON) as validation set
# Initialized from ASR pretrained model
# 8-GPU distributed training via torchrun
set -euo pipefail
export NCCL_DEBUG=ERROR
export CUDA_VISIBLE_DEVICES=0,1,2,3

DATA_ROOT=/root/data/en-de
CONFIG_YAML=config_nat.yaml
SAVE_DIR=/root/experiments/ckpts/nat_s2t_ctc_st_ende_no_finetune
TASK_TYPE=st

# ASR pretrained checkpoint for encoder initialization
ASR_CKPT=/root/experiments/ckpts/nat_s2t_ctc_asr_librispeech/checkpoint150.pt

source /root/envs/fairseq/bin/activate

mkdir -p ${SAVE_DIR}

torchrun --nproc_per_node=4 --master_port=29501 \
    $(which fairseq-train) ${DATA_ROOT} \
    --config-yaml ${CONFIG_YAML} \
    --task nat_speech_to_text \
    --task-type ${TASK_TYPE} \
    --train-subset train \
    --valid-subset tst-COMMON_st \
    --arch nat_s2t_ctc_transformer_m \
    --criterion nat_s2t_pure_ctc \
    --encoder-ctc-weight 1 \
    --decoder-ctc-weight 1 \
    --upsample-ratio 1 \
    --encoder-normalize-before \
    --decoder-normalize-before \
    --post-process sentencepiece \
    --optimizer adam \
    --adam-betas '(0.9, 0.98)' \
    --lr 5e-4 \
    --lr-scheduler inverse_sqrt \
    --warmup-updates 10000 \
    --clip-norm 10.0 \
    --max-tokens 100000 \
    --update-freq 1 \
    --seed 1 \
    --fp16 \
    --max-epoch 200 \
    --num-workers 4 \
    --save-dir ${SAVE_DIR} \
    --save-interval 1 \
    --keep-last-epochs 100 \
    --best-checkpoint-metric bleu \
    --maximize-best-checkpoint-metric \
    --patience 10 \
    --log-format json \
    --log-interval 100 \
    --ddp-backend legacy_ddp \
    #--load-pretrained-encoder-from ${ASR_CKPT} \
